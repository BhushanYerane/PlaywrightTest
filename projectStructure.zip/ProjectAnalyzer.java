import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.FileWriter;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ProjectAnalyzer
 *
 * - Prints an ASCII tree of the project.
 * - Scans .java files to identify:
 *      package, imports, declared classes, referenced class names
 * - Resolves intra-project dependencies (file -> file edges).
 * - Optionally emits a Graphviz DOT file for visualization.
 *
 * Usage:
 *   java ProjectAnalyzer <rootDir> [--ext=.java] [--dot=deps.dot] [--ignore=dir1,dir2,...]
 *
 * Example:
 *   java ProjectAnalyzer "C:\\Users\\byerane\\Downloads\\Backup\\Skills\\PlayWright\\playwrightAutomation\\src" --dot=deps.dot
 */
public class ProjectAnalyzer {

    // ----- Configuration -----
    private static final Set<String> DEFAULT_IGNORES = new HashSet<>(Arrays.asList(
            ".git", ".idea", ".vscode", "target", "build", "out", "node_modules", ".gradle", ".mvn"
    ));
    private static final Set<String> DEFAULT_EXTENSIONS = new HashSet<>(Collections.singletonList(".java"));

    // Common Java/stdlib identifiers to ignore when detecting dependencies (reduce noise):
    private static final Set<String> IGNORE_SIMPLE_NAMES = new HashSet<>(Arrays.asList(
            "String", "Integer", "Long", "Short", "Byte", "Character", "Boolean", "Double", "Float",
            "List", "Map", "Set", "HashMap", "HashSet", "ArrayList", "LinkedList", "Deque", "Queue",
            "Optional", "Objects", "System", "Runtime", "Math", "Files", "Paths", "Collectors",
            "Stream", "Class", "Override", "SuppressWarnings", "Autowired", "Test", "BeforeEach",
            "AfterEach", "BeforeAll", "AfterAll", "ParameterizedTest", "DisplayName"
    ));

    private static class FileInfo {
        Path path;
        String packageName = "";
        Set<String> imports = new HashSet<>();
        Set<String> declaredClasses = new HashSet<>(); // simple names
        Set<String> usedSimpleNames = new HashSet<>();
        String relative; // display-friendly relative path

        @Override
        public String toString() {
            return relative;
        }
    }

    private static class Cli {
        Path root;
        Set<String> extensions = new HashSet<>(DEFAULT_EXTENSIONS);
        Set<String> ignoreDirs = new HashSet<>(DEFAULT_IGNORES);
        String dotPath = null;
    }

    public static void main(String[] args) {
        try {
            Cli cli = parseArgs(args);
            if (cli == null) {
                printHelp();
                return;
            }

            // 1) Collect files & build directory tree
            List<Path> sourceFiles = new ArrayList<>();
            DirNode tree = buildTreeAndCollect(cli.root, cli.extensions, cli.ignoreDirs, sourceFiles);

            if (sourceFiles.isEmpty()) {
                System.out.println("No source files found with extensions: " + cli.extensions + " under " + cli.root);
                return;
            }

            // 2) First pass: parse package/imports/declared classes
            Map<Path, FileInfo> fileInfoMap = new LinkedHashMap<>();
            for (Path p : sourceFiles) {
                FileInfo info = parseHeader(p, cli.root);
                fileInfoMap.put(p, info);
            }

            // Build a mapping of simpleName -> FileInfo list (to handle duplicates across packages)
            Map<String, List<FileInfo>> classIndex = new HashMap<>();
            for (FileInfo info : fileInfoMap.values()) {
                for (String cls : info.declaredClasses) {
                    classIndex.computeIfAbsent(cls, k -> new ArrayList<>()).add(info);
                }
            }

            // 3) Second pass: scan for used simple names
            for (FileInfo info : fileInfoMap.values()) {
                info.usedSimpleNames = parseUsages(info.path, classIndex.keySet());
                // filter out obviously noisy names
                info.usedSimpleNames.removeAll(IGNORE_SIMPLE_NAMES);
                // don't count classes declared in same file as dependencies
                info.usedSimpleNames.removeAll(info.declaredClasses);
            }

            // 4) Resolve dependencies between files
            Map<FileInfo, Set<FileInfo>> edges = new LinkedHashMap<>();
            Map<FileInfo, Map<String, List<FileInfo>>> ambiguous = new LinkedHashMap<>();

            for (FileInfo from : fileInfoMap.values()) {
                Set<FileInfo> deps = new LinkedHashSet<>();
                Map<String, List<FileInfo>> ambForFile = new LinkedHashMap<>();

                for (String used : from.usedSimpleNames) {
                    List<FileInfo> candidates = classIndex.get(used);
                    if (candidates == null || candidates.isEmpty()) continue;

                    if (candidates.size() == 1) {
                        deps.add(candidates.get(0));
                        continue;
                    }

                    // Try to resolve via import exact match
                    FileInfo resolved = resolveByImport(from, used, candidates);
                    if (resolved != null) {
                        deps.add(resolved);
                        continue;
                    }

                    // Try same package resolution
                    resolved = resolveBySamePackage(from, used, candidates);
                    if (resolved != null) {
                        deps.add(resolved);
                        continue;
                    }

                    // Ambiguous: record all candidates (excluding self)
                    List<FileInfo> ambList = new ArrayList<>();
                    for (FileInfo cand : candidates) {
                        if (!cand.path.equals(from.path)) {
                            ambList.add(cand);
                        }
                    }
                    if (!ambList.isEmpty()) {
                        ambForFile.put(used, ambList);
                    }
                }

                edges.put(from, deps);
                if (!ambForFile.isEmpty()) {
                    ambiguous.put(from, ambForFile);
                }
            }

            // 5) Print outputs
            System.out.println("\n=== PROJECT TREE ===");
            printTree(tree);

            System.out.println("\n=== FILES SCANNED (" + fileInfoMap.size() + ") ===");
            fileInfoMap.values().forEach(fi -> System.out.println(" - " + fi.relative));

            System.out.println("\n=== DEPENDENCIES (file -> depends on) ===");
            for (Map.Entry<FileInfo, Set<FileInfo>> e : edges.entrySet()) {
                System.out.println(e.getKey().relative);
                if (e.getValue().isEmpty()) {
                    System.out.println("   (no intra-project dependencies found)");
                } else {
                    for (FileInfo dep : e.getValue()) {
                        System.out.println("   -> " + dep.relative);
                    }
                }
            }

            if (!ambiguous.isEmpty()) {
                System.out.println("\n=== AMBIGUOUS REFERENCES (need explicit import or disambiguation) ===");
                for (Map.Entry<FileInfo, Map<String, List<FileInfo>>> e : ambiguous.entrySet()) {
                    System.out.println(e.getKey().relative);
                    for (Map.Entry<String, List<FileInfo>> ae : e.getValue().entrySet()) {
                        System.out.println("   " + ae.getKey() + " could be:");
                        for (FileInfo cand : ae.getValue()) {
                            System.out.println("      - " + cand.relative + " (package: " + cand.packageName + ")");
                        }
                    }
                }
            }

            // 6) Optionally emit Graphviz
            if (cli.dotPath != null) {
                writeDot(cli.dotPath, edges);
                System.out.println("\nDOT graph written to: " + cli.dotPath +
                        "\nRender with: dot -Tpng " + cli.dotPath + " -o deps.png");
            }

            // 7) Example: find relations for a specific file name (e.g., "Test001")
            System.out.println("\nTIP: To find related files for 'Test001', search dependencies above for lines containing it.");
            System.out.println("     Or generate DOT and open it in a graph viewer.");

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
            System.exit(1);
        }
    }

    private static Cli parseArgs(String[] args) {
        if (args.length == 0) return null;

        Cli cli = new Cli();
        cli.root = Paths.get(args[0]);

        if (!Files.exists(cli.root) || !Files.isDirectory(cli.root)) {
            System.err.println("Root directory not found or not a directory: " + cli.root);
            return null;
        }

        for (int i = 1; i < args.length; i++) {
            String a = args[i];
            if (a.startsWith("--ext=")) {
                String v = a.substring("--ext=".length()).trim();
                Set<String> exts = new HashSet<>();
                for (String s : v.split(",")) {
                    s = s.trim();
                    if (!s.startsWith(".")) s = "." + s;
                    exts.add(s.toLowerCase(Locale.ROOT));
                }
                if (!exts.isEmpty()) cli.extensions = exts;
            } else if (a.startsWith("--ignore=")) {
                String v = a.substring("--ignore=".length()).trim();
                Set<String> ig = new HashSet<>();
                for (String s : v.split(",")) {
                    ig.add(s.trim());
                }
                if (!ig.isEmpty()) cli.ignoreDirs = ig;
            } else if (a.startsWith("--dot=")) {
                cli.dotPath = a.substring("--dot=".length()).trim();
            } else if (a.equals("--help") || a.equals("-h") || a.equals("/?")) {
                return null;
            } else {
                System.err.println("Unknown arg: " + a);
                return null;
            }
        }
        return cli;
    }

    private static void printHelp() {
        System.out.println("Usage: java ProjectAnalyzer <rootDir> [--ext=.java] [--dot=deps.dot] [--ignore=dir1,dir2,...]");
        System.out.println("Example:");
        System.out.println("  java ProjectAnalyzer \"C:\\\\Users\\\\byerane\\\\Downloads\\\\Backup\\\\Skills\\\\PlayWright\\\\playwrightAutomation\\\\src\" --dot=deps.dot");
    }

    // ---------- Directory Tree ----------

    private static class DirNode {
        String name;
        List<DirNode> dirs = new ArrayList<>();
        List<String> files = new ArrayList<>();
    }

    private static DirNode buildTreeAndCollect(Path root, Set<String> extensions,
                                               Set<String> ignoreDirs, List<Path> sourceFiles) throws IOException {
        DirNode rootNode = new DirNode();
        rootNode.name = root.getFileName() == null ? root.toString() : root.getFileName().toString();

        // Mapping dir path -> node for building the tree
        Map<Path, DirNode> dirMap = new HashMap<>();
        dirMap.put(root, rootNode);

        Files.walkFileTree(root, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                if (!dir.equals(root)) {
                    String name = dir.getFileName().toString();
                    if (ignoreDirs.contains(name)) {
                        return FileVisitResult.SKIP_SUBTREE;
                    }
                    DirNode parentNode = dirMap.get(dir.getParent());
                    DirNode node = new DirNode();
                    node.name = name;
                    parentNode.dirs.add(node);
                    dirMap.put(dir, node);
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                String name = file.getFileName().toString();
                DirNode parentNode = dirMap.get(file.getParent());
                parentNode.files.add(name);

                String lower = name.toLowerCase(Locale.ROOT);
                for (String ext : extensions) {
                    if (lower.endsWith(ext)) {
                        sourceFiles.add(file);
                        break;
                    }
                }
                return FileVisitResult.CONTINUE;
            }
        });

        // Sort directories and files for prettier output
        sortTree(rootNode);
        return rootNode;
    }

    private static void sortTree(DirNode node) {
        node.dirs.sort(Comparator.comparing(n -> n.name.toLowerCase(Locale.ROOT)));
        node.files.sort(String.CASE_INSENSITIVE_ORDER);
        for (DirNode d : node.dirs) sortTree(d);
    }

    private static void printTree(DirNode node) {
        printTree(node, "", true);
    }

    private static void printTree(DirNode node, String prefix, boolean isRoot) {
        if (!isRoot) {
            System.out.println(prefix + node.name + "/");
            prefix += "  ";
        } else {
            System.out.println(node.name + "/");
        }
        for (int i = 0; i < node.dirs.size(); i++) {
            DirNode child = node.dirs.get(i);
            printTree(child, prefix, false);
        }
        for (String f : node.files) {
            System.out.println(prefix + f);
        }
    }

    // ---------- Parsing Headers (package/imports/declared) ----------

    private static final Pattern PACKAGE_RE = Pattern.compile("^\\s*package\\s+([a-zA-Z0-9_.]+)\\s*;", Pattern.MULTILINE);
    private static final Pattern IMPORT_RE = Pattern.compile("^\\s*import\\s+([a-zA-Z0-9_.*]+)\\s*;", Pattern.MULTILINE);
    private static final Pattern CLASS_RE = Pattern.compile(
            "^\\s*(public\\s+|protected\\s+|private\\s+)?(abstract\\s+|final\\s+)?(class|interface|enum)\\s+([A-Za-z_][A-Za-z0-9_]*)\\b",
            Pattern.MULTILINE);
    private static final Pattern RECORD_RE = Pattern.compile(
            "^\\s*(public\\s+|protected\\s+|private\\s+)?record\\s+([A-Za-z_][A-Za-z0-9_]*)\\b",
            Pattern.MULTILINE);
    private static final Pattern ANNOTATION_TYPE_RE = Pattern.compile(
            "^\\s*(public\\s+|protected\\s+|private\\s+)?@interface\\s+([A-Za-z_][A-Za-z0-9_]*)\\b",
            Pattern.MULTILINE);

    private static FileInfo parseHeader(Path file, Path root) {
        FileInfo info = new FileInfo();
        info.path = file;
        info.relative = root.relativize(file).toString().replace('\\', '/');

        String content = readAll(file);

        Matcher pm = PACKAGE_RE.matcher(content);
        if (pm.find()) info.packageName = pm.group(1);

        Matcher im = IMPORT_RE.matcher(content);
        while (im.find()) {
            info.imports.add(im.group(1));
        }

        Matcher cm = CLASS_RE.matcher(content);
        while (cm.find()) {
            info.declaredClasses.add(cm.group(4));
        }
        Matcher rm = RECORD_RE.matcher(content);
        while (rm.find()) {
            info.declaredClasses.add(rm.group(2));
        }
        Matcher am = ANNOTATION_TYPE_RE.matcher(content);
        while (am.find()) {
            info.declaredClasses.add(am.group(2));
        }

        return info;
    }

    private static String readAll(Path file) {
        try {
            return Files.readString(file, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    // ---------- Parse usages (simple, heuristic tokenization) ----------

    private static final Pattern SIMPLE_NAME_TOKEN = Pattern.compile("\\b([A-Z][A-Za-z0-9_]*)\\b");

    private static Set<String> parseUsages(Path file, Set<String> knownSimpleNames) {
        Set<String> used = new HashSet<>();
        try (BufferedReader br = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            String line;
            while ((line = br.readLine()) != null) {
                // Strip obvious comments to reduce noise
                String trimmed = line.replaceAll("//.*", "");
                Matcher m = SIMPLE_NAME_TOKEN.matcher(trimmed);
                while (m.find()) {
                    String token = m.group(1);
                    if (knownSimpleNames.contains(token)) {
                        used.add(token);
                    }
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
        return used;
    }

    private static FileInfo resolveByImport(FileInfo from, String simple, List<FileInfo> candidates) {
        // imports like: import com.example.BaseTest;
        // wildcard imports won't disambiguate by themselves
        for (String imp : from.imports) {
            if (imp.endsWith("." + simple)) {
                // Match candidate with this package
                String pkg = imp.substring(0, imp.lastIndexOf('.'));
                for (FileInfo cand : candidates) {
                    if (pkg.equals(cand.packageName) && cand.declaredClasses.contains(simple)) {
                        return cand;
                    }
                }
            }
        }
        // Try wildcard imports: import com.example.*;
        for (String imp : from.imports) {
            if (imp.endsWith(".*")) {
                String pkg = imp.substring(0, imp.length() - 2);
                for (FileInfo cand : candidates) {
                    if (pkg.equals(cand.packageName) && cand.declaredClasses.contains(simple)) {
                        return cand; // If multiple match, will be caught later as ambiguous, but here it's the first
                    }
                }
            }
        }
        return null;
    }

    private static FileInfo resolveBySamePackage(FileInfo from, String simple, List<FileInfo> candidates) {
        for (FileInfo cand : candidates) {
            if (Objects.equals(from.packageName, cand.packageName) && cand.declaredClasses.contains(simple)) {
                return cand;
            }
        }
        return null;
    }

    // ---------- Graphviz DOT ----------

    private static void writeDot(String dotPath, Map<FileInfo, Set<FileInfo>> edges) {
        try (PrintWriter pw = new PrintWriter(new FileWriter(dotPath, StandardCharsets.UTF_8))) {
            pw.println("digraph G {");
            pw.println("  graph [rankdir=LR, fontsize=10, labelloc=t, label=\"Project Dependencies\"];");
            pw.println("  node [shape=box, fontsize=9, style=rounded];");

            // Assign indices for stable node ids
            Map<FileInfo, String> ids = new LinkedHashMap<>();
            int idx = 0;
            for (FileInfo fi : edges.keySet()) {
                ids.put(fi, "n" + (idx++));
            }
            // also include deps nodes that may not appear as keys (isolated)
            for (Set<FileInfo> deps : edges.values()) {
                for (FileInfo fi : deps) {
                    ids.putIfAbsent(fi, "n" + (idx++));
                }
            }

            // Emit nodes
            for (Map.Entry<FileInfo, String> e : ids.entrySet()) {
                String label = e.getKey().relative.replace("\\", "/");
                pw.printf("  %s [label=\"%s\"];\n", e.getValue(), escapeDot(label));
            }

            // Emit edges
            for (Map.Entry<FileInfo, Set<FileInfo>> e : edges.entrySet()) {
                String fromId = ids.get(e.getKey());
                for (FileInfo dep : e.getValue()) {
                    String toId = ids.get(dep);
                    if (toId != null) {
                        pw.printf("  %s -> %s;\n", fromId, toId);
                    }
                }
            }

            pw.println("}");
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    private static String escapeDot(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
//--
/***
# 1) Go to the folder where ProjectAnalyzer.java is saved
cd "C:\Tools\ProjectAnalyzer"

# 2) Make sure Java and Javac exist
java -version
javac -version

# 3) Compile the program (this creates ProjectAnalyzer.class in the same folder)
javac ProjectAnalyzer.java

# 4) Run it (note: -cp . tells Java to look in the current folder)
java -cp . ProjectAnalyzer "C:\Users\byerane\Downloads\Backup\Skills\PlayWright\playwrightAutomation\src" --dot=deps.dot
*/