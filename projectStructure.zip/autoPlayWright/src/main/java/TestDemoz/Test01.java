package TestDemoz;

public class Test01 {
    public static void main(String[] args) {
        System.out.println("Hello from Test01!");
        System.out.println("This is an additional line.");
// write your code here launch
    }
}