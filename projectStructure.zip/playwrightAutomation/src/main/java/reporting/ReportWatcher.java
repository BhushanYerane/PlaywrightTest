package reporting;

import com.aventstack.extentreports.ExtentTest;
import com.microsoft.playwright.Page;
import io.qameta.allure.Allure;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.api.extension.TestWatcher;

import java.io.ByteArrayInputStream;
import java.util.Base64;
import java.util.Optional;

public class ReportWatcher implements TestWatcher {

  private final ThreadLocal<Page> pageTL = new ThreadLocal<>();
  private final ThreadLocal<ExtentTest> testTL = new ThreadLocal<>();

  public void setContext(Page page, ExtentTest test) {
    pageTL.set(page);
    testTL.set(test);
  }

  @Override
  public void testSuccessful(ExtensionContext context) {
    Optional.ofNullable(testTL.get()).ifPresent(t -> t.pass("Test passed"));
  }

  @Override
  public void testFailed(ExtensionContext context, Throwable cause) {
    // Attach screenshot to Allure and Extent
    Page page = pageTL.get();
    ExtentTest test = testTL.get();

    if (page != null) {
      byte[] png = page.screenshot(new Page.ScreenshotOptions().setFullPage(true));
      // Allure attachment
      Allure.addAttachment("Failure Screenshot", new ByteArrayInputStream(png));
      // Extent attachment (base64)
      if (test != null) {
        test.fail(cause);
        String base64 = Base64.getEncoder().encodeToString(png);
        test.addScreenCaptureFromBase64String(base64, "Failure Screenshot");
      }
    } else if (test != null) {
      test.fail(cause);
    }
  }

  @Override
  public void testAborted(ExtensionContext context, Throwable cause) {
    Optional.ofNullable(testTL.get()).ifPresent(t -> t.skip("Test aborted: " + cause.getMessage()));
  }
}
