package reporting;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public final class ExtentManager {
  private static ExtentReports extent;

  private ExtentManager() {}

  public static synchronized ExtentReports getReporter() {
    if (extent == null) {
      ExtentSparkReporter spark = new ExtentSparkReporter("target/extent-report.html");
      spark.config().setDocumentTitle("Playwright Test Report");
      spark.config().setReportName("UI Automation Suite");

      extent = new ExtentReports();
      extent.attachReporter(spark);
      extent.setSystemInfo("Framework", "Playwright + JUnit 5");
      extent.setSystemInfo("OS", System.getProperty("os.name"));
      extent.setSystemInfo("Java", System.getProperty("java.version"));
    }
    return extent;
  }
}
