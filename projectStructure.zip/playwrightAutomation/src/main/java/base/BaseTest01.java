package base;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.LoadState;
import org.junit.jupiter.api.*;

import java.util.*;
import java.util.logging.*;
import java.util.logging.Formatter;

public class BaseTest01 {
  protected static Playwright playwright;
  protected static Browser browser;

  protected BrowserContext context;
  protected Page page;

  // Config via system properties
  protected static String BROWSER = System.getProperty("browser", "chromium");
  protected static boolean HEADLESS = Boolean.parseBoolean(System.getProperty("headless", "false"));
  protected static boolean FAIL_ON_NETWORK_ERROR = Boolean.parseBoolean(System.getProperty("failOnNetworkError", "false"));

  // Network failures recorded per test
  protected final List<com.microsoft.playwright.Response> failedResponses = Collections.synchronizedList(new ArrayList<>());

  protected final Logger LOG = Logger.getLogger(getClass().getName());

  @BeforeAll
  static void beforeAll() {
    configureRootLogger();
    playwright = Playwright.create();
    BrowserType.LaunchOptions opts = new BrowserType.LaunchOptions().setHeadless(HEADLESS);
    switch (BROWSER.toLowerCase(Locale.ROOT)) {
      case "firefox":  browser = playwright.firefox().launch(opts); break;
      case "webkit":   browser = playwright.webkit().launch(opts); break;
      case "chromium":
      default:         browser = playwright.chromium().launch(opts); break;
    }
    Logger.getLogger(BaseTest.class.getName()).info(
        String.format("Launched %s (headless=%s)", BROWSER, HEADLESS));
  }

  @AfterAll
  static void afterAll() {
    if (browser != null) browser.close();
    if (playwright != null) playwright.close();
  }

  @BeforeEach
  void beforeEach() {
    context = browser.newContext(new Browser.NewContextOptions().setAcceptDownloads(false));
    page = context.newPage();
    page.setDefaultTimeout(30000);
    page.setDefaultNavigationTimeout(30000);
    attachNetworkListeners();
  }

  @AfterEach
  void afterEach() {
    context.close();
  }

  protected void waitStable() {
    page.waitForLoadState(LoadState.DOMCONTENTLOADED);
    page.waitForLoadState(LoadState.NETWORKIDLE);
  }

  private void attachNetworkListeners() {
    page.onResponse(resp -> {
      int status = resp.status();
      if (status >= 400) {
        failedResponses.add(resp);
        LOG.warning(() -> String.format("Network error %d %s -> %s",
            status, resp.statusText(), resp.url()));
      }
    });
  }

  private static void configureRootLogger() {
    Logger root = Logger.getLogger("");
    for (Handler h : root.getHandlers()) root.removeHandler(h);
    ConsoleHandler console = new ConsoleHandler();
    console.setLevel(Level.INFO);
    console.setFormatter(new Formatter() {
      @Override public String format(LogRecord r) {
        return String.format("[%1$tT] %-7s %s%n", new Date(r.getMillis()), r.getLevel().getName(), r.getMessage());
      }
    });
    root.addHandler(console);
    root.setLevel(Level.INFO);
  }
}
