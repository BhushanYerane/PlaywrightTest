package base;

import com.microsoft.playwright.*;
import org.junit.jupiter.api.*;

public class primaryTest {

    protected static Playwright playwright;
    protected static Browser browser;
    protected BrowserContext context;
    protected Page page;

    @BeforeAll
    static void beforeAll() {
        System.out.println("===== TEST EXECUTION STARTED =====");
        playwright = Playwright.create();
        browser = playwright.chromium()
                .launch(new BrowserType.LaunchOptions().setHeadless(false).setSlowMo(1000));
    //     System.out.println("Browser launched successfully");
    }

    @AfterAll
    static void afterAll() {
        if (browser != null) {
           browser.close();
    //      System.out.println("Browser closed");
        }
        if (playwright != null) {
            playwright.close();
    //       System.out.println("Playwright closed");
        }
        System.out.println("===== TEST EXECUTION FINISHED =====");
    }

    @BeforeEach
    void beforeEach(TestInfo testInfo) {
        context = browser.newContext();
        page = context.newPage();
        System.out.println("---- Test Started: " + testInfo.getDisplayName() + " ----");
    }

    @AfterEach
    void afterEach(TestInfo testInfo) {
        if (context != null) {
            context.close();
        }
        System.out.println("---- Test Ended: " + testInfo.getDisplayName() + " ----");
    }

    protected void navigateToApp() {
        System.out.println("Navigating to DoTestHere site");
        page.navigate("https://dotesthere.com/");
        System.out.println("DoTestHere loaded | Title: " + page.title());
    }

    protected void launchPracticeSite1() {
        //System.out.println("Navigating to Rahul Shetty Academy site");
        page.navigate("https://rahulshettyacademy.com/");
        System.out.println("Practice site loaded | Title: " + page.title());
    }
    protected void launchPracticeSite2() {
        page.navigate("https://rahulshettyacademy.com/loginpagePractise/");
       // System.out.println("Practice site loaded | Title: " + page.title());
    }
    
}