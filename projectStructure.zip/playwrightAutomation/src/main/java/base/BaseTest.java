package base;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import io.qameta.allure.Step;
import reporting.ExtentManager;
import reporting.ReportWatcher;
import utils.ConfigLoader;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public abstract class BaseTest {
  protected final Logger log = LoggerFactory.getLogger(getClass());

  protected Playwright playwright;
  protected Browser browser;
  protected BrowserContext context;
  protected Page page;

  protected ExtentReports extent;
  protected ExtentTest test;

  protected ConfigLoader.Config cfg;

  @RegisterExtension
  ReportWatcher watcher = new ReportWatcher();

  @BeforeAll
  void beforeAllSuite() {
    log.info("<<<- Test SUITE START ->>>");
    extent = ExtentManager.getReporter();

    cfg = ConfigLoader.load();
    log.info("Config -> browser={}, channel={}, headless={}, slowMo={}, baseURL={}, appURL={}, urls={}",
        cfg.browser, cfg.channel, cfg.headless, cfg.slowMo, cfg.baseURL, cfg.appURL, cfg.urls.keySet());

    playwright = Playwright.create();
    BrowserType.LaunchOptions opts = new BrowserType.LaunchOptions()
        .setHeadless(cfg.headless)
        .setSlowMo(cfg.slowMo);
  //      .setArgs(Arrays.asList("--start-maximized"));

    switch (cfg.browser) {
      case "chromium":
        if (!cfg.channel.isEmpty()) {
          opts.setChannel(cfg.channel);
        }
        browser = playwright.chromium().launch(opts);
        break;
      case "firefox":
        browser = playwright.firefox().launch(opts);
        break;
      case "webkit":
        browser = playwright.webkit().launch(opts);
        break;
      default:
        throw new IllegalArgumentException("Unsupported browser in config: " + cfg.browser);
    }
  }

  @BeforeEach
  void beforeEachTest(TestInfo testInfo) {
    context = browser.newContext();
    page = context.newPage();
    test = extent.createTest(getClass().getSimpleName() + " :: " + testInfo.getDisplayName());
    watcher.setContext(page, test);

    log.info(">>> TEST START: {}", testInfo.getDisplayName());
  }

  @AfterEach
  void afterEachTest(TestInfo testInfo) {
    try {
      if (context != null) context.close();
      if (page != null) page.close();
      log.info("<<< TEST END: {}", testInfo.getDisplayName());
    } finally {
      extent.flush();
    }
  }

  @AfterAll
  void afterAllSuite() {
    try {
      if (browser != null) browser.close();
      if (playwright != null) playwright.close();
      log.info("<<<-- SUITE END -->>>");
    } finally {
      if (extent != null) extent.flush();
    }
  }

  // --- Allure-friendly helper for navigations

  @Step("Navigate to: {url}")
  protected void navigate(String url) {
    if (url == null || url.isEmpty()) {
      throw new IllegalArgumentException("Target URL must not be null or empty.");
    }
    log.info("Navigating to URL: {}", url);
    page.navigate(url);
  }

  @Step("Navigate to Base URL")
  protected void navigateToBase() {
    if (cfg.baseURL == null || cfg.baseURL.isEmpty()) {
      throw new IllegalStateException("baseURL is not configured.");
    }
    log.info("Navigating to baseURL: {}", cfg.baseURL);
    page.navigate(cfg.baseURL);
  }

  @Step("Navigate to App URL")
  protected void navigateToApp() {
    if (cfg.appURL == null || cfg.appURL.isEmpty()) {
      throw new IllegalStateException("appURL is not configured.");
    }
    log.info("Navigating to appURL: {}", cfg.appURL);
    page.navigate(cfg.appURL);
  }

  @Step("Navigate to App URL with key: {key}")
  protected void navigateToApp(String key) {
    if (key == null || key.isEmpty()) {
      throw new IllegalArgumentException("key must not be null or empty.");
    }
    String target = cfg.urls.get(key);
    if (target == null || target.isEmpty()) {
      throw new IllegalStateException("No URL configured for key: " + key);
    }
    log.info("Navigating to URL key='{}' -> {}", key, target);
    page.navigate(target);
  }
}
