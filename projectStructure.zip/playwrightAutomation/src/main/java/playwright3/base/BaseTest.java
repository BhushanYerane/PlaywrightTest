package playwright3.base;

import com.microsoft.playwright.*;

public class BaseTest {
  private static Playwright playwright;
  private static Browser browser;
  private static BrowserContext context;
  private static Page page;

  public static synchronized void start() {
    if (playwright == null) {
      playwright = Playwright.create();
      browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false));
    }
  }

  public static synchronized void newContextAndPage() {
    if (browser == null) start();
    if (context != null) context.close();
    context = browser.newContext();
    page = context.newPage();
  }

  public static Page getPage() {
    return page;
  }

  public static synchronized void stop() {
    try {
      if (context != null) context.close();
    } finally {
      if (browser != null) browser.close();
      if (playwright != null) playwright.close();
      context = null;
      page = null;
      browser = null;
      playwright = null;
    }
  }
}
