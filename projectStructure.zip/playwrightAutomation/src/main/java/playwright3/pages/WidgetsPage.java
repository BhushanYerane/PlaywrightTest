package playwright3.pages;

import com.microsoft.playwright.Page;

public class WidgetsPage {
  private final Page page;
  
  public WidgetsPage(Page page) { this.page = page; }

  public void openAccordion() {
    page.navigate("https://practice.expandtesting.com/accordion");
  }
}

