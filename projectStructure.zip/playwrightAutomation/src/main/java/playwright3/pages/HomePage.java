package playwright3.pages;

import com.microsoft.playwright.Page;
import playwright3.utils.ConfigReader;

public class HomePage {
  private final Page page;
  private final String baseUrl;

  public HomePage(Page page) {
    this.page = page;
    this.baseUrl = ConfigReader.get("baseUrl", "https://practice.expandtesting.com/");
  }

  public void open() {
    page.navigate(baseUrl);
  }

  public String title() {
    return page.title();
  }
}
