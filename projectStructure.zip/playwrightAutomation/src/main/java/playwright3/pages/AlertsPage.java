package playwright3.pages;

import com.microsoft.playwright.Page;

public class AlertsPage {
  private final Page page;
  
  public AlertsPage(Page page) { this.page = page; }

  public void open() {
    page.navigate("https://practice.expandtesting.com/javascript-alerts");
  }
}
