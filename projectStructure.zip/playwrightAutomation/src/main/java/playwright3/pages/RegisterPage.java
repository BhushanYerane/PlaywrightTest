package playwright3.pages;

import com.microsoft.playwright.Page;

public class RegisterPage {
  private final Page page;

  public RegisterPage(Page page) {
    this.page = page;
  }

  public void open() {
    page.navigate("https://practice.expandtesting.com/register");
  }
}
