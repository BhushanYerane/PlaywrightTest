package playwright3.utils;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentManager {
  private static ExtentReports extent;
  private static final ThreadLocal<ExtentTest> currentTest = new ThreadLocal<>();

  public static synchronized ExtentReports getExtent() {
    if (extent == null) {
      ExtentSparkReporter spark = new ExtentSparkReporter("target/extent-report/index.html");
      extent = new ExtentReports();
      extent.attachReporter(spark);
    }
    return extent;
  }

  public static ExtentTest createTest(String name) {
    ExtentTest test = getExtent().createTest(name);
    currentTest.set(test);
    return test;
  }

  public static ExtentTest getTest() {
    return currentTest.get();
  }

  public static void flush() {
    if (extent != null) extent.flush();
  }
}
