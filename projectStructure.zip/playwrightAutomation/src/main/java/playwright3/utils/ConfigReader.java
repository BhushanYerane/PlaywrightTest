package playwright3.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigReader {
  private static final Properties PROPS = new Properties();
  static {
    try (InputStream is = ConfigReader.class.getClassLoader()
        .getResourceAsStream("config.properties")) {
      if (is != null) PROPS.load(is);
    } catch (IOException ignored) {}
  }

  public static String get(String key, String defaultValue) {
    String sys = System.getProperty(key);
    if (sys != null) return sys;
    String val = PROPS.getProperty(key);
    return val != null ? val : defaultValue;
  }
}
