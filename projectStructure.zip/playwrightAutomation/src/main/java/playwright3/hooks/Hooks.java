package playwright3.hooks;

import com.aventstack.extentreports.ExtentTest;
import playwright3.base.BaseTest;
import playwright3.utils.ExtentManager;
import playwright3.pages.HomePage;
import com.microsoft.playwright.Page;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {
  @Before
  public void before(Scenario scenario) {
    BaseTest.start();
    BaseTest.newContextAndPage();
    ExtentTest test = ExtentManager.createTest(scenario.getName());
    test.info("Starting scenario: " + scenario.getName());

    // Launch application home page
    Page page = BaseTest.getPage();
    HomePage home = new HomePage(page);
    home.open();
    test.info("Opened: " + page.url());
  }

  @After
  public void after(Scenario scenario) {
    Page page = BaseTest.getPage();
    try {
      if (scenario.isFailed() && page != null) {
        byte[] shot = page.screenshot(new Page.ScreenshotOptions().setFullPage(true));
        scenario.attach(shot, "image/png", "Failure screenshot");
        ExtentManager.getTest().addScreenCaptureFromBase64String(java.util.Base64.getEncoder().encodeToString(shot));
      }
      if (ExtentManager.getTest() != null) {
        ExtentManager.getTest().info("Scenario status: " + scenario.getStatus());
      }
    } finally {
      BaseTest.stop();
      ExtentManager.flush();
    }
  }
}