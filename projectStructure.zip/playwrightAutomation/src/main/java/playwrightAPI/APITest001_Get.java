package playwrightAPI; // QuotesApiTest- GET /quotes - read one item fields  // Docs: https://playwright.dev/java/docs/api-testing

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.playwright.APIRequest;
import com.microsoft.playwright.APIRequestContext;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Playwright;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class APITest001_Get {

	@Test
	void getQuotes_andReadOneItemFields() throws Exception {
		Playwright pw = Playwright.create();
		// APIRequestContext request = pw.request().newContext(new APIRequest.NewContextOptions().setBaseURL("https://uibank-api.uipath.com")
		// .setIgnoreHTTPSErrors(true).setExtraHTTPHeaders(Map.of("Accept", "application/json")));

		Map<String, String> headers = new HashMap<>();
		headers.put("Accept", "application/json");

		APIRequestContext request = pw.request().newContext(new APIRequest.NewContextOptions()
				.setBaseURL("https://uibank-api.uipath.com").setIgnoreHTTPSErrors(true).setExtraHTTPHeaders(headers));

		APIResponse res = request.get("/api/quotes");
		assertEquals(200, res.status(), "Expected HTTP 200 from /api/quotes");

		ObjectMapper mapper = new ObjectMapper();
		Quote[] quotes = mapper.readValue(res.body(), Quote[].class);

		assertNotNull(quotes);
		assertTrue(quotes.length > 0, "At least one quote expected");

		Quote q = quotes[0];

		System.out.println("---- One Quote item ----");
		System.out.println("id:        " + q.id);
		System.out.println("amount:    " + q.amount);
		System.out.println("term:      " + q.term);
		System.out.println("income:    " + q.income);
		System.out.println("age:       " + q.age);
		System.out.println("accepted:  " + q.accepted);
		System.out.println("rate:      " + q.rate);
		System.out.println("date:      " + q.date);
		System.out.println("email:     " + q.email);

		// Simple validations
		assertNotNull(q.id);
		assertNotNull(q.amount);
		assertNotNull(q.income);

	}
}