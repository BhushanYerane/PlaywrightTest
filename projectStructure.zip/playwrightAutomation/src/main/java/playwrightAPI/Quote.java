package playwrightAPI;

public class Quote {
	public String id;

	public Long amount;
	public Long income;

	public Integer term;
	public Integer age;

	public Boolean accepted;
	public Double rate;
	public String date;
	public String email;
}