package playwrightAPI;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.microsoft.playwright.APIRequest;
import com.microsoft.playwright.APIRequestContext;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.HttpHeader;
import com.microsoft.playwright.options.RequestOptions;

import playwrightAPI.UtilFiles.BaseApiTest;

public class APITest002 extends BaseApiTest {

	private final ObjectMapper mapper = new ObjectMapper();
	static String emailID;

	@Test
	public void getuserID() throws IOException {
		APIRequestContext apiContext = dotesthere();
		APIResponse resp = apiContext.get("/api-testing/",
				RequestOptions.create().setHeader("Accept", "application/json").setQueryParam("id", "1"));

		int statusCode = resp.status();
		System.out.println("Status code is: " + statusCode);
		assertEquals(200, resp.status(), "Expected 200 OK from /api-testing/");
		assertTrue(resp.ok(), "Response not OK: " + resp.status());

		ObjectMapper mapper = new ObjectMapper();
		JsonNode root = mapper.readTree(resp.body());
		JsonNode dataNode = root.path("data");

		ObjectNode onlyData = mapper.createObjectNode();
		onlyData.set("data", dataNode);

		System.out.println(onlyData.toPrettyString());
		apiContext.dispose();
	}

	// @Test
	public void healthCheck_returns200_andJson() throws Exception {
		APIRequestContext ctx = practice();
		APIResponse res = ctx.get("/notes/api/health-check");

		assertEquals(200, res.status(), "Expected 200 OK from /notes/api/health-check");
		assertTrue(res.ok(), "Response not OK: " + res.status());
		assertTrue(res.headers().getOrDefault("content-type", "").toLowerCase().contains("application/json"),
				"Content-Type should be application/json");

		JsonNode json = mapper.readTree(res.body());
		System.out.println("Practice health-check JSON:\n" + json.toPrettyString());

		// Optional field assertion (adjust to the API contract)
		assertTrue(json.has("status"), "JSON should contain 'status' field");

	}

	// @Test
	public void apiTesting_returns200() {
		APIRequestContext ctx = dotesthere();
		{
			APIResponse res = ctx.get("/api-testing/");
			int statusCode = res.status();
			System.out.println("Status code is: " + statusCode);

			assertEquals(200, res.status(), "Expected 200 OK from /api-testing/");
			assertTrue(res.ok(), "Response not OK: " + res.status());

			System.out.println("dotesthere response (text):\n" + res.text());
		}
	}

	// 1 - done
	// @Test
	public void apiTest_gorest() throws Exception {
		Playwright pw = Playwright.create();
		APIRequest apireq = pw.request();

		// APIRequestContext apiContext = apireq.newContext(new
		// APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in")
		// .setIgnoreHTTPSErrors(true).setExtraHTTPHeaders(Map.of("Accept",
		// "application/json")));

		Map<String, String> headers = new HashMap<>();
		headers.put("Accept", "application/json");

		APIRequestContext apiContext = apireq
				.newContext(new APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in")
						.setIgnoreHTTPSErrors(true).setIgnoreHTTPSErrors(true).setExtraHTTPHeaders(headers));

		APIResponse resp = apiContext.get("/public/v2/users", RequestOptions.create().setQueryParam("gender", "female")
				.setQueryParam("status", "active").setQueryParam("page", 1).setQueryParam("per_page", 5));

		int statusCode = resp.status();
		System.out.println("Status code is: " + statusCode);

		assertEquals(200, resp.status(), "Expected HTTP 200");
		assertTrue(resp.ok(), "Response not OK: " + resp.status());

		ObjectMapper mapper = new ObjectMapper();
		JsonNode root = mapper.readTree(resp.body());
		System.out.println("Response (pretty JSON):\n" + root.toPrettyString());

		if (root.isArray()) {
			for (JsonNode user : root) {
				System.out.printf("id=%s, name=%s, email=%s, gender=%s, status=%s%n", user.path("id").asText(),
						user.path("name").asText(), user.path("email").asText(), user.path("gender").asText(),
						user.path("status").asText());
			}
		}
		// Cleanup
		apiContext.dispose();
		pw.close();
	}

	// 2 
	// @Test
	public void disposeResponseTest() throws Exception {
		Playwright pw = Playwright.create();
		APIRequest apireq = pw.request();
		APIRequestContext apiContext = apireq.newContext(
				new APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in").setIgnoreHTTPSErrors(true));

		APIResponse resp = apiContext.get("/public/v2/users");

		int statusCode = resp.status();
		System.out.println("Status code is: " + statusCode);
		assertEquals(200, resp.status(), "Expected HTTP 200");
		assertTrue(resp.ok(), "Response not OK: " + resp.status());
		String statusTxt = resp.statusText();
		System.out.println("Status text is: " + statusTxt);
		System.out.println("Response body (text):\n" + resp.text());

		// Dispose response and context will dispose only response resources, not status
		// code or text
		resp.dispose();
		try {
			System.out.println("Response body (text):\n" + resp.text());
		} catch (Exception e) {
			System.out.println("API response disposed, cannot access body: ");
		}
		int statusCode2 = resp.status();
		System.out.println("Status code is: " + statusCode2);

		String statusTxt1 = resp.statusText();
		System.out.println("Status text is: " + statusTxt1);
		System.out.println("Response URL: " + resp.url());

		APIResponse resp2 = apiContext.get("https://reqres.in/api/users/2");
		System.out.println("New response status code: " + resp2.status());
		System.out.println("New response body (text):\n" + resp2.text());
		resp.dispose();

	}

	// done
	// @Test
	public void getHeaderTest() {
		Playwright pw = Playwright.create();
		APIRequest apireq = pw.request();
		APIRequestContext apiContext = apireq.newContext(
				new APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in").setIgnoreHTTPSErrors(true));
		APIResponse resp = apiContext.get("/public/v2/users");
		int statusCode = resp.status();
		System.out.println("Status code is: " + statusCode);
		assertEquals(200, resp.status(), "Expected HTTP 200");
		assertTrue(resp.ok(), "Response not OK: " + resp.status());

		// using Map
		Map<String, String> headerMap = resp.headers();
		// headerMap.forEach((k,v)-> System.out.println(k +":"+ v));

		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		assertEquals(headerMap.get("content-type"), "application/json; charset=utf-8");
		System.out.println("Total Headers: " + headerMap.size());
		assertEquals(headerMap.get("server"), "cloudflare");

		System.out.println("---------------------");
		// using List
		List<HttpHeader> headerList = resp.headersArray();
		for (HttpHeader hl : headerList) {
			System.out.println(hl.name + " : " + hl.value);
		}
		assertEquals(headerMap.get("content-type"), "application/json; charset=utf-8");
		System.out.println("Total Headers: " + headerMap.size());

	}

	// 4 - done
	// @Test
	public void createuser_post() throws IOException {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("name", "Bhushan Lala");
		data.put("gender", "male");
		data.put("email", getRamdomEmail());
		data.put("status", "active");

		Playwright pw = Playwright.create();
		APIRequest apireq = pw.request();
		APIRequestContext apiContext = apireq.newContext(
				new APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in").setIgnoreHTTPSErrors(true));
		APIResponse postresp = apiContext.post("/public/v2/users",
				RequestOptions.create().setHeader("Content-Type", "application/json")
						.setHeader("Authorization",
								"Bearer 585e6c359bcf796e02db02e7d6688d268d5af543c9642b2067898b0220d3165e")
						.setData(data));
		System.out.println(postresp.status());
		assertEquals(postresp.status(), 201);
		assertEquals(postresp.statusText(), "Created");

		System.out.println(postresp.text());

		ObjectMapper objMapper = new ObjectMapper();
		JsonNode postjsonResp = objMapper.readTree(postresp.body());
		String jsonstr = postjsonResp.toPrettyString();
		System.out.println(jsonstr);

		String userID = postjsonResp.get("id").asText();
		APIRequestContext apiContext1 = apireq.newContext(
				new APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in").setIgnoreHTTPSErrors(true));
		APIResponse getresp1 = apiContext1.get("/public/v2/users/" + userID, RequestOptions.create()
				.setHeader("Authorization", "Bearer 585e6c359bcf796e02db02e7d6688d268d5af543c9642b2067898b0220d3165e"));
		int statusCode = getresp1.status();
		System.out.println("Status code is: " + statusCode);
		assertEquals(getresp1.status(), 200);
		assertEquals(getresp1.statusText(), "OK");
		System.out.println(getresp1.text());
		assertTrue(getresp1.text().contains(userID));
		assertTrue(getresp1.text().contains(emailID));
	}

	// 5 - done
	// @Test
	public void createUser_post_noToken() throws IOException {

		Map<String, Object> data = new HashMap<>();
		data.put("name", "Bhushan Lala");
		data.put("gender", "male");
		data.put("email", getRamdomEmail());
		data.put("status", "active");

		Playwright pw = Playwright.create();
		APIRequest apireq = pw.request();
		APIRequestContext apiContext = apireq.newContext(
				new APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in").setIgnoreHTTPSErrors(true));

		APIResponse postResp = apiContext.post("/public/v2/users", RequestOptions.create()
				.setHeader("Content-Type", "application/json").setHeader("Authorization", "Bearer ").setData(data));

		System.out.println(postResp.status());
		assertEquals(401, postResp.status());
		assertEquals(postResp.statusText(), "Unauthorized");
		String rawResponse = postResp.text();
		System.out.println(rawResponse);

		// Parse JSON
		ObjectMapper mapper = new ObjectMapper();
		JsonNode jsonNode = mapper.readTree(rawResponse);

		System.out.println(jsonNode.toPrettyString());
		assertEquals("Invalid token", jsonNode.get("message").asText());
	}

	// 6 - done
	// @Test
	public void createUser_post_usedEmail() throws IOException {

		Map<String, Object> data = new HashMap<>();
		data.put("name", "Bhushan Lala");
		data.put("gender", "male");
		data.put("email", "bhushan19@2gmail.com");
		data.put("status", "active");

		Playwright pw = Playwright.create();
		APIRequest apireq = pw.request();
		APIRequestContext apiContext = apireq.newContext(
				new APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in").setIgnoreHTTPSErrors(true));

		APIResponse postResp = apiContext.post("/public/v2/users",
				RequestOptions.create().setHeader("Content-Type", "application/json")
						.setHeader("Authorization",
								"Bearer 585e6c359bcf796e02db02e7d6688d268d5af543c9642b2067898b0220d3165e")
						.setData(data));
		System.out.println(postResp.status());
		assertEquals(422, postResp.status());
		assertTrue(postResp.statusText().contains("Unprocessable Entity"));
		String rawResponse = postResp.text();
		System.out.println("\n" + rawResponse);

		ObjectMapper objmapper = new ObjectMapper();
		JsonNode jsonresp = objmapper.readTree(rawResponse);

		String msg = jsonresp.get(0).get("message").asText();
		assertEquals("has already been taken", msg);
	}

	// 8
	//@Test
	public void createuser_withJSONFile() throws IOException {
		// get json file
		//String jsonBody = new String(Files.readAllBytes(Paths.get("./src/main/java/playwrightAPI/data/user.json")),StandardCharsets.UTF_8);
		
		byte [] fileBytes = null;
		File jsonfile = new File("./src/main/java/playwrightAPI/data/user.json");
		fileBytes = Files.readAllBytes(jsonfile.toPath());
		String jsonBody = new String(fileBytes, StandardCharsets.UTF_8);
				
		Playwright pw = Playwright.create();
		APIRequest apireq = pw.request();
		APIRequestContext apiContext = apireq.newContext(new APIRequest.NewContextOptions()
										.setBaseURL("https://gorest.co.in").setIgnoreHTTPSErrors(true));
		APIResponse postresp = apiContext.post("/public/v2/users",RequestOptions.create().setHeader("Content-Type", "application/json")
						.setHeader("Authorization","Bearer 585e6c359bcf796e02db02e7d6688d268d5af543c9642b2067898b0220d3165e")
						.setData(jsonBody));
		System.out.println(postresp.status());
		assertEquals(postresp.status(), 201);
		assertEquals(postresp.statusText(), "Created");

		System.out.println(postresp.text());

		ObjectMapper objMapper = new ObjectMapper();
		JsonNode postjsonResp = objMapper.readTree(postresp.body());
		String jsonstr = postjsonResp.toPrettyString();
		System.out.println(jsonstr);

		String userID = postjsonResp.get("id").asText();
		System.out.println("-----------------> Get Call <--------------------");
		// Get the user which is created
		APIRequestContext apiContext1 = apireq.newContext(
				new APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in").setIgnoreHTTPSErrors(true));
		APIResponse getresp1 = apiContext1.get("/public/v2/users/" + userID, RequestOptions.create()
				.setHeader("Authorization", "Bearer 585e6c359bcf796e02db02e7d6688d268d5af543c9642b2067898b0220d3165e"));
		int statusCode = getresp1.status();
		System.out.println("Status code is: " + statusCode);
		assertEquals(getresp1.status(), 200);
		assertEquals(getresp1.statusText(), "OK");
		System.out.println(getresp1.text());
		assertTrue(getresp1.text().contains(userID));
	}
	
	//7 - done
	//@Test
	public void createuser_withJSONString() throws IOException {
		//String jaon
		String jsonData = "{\r\n"
				+ "    \"name\":\"Bhushan Ramakrishna\", \r\n"
				+ "    \"gender\":\"male\", \r\n"
				+ "    \"email\":\""+getRamdomEmail()+"\", \r\n"
				+ "    \"status\":\"active\"\r\n"
				+ "}";
		
		Playwright pw = Playwright.create();
		APIRequest apireq = pw.request();
		APIRequestContext apiContext = apireq.newContext(
				new APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in").setIgnoreHTTPSErrors(true));
		APIResponse postresp = apiContext.post("/public/v2/users",
				RequestOptions.create().setHeader("Content-Type", "application/json")
						.setHeader("Authorization",
								"Bearer 585e6c359bcf796e02db02e7d6688d268d5af543c9642b2067898b0220d3165e")
						.setData(jsonData));
		System.out.println(postresp.status());
		assertEquals(postresp.status(), 201);
		assertEquals(postresp.statusText(), "Created");

		System.out.println(postresp.text());

		ObjectMapper objMapper = new ObjectMapper();
		JsonNode postjsonResp = objMapper.readTree(postresp.body());
		String jsonstr = postjsonResp.toPrettyString();
		System.out.println(jsonstr);

		String userID = postjsonResp.get("id").asText();
		System.out.println("-----------------> Get Call <--------------------");
		// Get the user which is created
		APIRequestContext apiContext1 = apireq.newContext(
				new APIRequest.NewContextOptions().setBaseURL("https://gorest.co.in").setIgnoreHTTPSErrors(true));
		APIResponse getresp1 = apiContext1.get("/public/v2/users/" + userID, RequestOptions.create()
				.setHeader("Authorization", "Bearer 585e6c359bcf796e02db02e7d6688d268d5af543c9642b2067898b0220d3165e"));
		int statusCode = getresp1.status();
		System.out.println("Status code is: " + statusCode);
		assertEquals(getresp1.status(), 200);
		assertEquals(getresp1.statusText(), "OK");
		System.out.println(getresp1.text());
		assertTrue(getresp1.text().contains(userID));
		assertTrue(getresp1.text().contains(emailID));
	}
	
	//
	public static String getRamdomEmail() {
		emailID = "playwrightAPI" + System.currentTimeMillis() + "@network19.com";
		return emailID;
	}

}