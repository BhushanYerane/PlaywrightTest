package playwrightAPI.UtilFiles;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;

import com.microsoft.playwright.APIRequest;
import com.microsoft.playwright.APIRequestContext;
import com.microsoft.playwright.Playwright;

@TestInstance(Lifecycle.PER_CLASS)
public abstract class BaseApiTest {

	protected Playwright pw;

	@BeforeAll
	void startPlaywright() {
		pw = Playwright.create();
	}

	@AfterAll
	void closePlaywright() {
		if (pw != null) {
			pw.close();
			pw = null;
		}
	}

	/** Context for https://practice.expandtesting.com (read from config). */
	protected APIRequestContext practice() {
		String baseUrl = ConfigFile.get("practice.baseUrl");
		return newContext(baseUrl);
	}

	/** Context for https://dotesthere.com (read from config). */
	protected APIRequestContext dotesthere() {
		String baseUrl = ConfigFile.get("dotesthere.baseUrl");
		return newContext(baseUrl);
	}

	/** Common context builder with sensible defaults. 
	private APIRequestContext newContext(String baseUrl) {
		APIRequest.NewContextOptions opts = new APIRequest.NewContextOptions().setBaseURL(baseUrl)
				.setIgnoreHTTPSErrors(true).setExtraHTTPHeaders(Map.of("Accept", "application/json"));

		return pw.request().newContext(opts);
	}
	*/
	private APIRequestContext newContext(String baseUrl) {

	    Map<String, String> headers = new HashMap<>();
	    headers.put("Accept", "application/json");

	    APIRequest.NewContextOptions opts = new APIRequest.NewContextOptions()
	            .setBaseURL(baseUrl)
	            .setIgnoreHTTPSErrors(true)
	            .setExtraHTTPHeaders(headers);

	    return pw.request().newContext(opts);
	}

	
}