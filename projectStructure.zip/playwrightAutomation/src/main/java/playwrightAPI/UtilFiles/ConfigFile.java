package playwrightAPI.UtilFiles;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.util.Properties;

public final class ConfigFile {
  private static final Properties PROPS = new Properties();

  static {
    try (InputStream is = Thread.currentThread()
                                .getContextClassLoader()
                                .getResourceAsStream("config.properties")) {
      if (is == null) {
        throw new IllegalStateException("config.properties not found on classpath (src/test/resources)");
      }
      PROPS.load(is);
    } catch (IOException e) {
      throw new UncheckedIOException("Failed to load config.properties", e);
    }
  }

  private ConfigFile() {}

  /** Returns system property if present, otherwise value from config.properties. */
  public static String get(String key) {
    String fromSys = System.getProperty(key);
    if (fromSys != null && !fromSys.isBlank()) return fromSys;
    String val = PROPS.getProperty(key);
    if (val == null || val.isBlank()) {
      throw new IllegalStateException("Missing config key: " + key);
    }
    return val;
  }
}