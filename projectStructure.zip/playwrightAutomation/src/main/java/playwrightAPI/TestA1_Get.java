package playwrightAPI;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.Locale;
import java.util.Map;

import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.playwright.APIRequest;
import com.microsoft.playwright.APIRequestContext;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Playwright;

public class TestA1_Get {

	@Test
	public void getuser2_apitest() throws IOException {
		Playwright pw = Playwright.create();
		APIRequest apireq = pw.request();
		APIRequestContext apireqcontext = apireq.newContext(
				new APIRequest.NewContextOptions().setBaseURL("https://practice.expandtesting.com/").setIgnoreHTTPSErrors(true));

		APIResponse apiresp = apireqcontext.get("notes/api/health-check");

		int statusCode = apiresp.status();
		System.out.println("Status code is: " + statusCode);
		assertEquals(200, apiresp.status(), "Expected 200 OK from /api-testing");
		assertTrue(apiresp.ok(), "Response not OK: " + apiresp.status());
		
		ObjectMapper mapper = new ObjectMapper();
		JsonNode jsonResponse = mapper.readTree(apiresp.body());
		String statusValue = jsonResponse.path("status").asText();		
		String jsonmsg = jsonResponse.toPrettyString();
		System.out.println("Status value from JSON: " + jsonmsg);
		
		System.out.println(apiresp.url());
		Map<String, String> headerlist =  apiresp.headers();
		System.out.println("Headers: " + headerlist);
		assertEquals(headerlist.get("content-type"), "application/json; charset=utf-8");
		//assertEquals(headerlist.get("x-download-options"), "");
		
		// Clean up
		apireqcontext.dispose();
		pw.close();
	}

	//@Test
	public void getuser_apitest() throws IOException {
		Playwright pw = Playwright.create();
		APIRequest apireq = pw.request();
		APIRequestContext apireqcontext = apireq
				.newContext(new APIRequest.NewContextOptions().setBaseURL("https://dotesthere.com")
						.setIgnoreHTTPSErrors(true).setExtraHTTPHeaders(Map.of("Accept", "application/json")));

		APIResponse apiresp = apireqcontext.get("/api-testing/");

		int statusCode = apiresp.status();
		System.out.println("Status code is: " + statusCode);
		
		assertEquals(200, apiresp.status(), "Expected 200 OK from /api-testing");
		assertTrue(apiresp.ok(), "Response not OK: " + apiresp.status());
		
		String contentType = apiresp.headers().getOrDefault("content-type", "").toLowerCase(Locale.ROOT);

		String bodyText = apiresp.text();
		System.out.println("Response body: " + bodyText);

		// Clean up
		apireqcontext.dispose();
		pw.close();

	}
}
