package playwright2;

import java.util.List;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.WaitUntilState;

public class Example {
  public static void main(String[] args) throws InterruptedException {
    try (Playwright playwright = Playwright.create()) {
      Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions()
        .setHeadless(false));
      BrowserContext context = browser.newContext();
      Page page = context.newPage();
      page.navigate("https://demoqa.com/register");
      
      page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("First Name")).click();
      page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("First Name")).fill("bhushan");
      page.wait(5000);
      page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Last Name")).click();
      page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Last Name")).fill("yerane");
      page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("UserName")).click();
      page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("UserName")).fill("bhushay");
      page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Password")).click();
      page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Password")).fill("12345qaz");
     
    }
    /**
    Playwright plywright = Playwright.create();
	Browser bowsr = plywright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true).setChannel("msedge")
			.setSlowMo(100)                     
	        .setTimeout(30000)                
	        .setArgs(List.of("--start-maximized",
	        				 "--disable-notifications")));
	BrowserContext bowsrcontext = bowsr.newContext(
				    new Browser.NewContextOptions()
				        .setViewportSize(null));

	Page page = bowsrcontext.newPage();
	
	page.navigate("https://practicesoftwaretesting.com/");
	page.navigate("https://automationintesting.online/", new Page.NavigateOptions().setWaitUntil(WaitUntilState.LOAD).setTimeout(25000));
	
	page.waitForTimeout(5000);
	page.close();
	bowsrcontext.close();
	bowsr.close();
	plywright.close();
    */
  }
}