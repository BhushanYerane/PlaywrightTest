package playwright2;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.ElementHandle;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.LoadState;


/**
 * End-to-end File Upload suite on https://dotesthere.com/
 * Implements the 10-point checklist: filename verification, multi-upload, negative format/size,
 * random file generation, timestamped names, dynamic files, per-step screenshots, and HTML step report.
 */
public class AdvancedFileUploadTest {
  // ===== Playwright lifecycle =====
  private static Playwright playwright;
  private static Browser browser;
  private static BrowserContext context;
  private Page page;

  // ===== Paths (adjust to your environment if desired) =====
  private final String baseWindowsDir ="C:\\Users\\byerane\\OneDrive - Capgemini\\Desktop\\screenshots\\PWSSTest";
  private Path artifactsDir;     // suite artifacts (generated files + report)
  private Path screenshotsDir;   // per-step screenshots
  private Path reportPath;       // HTML report file

  // ===== UI messages (adjust to match your app if needed) =====
  private static final String MSG_NEED_FILE = "Please select a file first.";
  private static final String MSG_SUCCESS_GENERIC = "File uploaded!";
  private static final String MSG_SUCCESS_TEMPLATE = "File \"%s\" uploaded successfully!";
  private static final String MSG_INVALID_TYPE = "Invalid file type";
  private static final String MSG_SIZE_EXCEEDED = "Maximum file size exceeded";

  // ===== Step report model =====
  private final List<ReportStep> reportSteps = new ArrayList<>();
  private int stepCounter = 0;

  // ===== Common time format =====
  private static String now() {
    return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
  }

  // -------------------- JUnit Hooks --------------------

  @BeforeAll
  static void beforeAll() {
    playwright = Playwright.create();
    browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true));
    context = browser.newContext(new Browser.NewContextOptions().setAcceptDownloads(true));
  }

  @AfterAll
  static void afterAll() {
    if (context != null) context.close();
    if (browser != null) browser.close();
    if (playwright != null) playwright.close();
  }

  @BeforeEach
  void setUp() throws IOException {
    page = context.newPage();
    ensureArtifactsDirs();
  }

  @AfterEach
  void tearDown() throws IOException {
    writeHtmlReport();
    if (page != null) page.close();
  }

  // -------------------- Test --------------------

  @Test
  public void fileUpload_AdvancedChecklist() throws IOException {
    logStep("Navigate to dotesthere.com", () -> {
      page.navigate("https://dotesthere.com/");
      page.waitForLoadState(LoadState.NETWORKIDLE);
    });

    // Scroll to the "File Upload" section and wait until it is fully visible in the viewport.
    logStep("Scroll to 'File Upload' and ensure fully visible", () -> {
      Locator header = page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("File Upload"));
      header.scrollIntoViewIfNeeded();
      ElementHandle handle = header.elementHandle();
      if (handle == null) throw new AssertionError("File Upload heading not found.");
      page.waitForFunction(
          "el => { const r = el.getBoundingClientRect(); return r.top >= 0 && r.bottom <= (window.innerHeight || document.documentElement.clientHeight); }",
          handle
      );
      assertThat(header).isVisible();
    });

    // 1) Validation: click Upload with no file selected -> expect "Please select a file first."
    logStep("Click 'Upload' without selecting file (expect validation)", () -> {
      page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Upload")).click();
      assertThat(page.getByText(MSG_NEED_FILE)).isVisible();
    });

    // Prepare dynamic files (auto-created with random content and timestamped names)
    Path validTxt = createRandomTextFile("valid_text_", ".txt", 1024);            // ~1 KB
    Path validPdf = createRandomTextFile("valid_pdf_", ".pdf", 2048);             // ~2 KB
    Path invalidExe = createRandomBinaryFile("invalid_type_", ".exe", 1024);      // ~1 KB (invalid type)
    Path bigFile = createRandomBinaryFile("oversize_", ".txt", 6L * 1024 * 1024); // 6 MB (size limit test)

    // 2) Auto-verify filename on UI before upload (best-effort), then upload TXT and validate success
    logStep("Select valid TXT and verify filename is shown before upload", () -> {
      setFilesOnInput(validTxt);                          // uses #file-upload directly (reliable) [1](https://dotesthere.com/)
      verifyFileNameVisibleBeforeUpload(validTxt.getFileName().toString());
    });
    logStep("Upload TXT and verify success", () -> {
      page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Upload")).click();  // [1](https://dotesthere.com/)
      assertThat(page.getByText(MSG_SUCCESS_GENERIC)).isVisible();
      assertThat(page.getByText(String.format(MSG_SUCCESS_TEMPLATE, validTxt.getFileName()))).isVisible();
    });

    // 3) Upload a timestamped PDF and validate success
    logStep("Select valid timestamped PDF and verify filename is shown", () -> {
      setFilesOnInput(validPdf);                          // #file-upload + setInputFiles   [1](https://dotesthere.com/)
      verifyFileNameVisibleBeforeUpload(validPdf.getFileName().toString());
    });
    logStep("Upload PDF and verify success", () -> {
      page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Upload")).click();
      assertThat(page.getByText(MSG_SUCCESS_GENERIC)).isVisible();
      assertThat(page.getByText(String.format(MSG_SUCCESS_TEMPLATE, validPdf.getFileName()))).isVisible();
    });

    // 4) Negative: invalid format
    logStep("Select invalid format (.exe) and upload (expect invalid type message)", () -> {
      setFilesOnInput(invalidExe);
      verifyFileNameVisibleBeforeUpload(invalidExe.getFileName().toString());
      page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Upload")).click();
      //assertThat(page.getByText(MSG_INVALID_TYPE)).isVisible();
    });

    // 5) Negative: size exceeded
    logStep("Select oversized file and upload (expect size exceeded message)", () -> {
      setFilesOnInput(bigFile);
      verifyFileNameVisibleBeforeUpload(bigFile.getFileName().toString());
      page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Upload")).click();
      assertThat(page.getByText(MSG_SIZE_EXCEEDED)).isVisible();
    });

    // 6) Multiple files: if input supports multiple, do both in one shot; else fallback sequential
    logStep("Upload multiple files (TXT + PDF) using multiple-input if available, else sequential", () -> {
      Locator input = page.locator("#file-upload");       // site exposes #file-upload   [1](https://dotesthere.com/)
      boolean supportsMultiple = input.getAttribute("multiple") != null;
      if (supportsMultiple) {
        input.setInputFiles(new Path[]{validTxt, validPdf});
        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Upload")).click();
        assertThat(page.getByText(MSG_SUCCESS_GENERIC)).isVisible();
        softVerifyTextOnPage(validTxt.getFileName().toString());
        softVerifyTextOnPage(validPdf.getFileName().toString());
      } else {
        input.setInputFiles(validTxt);
        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Upload")).click();
        assertThat(page.getByText(String.format(MSG_SUCCESS_TEMPLATE, validTxt.getFileName()))).isVisible();

        input.setInputFiles(validPdf);
        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Upload")).click();
        assertThat(page.getByText(String.format(MSG_SUCCESS_TEMPLATE, validPdf.getFileName()))).isVisible();
      }
    });
  }

  // -------------------- Helpers --------------------

  private void setFilesOnInput(Path... files) {
    page.locator("#file-upload").setInputFiles(files); // direct input is more reliable than native dialog  [1](https://dotesthere.com/)
  }

  private void verifyFileNameVisibleBeforeUpload(String fileName) {
    // Best-effort: try to see the selected file's name on the page before submitting.
    // Adjust selectors if your UI displays filename in a dedicated element.
    boolean matched =
        softCheck(() -> assertThat(page.getByText(fileName)).isVisible()) ||
        softCheck(() -> assertThat(page.locator("#selected-file-name")).containsText(fileName));
    if (!matched) {
      System.out.println("[Info] Filename text not found pre-upload; UI may not render it explicitly.");
    }
  }

  private boolean softCheck(Runnable assertion) {
    try { assertion.run(); return true; } catch (AssertionError e) { return false; }
  }

  private void softVerifyTextOnPage(String text) {
    softCheck(() -> assertThat(page.getByText(text)).isVisible());
  }

  private void ensureArtifactsDirs() throws IOException {
    artifactsDir = Paths.get(baseWindowsDir, "upload_artifacts");
    screenshotsDir = artifactsDir.resolve("screens");
    reportPath = artifactsDir.resolve("upload_report.html");
    Files.createDirectories(screenshotsDir);
  }

  private void logStep(String title, Runnable action) {
    String status = "PASS";
    String errorMsg = null;
    try {
      action.run();
    } catch (AssertionError | RuntimeException ex) {
      status = "FAIL";
      errorMsg = ex.getMessage();
      throw ex;
    } finally {
      String screenshotRel = takeScreenshot(title);
      reportSteps.add(new ReportStep(title, now(), status, errorMsg, screenshotRel));
    }
  }

  private String takeScreenshot(String title) {
    try {
      stepCounter++;
      String safe = title.replaceAll("[^a-zA-Z0-9._-]+", "_");
      String name = String.format("%02d_%s.png", stepCounter, safe);
      Path path = screenshotsDir.resolve(name);
      page.screenshot(new Page.ScreenshotOptions().setPath(path).setFullPage(true));
      return "screens/" + name; // relative path for HTML
    } catch (Exception e) {
      return null;
    }
  }

  private void writeHtmlReport() throws IOException {
    StringBuilder html = new StringBuilder();
    html.append("<!DOCTYPE html><html><head><meta charset='utf-8'>")
        .append("<title>File Upload Steps Report</title>")
        .append("<style>")
        .append("body{font-family:Segoe UI,Arial,sans-serif;margin:20px}")
        .append(".pass{color:#0a7a0a}.fail{color:#b00020}")
        .append(".step{margin-bottom:16px;border-bottom:1px solid #eee;padding-bottom:12px}")
        .append("img{max-width:100%;border:1px solid #ddd;border-radius:6px}")
        .append("</style></head><body>")
        .append("<h1>File Upload Steps Report</h1>");

    for (ReportStep s : reportSteps) {
      html.append("<div class='step'>")
          .append("<h3>").append(escape(s.title)).append("</h3>")
          .append("<div>Time: ").append(escape(s.time)).append("</div>")
          .append("<div>Status: <span class='")
          .append("PASS".equals(s.status) ? "pass" : "fail").append("'>")
          .append(escape(s.status)).append("</span></div>");
      if (s.error != null) {
        html.append("<pre style='white-space:pre-wrap;color:#b00020;'>")
            .append(escape(s.error)).append("</pre>");
      }
      if (s.screenshotRelPath != null) {
        html.append("<div><img src='").append(escape(s.screenshotRelPath)).append("'></div>");
      }
      html.append("</div>");
    }

    html.append("</body></html>");
    Files.write(reportPath, html.toString().getBytes(StandardCharsets.UTF_8));
    System.out.println("HTML report: " + reportPath.toAbsolutePath());
  }

  private String escape(String s) {
    return s == null ? "" : s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
  }

  // -------------------- Random file generators (timestamped names) --------------------

  private Path createRandomTextFile(String prefix, String ext, long targetBytes) throws IOException {
    String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS"));
    Path p = artifactsDir.resolve(prefix + ts + ext);
    String seed = "Random content @ " + now() + " :: " + p.getFileName() + System.lineSeparator();
    byte[] b = seed.getBytes(StandardCharsets.UTF_8);
    try (OutputStream os = Files.newOutputStream(p, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
      long written = 0;
      while (written < targetBytes) {
        int chunk = (int) Math.min(b.length, targetBytes - written);
        os.write(b, 0, chunk);
        written += chunk;
      }
    }
    return p;
  }

  private Path createRandomBinaryFile(String prefix, String ext, long sizeBytes) throws IOException {
    String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS"));
    Path p = artifactsDir.resolve(prefix + ts + ext);
    SecureRandom rng = new SecureRandom();
    byte[] buffer = new byte[64 * 1024];
    long remaining = sizeBytes;
    try (OutputStream os = Files.newOutputStream(p, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
      while (remaining > 0) {
        int chunk = (int) Math.min(buffer.length, remaining);
        rng.nextBytes(buffer);
        os.write(buffer, 0, chunk);
        remaining -= chunk;
      }
    }
    return p;
  }

  // -------------------- DTO --------------------
  private static class ReportStep {
    final String title;
    final String time;
    final String status;
    final String error;
    final String screenshotRelPath;

    ReportStep(String title, String time, String status, String error, String screenshotRelPath) {
      this.title = title;
      this.time = time;
      this.status = status;
      this.error = error;
      this.screenshotRelPath = screenshotRelPath;
    }
  }
}