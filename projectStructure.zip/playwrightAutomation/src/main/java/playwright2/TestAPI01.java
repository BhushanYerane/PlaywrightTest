/**
 * This test class demonstrates basic API testing using Playwright's APIRequestContext.
 * It includes two tests:
 * 1. listUsers_basicVerification: Verifies the response of the GET /users endpoint with pagination.
 * 2. getUserById_objectVerification: Fetches a user ID from the list endpoint and verifies the GET /users/{id} response.
 *
 * Note: The tests assume that the GoREST API is available and that the environment variable GOREST_TOKEN is set if authentication is required.
 
package playwright2;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.playwright.APIRequest;
import com.microsoft.playwright.APIRequestContext;
import com.microsoft.playwright.APIResponse;
import com.microsoft.playwright.Playwright;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestAPI01 {

  private static Playwright pw;
  private static APIRequestContext request;
  private static final ObjectMapper M = new ObjectMapper();

  @BeforeAll
  static void setup() {
    pw = Playwright.create();

    String token = System.getenv("GOREST_TOKEN"); // optional for GET
    Map<String, String> headers = new HashMap<>();
    headers.put("Accept", "application/json");
    if (token != null && !token.isBlank()) {
      headers.put("Authorization", "Bearer " + token);
    }

    request = pw.request().newContext(
        new APIRequest.NewContextOptions()
            .setBaseURL("https://gorest.co.in/public/v2")
            .setExtraHTTPHeaders(headers)
    );
  }

  @AfterAll
  static void teardown() {
    if (request != null) request.dispose();
    if (pw != null) pw.close();
  }

  @Test
  @Order(1)
  @DisplayName("GET /users?page=1&per_page=1 → returns array & pagination headers")
  void listUsers_basicVerification() throws Exception {
    APIResponse resp = request.get("/users?page=1&per_page=1");
    assertEquals(200, resp.status(), "Expected 200 for list endpoint");

    String ct = resp.headers().getOrDefault("content-type", "").toLowerCase();
    assertTrue(ct.contains("application/json"), "Content-Type should be JSON but was: " + ct);

    // Parse JSON array from text()
    JsonNode root = M.readTree(resp.text());
    assertTrue(root.isArray(), "Expected a JSON array for list endpoint");
    assertEquals(1, root.size(), "per_page=1 should return 1 item");

    // Pagination headers (present for list endpoints)
    assertNotNull(resp.headers().get("X-Pagination-Page"), "X-Pagination-Page should be present");
    assertNotNull(resp.headers().get("X-Pagination-Limit"), "X-Pagination-Limit should be present");
  }

  @Test
  @Order(2)
  @DisplayName("GET /users/{id} → fetch id from list first, then verify object response")
  void getUserById_objectVerification() throws Exception {
    // Step 1: fetch a current, valid id from the first page
    APIResponse listResp = request.get("/users?page=1&per_page=1");
    assertEquals(200, listResp.status(), "Expected 200 for list endpoint");

    JsonNode list = M.readTree(listResp.text());
    assertTrue(list.isArray() && list.size() > 0, "List should not be empty");

    JsonNode first = list.get(0);
    assertNotNull(first.get("id"), "User id should be present");
    long userId = first.get("id").asLong();

    // Step 2: GET the user by id
    APIResponse resp = request.get("/users/" + userId);
    assertEquals(200, resp.status(), "Expected 200 for existing user id");

    String ct = resp.headers().getOrDefault("content-type", "").toLowerCase();
    assertTrue(ct.contains("application/json"), "Content-Type should be JSON but was: " + ct);

    JsonNode user = M.readTree(resp.text());
    assertTrue(user.isObject(), "Expected JSON object for single user");

    // Basic field checks (GoREST user model: id, name, email, gender, status)
    assertTrue(user.has("id"), "Expected 'id'");
    assertTrue(user.has("name"), "Expected 'name'");
    assertTrue(user.has("email"), "Expected 'email'");
    assertTrue(user.has("status"), "Expected 'status'");
  }
}

**/