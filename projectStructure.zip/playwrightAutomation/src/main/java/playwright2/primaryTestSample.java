package playwright2; // This test contains only the setup and teardown methods for Playwright tests. You can add your test methods in this class or extend it in other test classes to reuse the setup and teardown logic.

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class primaryTestSample {
	 private Playwright playwright;
	  private Browser browser;
	  private BrowserContext context;
	  private Page page;
	
	@BeforeAll
	  void beforeAll() 
	  {
	    // Create Playwright and launch Edge non-headless with slowMo
	    playwright = Playwright.create();
	    browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false).setSlowMo(1000).setChannel("msedge"));
	  }

	  @BeforeEach
	  void beforeEach() {
	    // Fresh context per test for isolation
	    context = browser.newContext();
	    page = context.newPage();
	  }

	  @AfterEach
	  void afterEach() {
	    // Close the context (and all pages it owns)
	    if (context != null) context.close();
	    if (page != null) page.close();
	  }

	  @AfterAll
	  void afterAll() {
	    // Close browser and Playwright
	    if (browser != null) browser.close();
	    if (playwright != null) playwright.close();
	  }

}
