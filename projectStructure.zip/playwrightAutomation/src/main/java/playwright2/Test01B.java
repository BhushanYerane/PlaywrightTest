package playwright2; //this test class uses primaryTest for setup.

import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;

import org.junit.jupiter.api.Test;
import com.microsoft.playwright.options.AriaRole;

import base.primaryTest;
import pages.PracticeHubPage;

public class Test01B extends primaryTest {

	//@Test
	public void testAddRemoveElementsFlow() {
		navigateToApp();
		PracticeHubPage hub = new PracticeHubPage(page);

		// Use Add/Remove Elements locator group + actions
		hub.openAddRemoveElements();
		hub.addElement();
		hub.deleteElement();
		System.out.println("Add/Remove verified");
	}

	//@Test
	public void testABTestingFlow() {
		navigateToApp();
		PracticeHubPage hub = new PracticeHubPage(page);

		// Use AB Testing locator group + actions
		hub.openABTesting();
		assertThat(page.getByRole(AriaRole.HEADING,
				new com.microsoft.playwright.Page.GetByRoleOptions().setName("A/B Testing"))).isVisible();

		hub.showCodeExample();

		hub.switchVersionToB();
		hub.switchVersionToA();
	}

	//@Test
	public void testHomeHeader() {
		navigateToApp();
		PracticeHubPage hub = new PracticeHubPage(page);

		// Common locators in action
		hub.assertHomeLoaded();
	}

	@Test
	public void generalTest() {
		// Unrelated test: shows you can still use 'page' directly
		page.navigate("https://en.wikipedia.org/wiki/Wikipedia");
		page.navigate("https://gorest.co.in/");
		page.getByRole(AriaRole.LINK, new com.microsoft.playwright.Page.GetByRoleOptions().setName("Login")).click();
		page.navigate("https://demo.automationtesting.in/Index.html");
		System.out.println("All loaded successfully");
	}
}
