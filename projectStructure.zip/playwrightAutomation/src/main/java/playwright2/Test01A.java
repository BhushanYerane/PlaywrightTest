package playwright2; // this test class is for practice purpose only, not part of framework, // https://practice.expandtesting.com

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;

import utils.FakerData;
import utils.FakerData.PersonData;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.*;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;
import org.junit.jupiter.api.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class Test01A {
	private Playwright playwright;
	private Browser browser;
	private BrowserContext context;
	private Page page;
	PersonData person = FakerData.buildPerson();

	@Test
	public void Test() {
		page.navigate("https://practice.expandtesting.com/");

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("")).click();
		System.out.println("New URL   = " + page.url());
		page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("")).isVisible();
	}

	// @Test
	public void otpVerify() {
		page.navigate("https://practice.expandtesting.com/");

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("OTP: One Time Password")).click();
		System.out.println("New URL   = " + page.url());
		page.getByRole(AriaRole.HEADING,
				new Page.GetByRoleOptions().setName("OTP Login page for Automation Testing Practice")).isVisible();

		String email = page.getByText("practice@expandtesting.com").innerText().trim();
		String optCode = page.locator("//div[@id='core']//ul/li[2]/b").innerText().trim();

		page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Your Email Address")).fill(email);
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Send OTP Code")).click();

		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("OTP Verification")))
				.isVisible();
		page.getByPlaceholder("Enter OTP code").fill(optCode);
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Verify OTP Code")).click();

		assertThat(page.locator("//div[@id='flash']/b")).isVisible();
		assertThat(page.locator("//div[@id='flash']/b")).containsText("You logged into a secure area!");
		System.out.println("New URL   = " + page.url());
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName(" Logout")).click();
		assertThat(page.locator("//div[@id='flash']/b")).containsText("You logged out of the secure area!");

	}

	// @Test
	public void forgotpassword() {
		page.navigate("https://practice.expandtesting.com/");

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Forgot Password Form")).click();
		System.out.println("New URL   = " + page.url());
		page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Dummy Forgot Password form page"))
				.isVisible();
		assertThat(page.locator("h1")).containsText("Dummy Forgot Password form page for Automation Testing Practice");

		String useremail = person.email;
		System.out.println(useremail);
		page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("E-mail")).fill(useremail);
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Retrieve password")).click();

		String forgotpasswordemailmsg = page.locator("//div[@id='confirmation-alert']/p").innerText().trim();
		assertThat(page.locator("h1")).hasText("Password reset page for Automation Testing Practice");
		assertThat(page.locator("//div[@id='confirmation-alert']/p")).containsText(forgotpasswordemailmsg);

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("SUT")).click();
		assertThat(page.locator("#main-title"))
				.containsText("Automation Testing Practice WebSite for QA and Developers");
	}

	// @Test
	public void registerTest() {
		page.navigate("https://practice.expandtesting.com/");
		System.out.println("Title = " + page.title());
		System.out.println("URL   = " + page.url());
		PlaywrightAssertions.assertThat(page)
				.hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Test Register Page")).click();
		System.out.println("New URL   = " + page.url());
		page.getByRole(AriaRole.HEADING,
				new Page.GetByRoleOptions().setName("Test Register page for Automation Testing")).isVisible();
		String username = new String(person.username);
		String password = new String(person.password);
		String confirmpwd = new String(person.confirmPassword);
		System.out.println("UserName- " + username + "\nPassword- " + password + "\nConfirm Password- " + confirmpwd);

		page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Username")).fill(username);
		page.locator("input#password").fill(password);
		page.locator("#confirmPassword").fill(confirmpwd);
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Register")).click();

		String successmsg = page.locator("#flash").innerText().trim();
		PlaywrightAssertions.assertThat(page.locator("#flash")).hasText(successmsg);
		assertThat(page.locator("h1")).containsText("Test Login page for Automation Testing Practice");
	}

	// @Test
	public void loginTest() {
		page.navigate("https://practice.expandtesting.com/");
		System.out.println("Title = " + page.title());
		System.out.println("URL   = " + page.url());
		PlaywrightAssertions.assertThat(page)
				.hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Test Login Page")).click();
		System.out.println("New URL   = " + page.url());
		page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Test Login page for")).isVisible();

		assertThat(page.locator("#core")).containsText("practice");
		assertThat(page.locator("#core")).containsText("SuperSecretPassword!");

		String usernm = page.locator("//div[@class='row']/div/ul/li[1]/b").innerText().trim();
		String userpwd = page.locator("//div[@class='row']/div/ul/li[2]/b").innerText().trim();

		page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Username")).fill(usernm);
		page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Password")).fill(userpwd);
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Login")).click();

		String loginmsg = page.locator("#flash-message").innerText().trim();
		System.out.println("URL   = " + page.url());

		PlaywrightAssertions.assertThat(page.locator("#flash")).hasText(loginmsg);
		PlaywrightAssertions.assertThat(page.locator("#username")).containsText("Hi, practice!");

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Logout")).click();

		assertThat(page.locator("#flash")).containsText("You logged out of the secure area!");
		assertThat(page.locator("h1")).containsText("Test Login page for Automation Testing Practice");

		/**
		 * if user enter worng deatils
		 * assertThat(page.locator("#flash")).containsText("Your password is invalid!");
		 * assert login message assertThat(page.locator("h1")).containsText("Secure Area
		 * page for Automation Testing Practice");
		 */
	}

	// @Test
	public void webInputs() {
		page.navigate("https://practice.expandtesting.com/");
		System.out.println("Title = " + page.title());
		System.out.println("URL   = " + page.url());
		PlaywrightAssertions.assertThat(page)
				.hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Web inputs")).click();
		System.out.println("New URL   = " + page.url());
		page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Web inputs page")).isVisible();
		assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Display Inputs"))).isVisible();
		assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Clear Inputs"))).isVisible();

		// Prepare expected values (keep them as strings for easy comparison)
		String expectedNumber = "9876543211";
		String expectedText = "Enter Text";
		String expectedPassword = "123#WQaz!";
		String expectedDate = "2022-02-22"; // the input typically expects yyyy-MM-dd

		page.locator("#input-number").fill(expectedNumber);
		page.locator("input#input-text").fill(expectedText);
		page.locator("#input-password").fill(expectedPassword);
		page.locator("#input-date").fill(expectedDate);
		page.locator("#btn-display-inputs").click();

		// Optional: verify what you filled by reading back the input values
		PlaywrightAssertions.assertThat(page.locator("#input-number")).hasValue(expectedNumber);
		PlaywrightAssertions.assertThat(page.locator("#input-text")).hasValue(expectedText);
		PlaywrightAssertions.assertThat(page.locator("#input-password")).hasValue(expectedPassword);
		PlaywrightAssertions.assertThat(page.locator("#input-date")).hasValue(expectedDate);

		// Read outputs (these are text containers, not inputs)
		Locator outNumber = page.locator("#output-number");
		Locator outText = page.locator("#output-text");
		Locator outPassword = page.locator("#output-password");
		Locator outDate = page.locator("#output-date");

		// Exact Assertions (best when you expect exact match)
		PlaywrightAssertions.assertThat(outNumber).hasText(expectedNumber);
		PlaywrightAssertions.assertThat(outText).hasText(expectedText);
		PlaywrightAssertions.assertThat(outPassword).hasText(expectedPassword);
		PlaywrightAssertions.assertThat(outDate).hasText(expectedDate);

		// Partial Assertions (if you only need to verify part of the text)
		// containsText allows partial matches
		PlaywrightAssertions.assertThat(outText).containsText("Enter");
		PlaywrightAssertions.assertThat(outPassword).containsText("#WQ");

		// You can also fetch the raw text if you want to do custom comparisons
		String actualNumber = outNumber.innerText().trim();
		String actualText = outText.innerText().trim();
		String actualPassword = outPassword.innerText().trim();
		String actualDate = outDate.innerText().trim();

		System.out.println("Actual Output -> number: " + actualNumber + ", text: " + actualText + ", password: "
				+ actualPassword + ", date: " + actualDate);

		page.locator("#btn-clear-inputs").click();
		PlaywrightAssertions.assertThat(page.locator("#input-number")).hasText("");

		/** for Input */
		// page.getByRole(AriaRole.SPINBUTTON, new
		// Page.GetByRoleOptions().setName("Input: Number")).fill("9876543210");
		// page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Input:
		// Text")).fill("Bhushan");
		// page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Input:
		// Password")).fill("123#wesQAWE");
		// page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Input:
		// Date")).fill("2023-01-01");
		/** for OutPut */
		// page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Clear
		// Inputs")).click();
		// assertThat(page.locator("#result")).isVisible();

	}

	// @Test
	public void clickMenu() {
		page.navigate("https://practice.expandtesting.com/");
		System.out.println("Title = " + page.title());
		System.out.println("URL   = " + page.url());
		PlaywrightAssertions.assertThat(page)
				.hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");

		PlaywrightAssertions.assertThat(page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("SUT")))
				.isVisible();
		PlaywrightAssertions.assertThat(page.locator("#main-title"))
				.containsText("Automation Testing Practice WebSite for QA and Developers");

		// page.locator("#examples-dropdown").click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Examples")).click();
		PlaywrightAssertions.assertThat(
				page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Sample applications for")))
				.isVisible();
		System.out.println("After Click URL   = " + page.url());

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Apps")).click();
		PlaywrightAssertions.assertThat(
				page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Apps for Automation Testing")))
				.isVisible();
		System.out.println("After Click URL   = " + page.url());

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("APIs")).click();
		PlaywrightAssertions.assertThat(
				page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("REST APIs for Automation Test ")))
				.isVisible();
		System.out.println("After Click URL   = " + page.url());

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Assertions")).click();
		PlaywrightAssertions.assertThat(page.getByRole(AriaRole.HEADING,
				new Page.GetByRoleOptions().setName("Assertions for Automation Testing"))).isVisible();
		System.out.println("After Click URL   = " + page.url());

		// when more than one matching locator or strict mode violation
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Reports")).first().click();
		// page.getByRole(AriaRole.LINK, new
		// Page.GetByRoleOptions().setName("Reports").setExact(true)).click();
		// page.locator("a[href='/#reports']").click();
		PlaywrightAssertions
				.assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Reports Examples")))
				.isVisible();
		System.out.println("After Click URL = " + page.url());

		page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Tools for QA and SDET")).click();
		PlaywrightAssertions
				.assertThat(
						page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Tools for QA and SDET")))
				.isVisible();

		page.mouse().up();
		assertThat(page.locator("#main-navbar")).containsText("Free ISTQB Mock Exams");
		assertThat(page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Search an example...")))
				.isVisible();
		page.getByPlaceholder("Search an example...").fill("LalaJI");
	}

	// @Test
	public void praticeTest() {
		page.navigate("https://practice.expandtesting.com/");
		System.out.println("Title = " + page.title());
		System.out.println("URL   = " + page.url());
		PlaywrightAssertions.assertThat(page)
				.hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");
	}

	@Test
	public void opensExampleAndChecksTitle() {
		page.navigate("https://jqueryui.com/");
		String title = page.title();
		System.out.println("# In Smaple Program #");
		Assertions.assertTrue(title.toLowerCase().contains("example"),
				"Expected title to contain 'example' but was: " + title);
	}

	// @Test
	public void canSearchOnBing() {
		page.navigate("https://www.bing.com");
		page.getByLabel("Enter your search term").click();
		page.keyboard().type("Playwright Java JUnit 5");
		page.keyboard().press("Enter");

		// Wait for results and assert
		Locator results = page.locator("#b_results");
		results.waitFor(); // ensures results are present
		Assertions.assertTrue(results.count() > 0, "Search results should be visible");
	}

	// This part of code is for start browser and close it
	@BeforeAll
	void beforeAll() {
		// Create Playwright and launch Edge non-headless with slowMo
		System.out.println("<------- # Start #--------->");
		playwright = Playwright.create();
		browser = playwright.chromium()
				.launch(new BrowserType.LaunchOptions().setHeadless(false).setSlowMo(1000).setChannel("msedge"));
		// browser = playwright.chromium().launch(new
		// BrowserType.LaunchOptions().setHeadless(true).setSlowMo(100).setChannel("msedge"));
	}

	@BeforeEach
	void beforeEach() {
		// Fresh context per test for isolation
		System.out.println("Test started");
		context = browser.newContext();
		page = context.newPage();
	}

	@AfterEach
	void afterEach() {
		// Close the context (and all pages it owns)
		if (context != null)
			context.close();
		if (page != null)
			page.close();
		System.out.println("Test Ended");
		System.out.println("<------------->");
	}

	@AfterAll
	void afterAll() {
		// Close browser and Playwright
		if (browser != null)
			browser.close();
		if (playwright != null)
			playwright.close();
		System.out.println("<--------- # END #------->");
	}
	//
}
