package playwright2; // this test class is for DoTestHere.com practice site - https://dotesthere.com/   -- BaseTest -- config.properties- configLoader -- Test002.java

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.microsoft.playwright.Download;
import com.microsoft.playwright.FileChooser;
import com.microsoft.playwright.FrameLocator;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.LoadState;
import com.microsoft.playwright.options.MouseButton;
import com.microsoft.playwright.options.SelectOption;

import base.BaseTest;

public class Test002 extends BaseTest {
	String customeFilePath = "C:\\Users\\byerane\\OneDrive - Capgemini\\Desktop\\screenshots\\PWSSTest";
	String saveFilePath = "C:\\\\Users\\\\byerane\\\\OneDrive - Capgemini\\\\Desktop\\\\screenshots\\\\PWSSTest";
	String defaultPath = "C:\\Users\\byerane\\OneDrive - Capgemini\\Desktop\\screenshots\\PWSSTest\\filedownload";

	@Test
	public void test20() {
		navigateToApp();
		// Sortable Data Tables
		Locator sectionHeader = page.getByRole(AriaRole.HEADING,
				new Page.GetByRoleOptions().setName("Sortable Data Tables"));
		sectionHeader.scrollIntoViewIfNeeded();
		sectionHeader.waitFor();
		assertThat(sectionHeader).isVisible();

	}

	// @Test
	public void test19() {
		navigateToApp();
		// WYSIWYG Editor
		Locator sectionHeader = page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("WYSIWYG Editor"));
		sectionHeader.scrollIntoViewIfNeeded();
		sectionHeader.waitFor();
		assertThat(sectionHeader).isVisible();
		// page.locator("#editor").clear();
		Locator editor = page.locator("#editor");
		assertThat(editor).isVisible();

		editor.click();
		editor.selectText();
		page.keyboard().press("Delete");

		// page.locator("#editor").fill("Bhushan");
		editor.type("Lala JI");
		// page.locator("#editor").selectText();
		editor.selectText();

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("B").setExact(true)).click();
		// assertThat(page.getByText("Applied bold formatting")).isVisible();
		Locator boldSpan = editor.locator("b:has-text('Lala JI'), strong:has-text('Lala JI')");
		assertThat(boldSpan).isVisible();

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("I").setExact(true)).click();
		assertThat(page.getByText("Applied italic formatting")).isVisible();

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("U").setExact(true)).click();
		assertThat(page.getByText("Applied underline formatting")).isVisible();
	}

	// @Test
	public void test18() {
		navigateToApp();
		// Shadow DOM
		Locator sectionHeader = page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Shadow DOM"));
		sectionHeader.scrollIntoViewIfNeeded();
		sectionHeader.waitFor();
		assertThat(sectionHeader).isVisible();
		Locator shadowHost = page.locator("#shadow-host");
		assertThat(shadowHost.getByText("Click to create shadow DOM content")).isVisible();
		shadowHost.getByRole(AriaRole.BUTTON, new Locator.GetByRoleOptions().setName("Create Shadow DOM")).click();
		assertThat(page.getByText("Shadow DOM created! 🌟")).isVisible();
		page.onceDialog(dialog -> {
			System.out.println("Dialog message: " + dialog.message());
			dialog.dismiss();
		});
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Shadow Button")).click();
	}

	// @Test
	public void test17() throws IOException, InterruptedException {
		navigateToApp();
		// Horizontal Slider
		Locator sectionHeader = page.getByRole(AriaRole.HEADING,
				new Page.GetByRoleOptions().setName("Horizontal Slider"));
		sectionHeader.scrollIntoViewIfNeeded();
		sectionHeader.waitFor();
		assertThat(sectionHeader).isVisible();
		Locator sliderloc = page.locator("#slider");
		for (int i = 0; i < 7; i++) {
			sliderloc.press("ArrowRight");
			Thread.sleep(200);
		}
		for (int i = 7; i >= 0; i--) {
			sliderloc.press("ArrowLeft");
			Thread.sleep(200);
		}
	}

	// @Test
	public void test16() throws IOException {
		navigateToApp();
		// Frames
		Locator sectionHeader = page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Frames"));
		sectionHeader.scrollIntoViewIfNeeded();
		sectionHeader.waitFor();
		assertThat(sectionHeader).isVisible();
		int iframecount = page.locator("iframe").count();
		FrameLocator iframe1 = page.frameLocator("#frame1");
		Locator frameHeading1 = iframe1.getByRole(AriaRole.HEADING,
				new FrameLocator.GetByRoleOptions().setName("Frame 1"));
		assertThat(frameHeading1).isVisible();

		FrameLocator iframe2 = page.frameLocator("#frame2");
		Locator frameHeading2 = iframe2.getByRole(AriaRole.HEADING,
				new FrameLocator.GetByRoleOptions().setName("Frame 2"));
		Locator frameText = iframe2.getByText("This is frame 2 content");
		assertThat(frameText).isVisible();
	}

	// @Test
	public void test15() throws IOException {
		navigateToApp();
		// Form Authentication
		Locator sectionHeader = page.getByRole(AriaRole.HEADING,
				new Page.GetByRoleOptions().setName("Form Authentication"));
		sectionHeader.scrollIntoViewIfNeeded();
		sectionHeader.waitFor();
		assertThat(sectionHeader).isVisible();
		page.getByPlaceholder("Username (ankur)").fill("ankur");
		page.getByPlaceholder("Password (automation)").fill("automation");
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Login")).click();
		page.getByText("Login successful!").isVisible();
		page.getByText("You logged into a secure area!").isVisible();
	}

	// @Test
	public void test14() throws IOException {
		navigateToApp();
		// File Download
		Locator sectionHeader = page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("File Upload"));
		sectionHeader.scrollIntoViewIfNeeded();
		assertThat(sectionHeader).isVisible();
		String scrollTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
		System.out.println("Scrolled to File Upload section at: " + scrollTime);

		/*
		 * page.getByRole(AriaRole.BUTTON, new
		 * Page.GetByRoleOptions().setName("Choose File")).setInputFiles(Paths.
		 * get("Holiday Calendar 2026.pdf"));
		 */

		// 1️⃣
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Upload")).click();
		assertThat(page.getByText("Please select a file first.")).isVisible();

		// 2️⃣
		Path fileToUpload = Paths.get(saveFilePath + "\\test2.txt");
		FileChooser fileChooser = page.waitForFileChooser(() -> {
			page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Choose File")).click();
		});
		fileChooser.setFiles(fileToUpload);

		// 3️⃣
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Upload")).click();

		// 4️⃣
		assertThat(page.getByText("File uploaded!")).isVisible();
		assertThat(page.getByText("File \"test2.txt\" uploaded successfully!")).isVisible();

		System.out.println("File uploaded successfully: " + fileToUpload);
	}

	// @Test
	public void test13() throws InterruptedException, IOException {
		navigateToApp();
		// File Download
		Locator sectionHeader = page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("File Download"));
		sectionHeader.scrollIntoViewIfNeeded();
		assertThat(sectionHeader).isVisible();

		Path downloadDir = Paths.get(defaultPath);
		Files.createDirectories(downloadDir);

		/**
		 * Download download = page.waitForDownload(() -> { // Click the link that
		 * triggers the download page.getByRole(AriaRole.LINK, new
		 * Page.GetByRoleOptions().setName("Download sample.txt")).click(); }); --- 1-
		 * Download download = page.waitForDownload(() -> {
		 * page.locator("a[download='sample.txt']").click(); }); --- 2- Download
		 * download = page.waitForDownload(() -> { page.locator("a:visible", new
		 * Locator.LocatorOptions() .setHasText("Download sample.txt")) .click(); });
		 */
		// ---- Download 1: sample.txt ----
		Path savedTxt = downloadAndSaveWithTimestamp(() -> page.locator("a[download='sample.txt']").click(), // precise
																												// selector
				downloadDir, "sample");
		System.out.println("Saved TXT: " + savedTxt.toAbsolutePath());

		// ---- Download 2: sample.pdf ----
		Path savedPdf = downloadAndSaveWithTimestamp(() -> page.locator("a[download='sample.pdf']").click(), // precise
																												// selector
				downloadDir, "sample");
		System.out.println("Saved PDF: " + savedPdf.toAbsolutePath());
	}

	private Path downloadAndSaveWithTimestamp(Runnable clickAction, Path downloadDir, String baseName) {
		Download download = page.waitForDownload(clickAction);

		// Original filename (e.g., sample.txt)
		String originalName = download.suggestedFilename();
		String extension = "";
		int dot = originalName.lastIndexOf(".");
		if (dot >= 0) {
			extension = originalName.substring(dot); // includes the dot
		}

		// Build new filename: sample_2026‑02‑17_20‑45‑10.txt
		// Create timestamped filename
		String timeStamp = java.time.LocalDateTime.now()
				.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
		String newFileName = "sample_" + timeStamp + extension;

		Path savePath = downloadDir.resolve(newFileName);
		download.saveAs(savePath);

		System.out.println("Download URL: " + download.url());
		System.out.println("Suggested Filename: " + download.suggestedFilename());
		System.out.println("Saved to: " + savePath.toAbsolutePath());
		return savePath;
	}

	// @Test
	public void test12() throws InterruptedException {
		navigateToApp();
		// Multiple Windows
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Multiple Windows")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Multiple Windows")))
				.isVisible();
		Locator clickLinkToWin = page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Click Here"));
		Page page1 = page.waitForPopup(() -> {
			clickLinkToWin.click();
		});
		assertThat(page1.getByRole(AriaRole.HEADING,
				new Page.GetByRoleOptions().setName("Automation Testing Practice Hub"))).isVisible();
	}

	// @Test
	public void test11() throws InterruptedException {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		// Key Presses
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Key Presses")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Key Presses"))).isVisible();
		Locator inputText = page.getByPlaceholder("Type keys here...");
		// 1
		inputText.press("Enter");
		page.locator("#target").press("Tab");
		assertThat(page.locator("p#key-result")).containsText("You entered:");

		// 2
		// page.locator("#myTextBox").pressSequentially("Hello World!", new
		// Locator.PressSequentiallyOptions().setDelay(100));
		inputText.pressSequentially("Hello World!");
		// inputText.pressSequentially("Hello World!", new
		// Locator.PressSequentiallyOptions().setDelay(100));
		String strenter = page.locator("#target").innerText().trim();
		System.out.println(strenter);

		// 3
		inputText.click();
		page.keyboard().press("Control");
		assertThat(page.locator("p#key-result")).containsText("You entered:");
	}

	// @Test
	public void test10() throws InterruptedException {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		// JavaScript Alerts
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("JavaScript Alerts")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("JavaScript Alerts")))
				.isVisible();

		page.onceDialog(dialog -> {
			System.out.println("Alert Message: " + dialog.message());
			dialog.accept();
		});
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Click for JS Alert")).click();
		assertThat(page.getByText("You successfully clicked an alert")).isVisible();

		page.waitForTimeout(3000);

		page.onceDialog(dialog -> {
			System.out.println("Alert Message: " + dialog.message());
			dialog.accept();
		});
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Click for JS Confirm")).click();
		assertThat(page.getByText("You clicked: Ok")).isVisible();

		page.waitForTimeout(3000);

		page.onceDialog(dialog -> {
			System.out.println("Alert Message: " + dialog.message());
			dialog.accept("Lala ji Hai!!");
		});
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Click for JS Prompt")).click();
		assertThat(page.locator("p#result")).containsText("You entered");

	}

	// @Test
	public void test09() throws InterruptedException {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		// Dynamic Loading
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Dynamic Loading")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Dynamic Loading")))
				.isVisible();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Start Loading")).click();
		assertThat(page.getByText("Loading...")).isVisible();
		assertThat(page.getByText("Loading completed!")).isVisible();
		page.getByText("Hello World!").isVisible();

		// String message = page.getByText("Hello World!").textContent();
		String message = page.getByText("Hello World!").innerText().trim();
		System.out.println("Text -: " + message);

		// Dynamic Loading mouse hover
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Hovers")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Hovers"))).isVisible();

		Locator element1 = page.locator(".figure:has(img[alt='User 1'])");
		// element1.hover();
		element1.hover(new Locator.HoverOptions().setForce(true));
		String hoverText = element1.getByText("name: user1").innerText().trim();
		System.out.println(hoverText);
		element1.locator("a", new Locator.LocatorOptions().setHasText("View profile")).click();
	}

	// @Test
	public void test08() throws InterruptedException {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		// Dynamic Content
		// editable text box and disable
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Dynamic Controls")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Dynamic Controls")))
				.isVisible();
		Locator txtbxInput = page.getByPlaceholder("Disabled input");
		Locator enableBtn = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Enable"));
		Locator disableBtn = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Disable"));

		if (!txtbxInput.isEditable()) {
			if (enableBtn.isVisible()) {
				enableBtn.click();
			} else {
				page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Enable")).click();
			}
			assertThat(page.getByText("Input enabled!")).isVisible();
			assertThat(txtbxInput).isEditable();
		}
		txtbxInput.fill("Lala Ji ");
		disableBtn.click();
		assertThat(page.getByText("Input disabled!")).isVisible();
		assertThat(txtbxInput).not().isEditable();

		// checkbox add and remove
		Locator checkbox = page.getByRole(AriaRole.CHECKBOX, new Page.GetByRoleOptions().setName("A checkbox"));
		Locator checkboxlabel = page.getByLabel("A checkbox");
		Locator addbtn = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Add"));
		Locator removebtn = page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Remove"));

		if (!checkbox.isVisible()) {
			addbtn.click();
			assertThat(page.getByText("Checkbox added!")).isVisible();
			assertThat(checkbox).isVisible();
		}

		if (checkbox.isChecked()) {
			checkbox.uncheck();
			assertThat(page.getByText("A checkbox Remove is now unchecked")).isVisible();
		} else {
			checkbox.check();
			assertThat(page.getByText("A checkbox Remove is now checked")).isVisible();
			checkbox.uncheck();
			assertThat(page.getByText("A checkbox Remove is now unchecked")).isVisible();
		}

		if (!checkbox.isVisible()) {
			if (!checkbox.isChecked()) {
				checkbox.check();
				// page.getByLabel("A checkbox").check();
			}
			assertThat(page.getByText("A checkbox Remove is now checked")).isVisible();
		}
		page.getByRole(AriaRole.CHECKBOX, new Page.GetByRoleOptions().setName("A checkbox")).uncheck();
		assertThat(page.getByText("A checkbox Remove is now unchecked")).isVisible();

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Remove")).click();
		assertThat(page.getByText("Checkbox removed!")).isVisible();
		assertThat(checkbox).not().isVisible();

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Add")).click();
		assertThat(page.getByText("Checkbox added!")).isVisible();
		assertThat(checkbox).isVisible();
	}

	// @Test
	public void test07() throws InterruptedException {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		// Dynamic Content
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Dynamic Content")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Dynamic Content")))
				.isVisible();
		Locator displaymsg = page.getByText("Dynamic content that changes on refresh.");

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Content")).click();
		Locator refreshdisplaymsg = page.getByText("Content refreshed");
		assertThat(page.getByText("Dynamic content refreshed!")).isVisible();
		Locator afterrefreshmsg = page.getByText("New content loaded successfully.");
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Content")).click();

		page.getByText("Dynamic content refreshed!").isVisible();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Content")).click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Content")).click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Content")).click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Content")).click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Content")).click();
		page.getByText("Dynamic content loaded.").isVisible();

	}

	// @Test
	public void test06() throws InterruptedException {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		// Drag and Drop
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Drag & Drop")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Drag & Drop"))).isVisible();
		assertThat(page.getByText("Status: Ready")).isVisible();
		assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Reinitialize"))).isVisible();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Test Drag & Drop")).click();
		page.getByText("A", new Page.GetByTextOptions().setExact(true)).click();
		page.locator("#column-b").click();
		page.getByText("A", new Page.GetByTextOptions().setExact(true)).click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Test Drag & Drop")).click();
		/* Need to check drag and drop not working */

		// DropDown
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Dropdown")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Dropdown"))).isVisible();
		// page.locator("select#dropdown").selectOption("Option 1");
		// page.selectOption("select#dropdown", "Option 1");
		page.selectOption("select#dropdown", new SelectOption().setLabel("Option 1"));
		page.selectOption("select#dropdown", new SelectOption().setIndex(1));
		assertThat(page.getByText("Selected: Option 1")).isVisible();
		page.waitForTimeout(5000);
		page.locator("select#dropdown").selectOption("Option 2");
		assertThat(page.getByText("Selected: Option 2")).isVisible();
	}

	// @Test
	public void test05() {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		// Disappearing Elements
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Disappearing Elements")).click();
		assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Menu"))).isEnabled();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Menu")).click();
		assertThat(page.getByText("Gallery link disappeared!")).isVisible();

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Menu")).click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Refresh Menu")).click();
		assertThat(page.getByText("Gallery link appeared!")).isVisible();
		assertThat(page.locator("//a[@id='gallery-link']")).isVisible();
	}

	// @Test
	public void test04() {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Automation Testing Practice")))
				.isVisible();
		// Checkboxes
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Checkboxes")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Checkboxes"))).isVisible();

		PlaywrightAssertions.assertThat(page.locator("xpath=//input[@id='checkbox1']")).isEnabled();
		PlaywrightAssertions.assertThat(page.locator("xpath=//input[@id='checkbox1']")).not().isChecked();
		PlaywrightAssertions
				.assertThat(page.getByRole(AriaRole.CHECKBOX, new Page.GetByRoleOptions().setName("Checkbox 1")))
				.isVisible();

		PlaywrightAssertions.assertThat(page.locator("xpath=//input[@id='checkbox2']")).isEnabled();
		PlaywrightAssertions.assertThat(page.locator("xpath=//input[@id='checkbox2']")).isChecked();
		PlaywrightAssertions
				.assertThat(page.getByRole(AriaRole.CHECKBOX, new Page.GetByRoleOptions().setName("Checkbox 2")))
				.isVisible();

		page.getByRole(AriaRole.CHECKBOX, new Page.GetByRoleOptions().setName("Checkbox 2")).uncheck();
		PlaywrightAssertions.assertThat(page.getByText("Checkbox 2 (checked) is now unchecked")).isVisible();

		page.getByRole(AriaRole.CHECKBOX, new Page.GetByRoleOptions().setName("Checkbox 1")).check();
		PlaywrightAssertions.assertThat(page.getByText("Checkbox 1 is now checked")).isVisible();

		page.getByRole(AriaRole.CHECKBOX, new Page.GetByRoleOptions().setName("Checkbox 1")).uncheck();
		PlaywrightAssertions.assertThat(page.getByText("Checkbox 1 is now unchecked")).isVisible();

		// *** Context Menu Right click
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Context Menu")).click();
		page.onceDialog(dialog -> {
			System.out.println(String.format("Dialog message: %s", dialog.message()));
			dialog.accept();
		});
		page.getByText("Right-click in this box").click(new Locator.ClickOptions().setButton(MouseButton.RIGHT));

	}

	// @Test
	public void test03() {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Automation Testing Practice")))
				.isVisible();
		// Challenging DOM
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Challenging DOM")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Challenging DOM")))
				.isVisible();
		assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Button 1"))).isEnabled();
		String fnm = page.locator("xpath=//table[@id='challenging-table']/thead/tr/th[1]").innerText().trim();
		String lnm = page.locator("xpath=//table[@id='challenging-table']/thead/tr/th[2]").innerText().trim();
		String eml = page.locator("xpath=//table[@id='challenging-table']/thead/tr/th[3]").innerText().trim();
		String act = page.locator("xpath=//table[@id='challenging-table']/thead/tr/th[4]").innerText().trim();
		System.out.println(fnm + "- " + lnm + "- " + eml + "- " + act);

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Button 1")).click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Button 2")).click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Button 3")).click();
		assertThat(page.getByText("Challenging DOM refreshed!")).isVisible();

		page.locator("//tbody[@id='challenging-tbody']/tr[1]/td/div/button[@class='btn-edit']").click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Cancel")).dblclick();
		assertThat(page.getByText("Challenging DOM refreshed!")).isVisible();

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Edit")).first().click();
		page.getByRole(AriaRole.TEXTBOX).fill("Adipisci111"); // imp one
		page.keyboard().press("Tab");
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Save")).nth(1).click();
		assertThat(page.getByText("Row updated successfully!")).isVisible();

		page.onceDialog(dialog -> {
			System.out.println(String.format("Dialog message: %s", dialog.message()));
			dialog.accept();
		});
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Delete")).last().click();
		assertThat(page.getByText("Row deleted successfully!")).isVisible();
		PlaywrightAssertions.assertThat(page.locator("//tbody[@id='challenging-tbody']/tr[2]//button[2]")).not()
				.isVisible();
	}

	// @Test
	public void test02() {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Automation Testing Practice")))
				.isVisible();
		// Basic Auth
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Basic Auth")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Basic Auth (admin/admin)")))
				.isVisible();
		assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Test Basic Auth"))).isEnabled();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Test Basic Auth")).click();
		assertThat(page.getByText("Basic auth simulation successful")).isVisible();
		page.locator("//div[@id='auth-result']/p").isVisible();
		assertThat(page.locator("//div[@id='auth-result']/p"))
				.containsText("Congratulations! You must have the proper credentials.");

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Test Basic Auth")).click();

		// Broken Images
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Broken Images")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Broken Images"))).isVisible();
		Locator imgs = page.locator("#playground img");
		int count = imgs.count();
		System.out.println("Total images found: " + count);
	}

	// @Test
	public void test01() {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Automation Testing Practice")))
				.isVisible();

		// A/B Testing
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("A/B Testing")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("A/B Testing"))).isVisible();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Version A: Original Content")))
				.isVisible();
		page.locator("//*[@id='playground']/div[2]/div[1]/div[1]/button").click(); //

		assertThat(page.getByText("Code example shown!")).isVisible();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Selenium Java"))).isVisible();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Playwright Python")))
				.isVisible();

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Switch Version")).click();
		assertThat(page.getByText("Switched to Version B")).isVisible();
		assertThat(
				page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Version B: Alternative Content")))
				.isVisible();

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Switch Version")).click();
		assertThat(page.getByText("Switched to Version A")).isVisible();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Version A: Original Content")))
				.isVisible();

		// Add/Remove Element
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Add/Remove Elements")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Add/Remove Elements")))
				.isVisible();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Add Element")).click();
		assertThat(page.getByText("Element added! ➕")).isVisible();
		assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Delete"))).isVisible();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Delete")).click();
		assertThat(page.getByText("Element removed!")).isVisible();
		System.out.println("-----------------------");
	}

	// @Test
	public void abtest() {
		navigateToApp();
		assertThat(page)
				.hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Automation Testing Practice")))
				.isVisible();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("A/B Testing"))).isVisible();
		assertThat(page.locator("#ab-test-content")).containsText("Switch Version");

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Switch Version")).click();
		assertThat(
				page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Version B: Alternative Content")))
				.isVisible();
		assertThat(page.getByText("Switched to Version B")).isVisible();

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Switch Version")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Version A: Original Content")))
				.isVisible();
		assertThat(page.getByText("Switched to Version A")).isVisible();
	}

	@Test
	@Tag("headless")
	public void generalTest() {
		page.navigate("https://en.wikipedia.org/wiki/Wikipedia");
		// System.out.println("1- " + page.title());
		// page.navigate("https://gorest.co.in/");
		// System.out.println("2- " + page.title());
		// page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Login")).click();
		// System.out.println("2.1- " + "After click on login: " + page.title());
		// page.navigate("https://demo.automationtesting.in/Index.html");
		// System.out.println("3- " + page.title());
		// page.navigate("https://dotesthere.com/");
		// System.out.println("4- " + page.title());
		// page.navigate(" https://practice.expandtesting.com/");
		// System.out.println("5- " + page.title());
		// page.navigate("https://uibank-api.uipath.com/explorer/swagger.json");
		// page.waitForTimeout(1250);
		System.out.println("All loaded successfully");
		// page.navigate("https://keycode.info/");
		// System.out.println("6- " + page.title());
	}

	/** Extra Code generate added below */
	// @Test
	public void jsAlert() throws InterruptedException {
		navigateToApp();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("JavaScript Alerts")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("JavaScript Alerts")))
				.isVisible();
		page.onceDialog(dialog -> {
			System.out.println("Alert Message: " + dialog.message());
			dialog.dismiss();
		});
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Click for JS Confirm")).click();
		assertThat(page.getByText("You clicked: Cancel")).isVisible();
	}

	// @Test
	public void keyboardpress() throws InterruptedException {
		page.navigate("https://keycode.info");
		page.keyboard().press("A");
		page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get(customeFilePath + "\\A.png")));
		page.keyboard().press("ArrowLeft");
		page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get(customeFilePath + "\\ArrowLeft.png")));
		page.keyboard().press("Shift+O");
		page.screenshot(new Page.ScreenshotOptions().setPath(Paths.get(customeFilePath + "\\O.png")));
	}

	// @Test
	public void keyboardpress1() throws InterruptedException, IOException {
		Path screenshotsDir = Paths.get("C:", "Users", "byerane", "OneDrive - Capgemini", "Desktop", "screenshots",
				"PWSSTest");
		Files.createDirectories(screenshotsDir);
		page.navigate("https://keycode.info");
		page.waitForLoadState(LoadState.NETWORKIDLE);
		page.focus("body"); // or page.click("body") if focus is not enough
		page.waitForTimeout(200);

		// Press 'A' and screenshot
		page.keyboard().press("A");
		page.screenshot(new Page.ScreenshotOptions().setPath(screenshotsDir.resolve("A.png")));

		// Press 'ArrowLeft' and screenshot
		page.keyboard().press("ArrowLeft");
		page.screenshot(new Page.ScreenshotOptions().setPath(screenshotsDir.resolve("ArrowLeft.png")));

		// Press 'Shift+O' and screenshot
		page.keyboard().press("Shift+O");
		page.screenshot(new Page.ScreenshotOptions().setPath(screenshotsDir.resolve("Shift+O.png")));
	}
}
