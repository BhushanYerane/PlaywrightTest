package playwright2;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.WaitUntilState;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class Test003 {
	private static Playwright plywright;
	private static Browser bowsr;
	private static BrowserContext bowsrcontext;
	private static Page page;

	@BeforeAll
	public void setUpplaywright() {
		plywright = Playwright.create();
		bowsr = plywright.chromium().launch(new BrowserType.LaunchOptions()
				.setHeadless(true)
				.setChannel("msedge")
				.setSlowMo(100).setTimeout(30000)
				.setArgs(List.of("--start-maximized", "--disable-notifications")));
	}

	@BeforeEach
	public void setupPage() {
		bowsrcontext = bowsr.newContext(new Browser.NewContextOptions().setViewportSize(null));
		page = bowsrcontext.newPage();
	}

	//@Test
	public void LaunchTest() {
		page.navigate("https://practicesoftwaretesting.com/");
		page.navigate("https://automationintesting.online/",
				new Page.NavigateOptions().setWaitUntil(WaitUntilState.LOAD).setTimeout(25000));
	}

	@AfterEach
	public void closePage() {
		if (page != null)
			page.close();
		if (bowsrcontext != null)
			bowsrcontext.close();
	}

	@AfterAll
	public void tearDownPlaywright() {
		if (bowsr != null)
			bowsr.close();
		if (plywright != null)
			plywright.close();
	}
}
