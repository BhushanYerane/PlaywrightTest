package playwright2; // This test class contains tests for the practice.expandtesting.com website, which is a test site for automation testing practice. It includes tests for registration, login, web inputs, and menu navigation. The tests use Playwright for browser automation and JUnit for structuring the tests.
// baseURL=https://practice.expandtesting.com/  -- BaseTest -- ConfigLoader

import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;
import base.BaseTest;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;
import org.junit.jupiter.api.Test;

public class Test001 extends BaseTest {

	@Test
	public void registerTest() {
		navigateToBase();
		assertThat(page).hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Test Register Page")).click();
		assertThat(page.getByRole(AriaRole.HEADING,
				new Page.GetByRoleOptions().setName("Test Register page for Automation Testing"))).isVisible();

		page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Username")).fill("bhushanwhy");
		page.locator("#password").fill("123lalaHOW#!");
		page.locator("#confirmPassword").fill("123lalaHOW#!");
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Register")).click();
	}

	//@Test
	public void loginTest() {
		navigateToBase();
		assertThat(page).hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Test Login Page")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Test Login page for")))
				.isVisible();

		// Validate hints
		assertThat(page.locator("#core")).containsText("practice");
		assertThat(page.locator("#core")).containsText("SuperSecretPassword!");

		String usernm = page.locator("//div[@class='row']/div/ul/li[1]/b").innerText().trim();
		String userpwd = page.locator("//div[@class='row']/div/ul/li[2]/b").innerText().trim();

		page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Username")).fill(usernm);
		page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Password")).fill(userpwd);
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Login")).click();

		Locator flash = page.locator("#flash");
		assertThat(flash).isVisible();
		assertThat(page.locator("#username")).containsText("Hi, practice!");

		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Logout")).click();
		assertThat(page.locator("#flash")).containsText("You logged out of the secure area!");
		assertThat(page.locator("h1")).containsText("Test Login page for Automation Testing Practice");
	}

	//@Test
	public void webInputs() {
		navigateToBase();
		assertThat(page).hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Web inputs")).click();

		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Web inputs page")))
				.isVisible();
		assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Display Inputs"))).isVisible();
		assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Clear Inputs"))).isVisible();

		Locator inNumber = page.locator("#input-number");
		Locator inText = page.locator("#input-text");
		Locator inPassword = page.locator("#input-password");
		Locator inDate = page.locator("#input-date");

		Locator resultPanel = page.locator("#result");
		Locator outNumber = page.locator("#output-number");
		Locator outText = page.locator("#output-text");
		Locator outPassword = page.locator("#output-password");
		Locator outDate = page.locator("#output-date");

		// On load, outputs should not be visible
		assertThat(resultPanel).not().isVisible();

		String expectedNumber = "9876543211";
		String expectedText = "Enter Text";
		String expectedPassword = "123#WQaz!";
		String expectedDate = "2022-02-22";

		inNumber.fill(expectedNumber);
		inText.fill(expectedText);
		inPassword.fill(expectedPassword);
		inDate.fill(expectedDate);

		assertThat(inNumber).hasValue(expectedNumber);
		assertThat(inText).hasValue(expectedText);
		assertThat(inPassword).hasValue(expectedPassword);
		assertThat(inDate).hasValue(expectedDate);

		page.locator("#btn-display-inputs").click();
		assertThat(resultPanel).isVisible();

		assertThat(outNumber).hasText(expectedNumber);
		assertThat(outText).hasText(expectedText);
		assertThat(outPassword).hasText(expectedPassword);
		assertThat(outDate).hasText(expectedDate);

		// Clear and verify cleared
		page.locator("#btn-clear-inputs").click();
		assertThat(inNumber).hasValue("");
		assertThat(inText).hasValue("");
		assertThat(inPassword).hasValue("");
		assertThat(inDate).hasValue("");
	}

	//@Test
	public void clickMenu() {
		page.navigate("https://practice.expandtesting.com/");
		System.out.println("Title = " + page.title());
		System.out.println("URL   = " + page.url());
		PlaywrightAssertions.assertThat(page)
				.hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");

		PlaywrightAssertions.assertThat(page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("SUT")))
				.isVisible();
		PlaywrightAssertions.assertThat(page.locator("#main-title"))
				.containsText("Automation Testing Practice WebSite for QA and Developers");

		// page.locator("#examples-dropdown").click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Examples")).click();
		PlaywrightAssertions.assertThat(
				page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Sample applications for")))
				.isVisible();
		System.out.println("After Click URL   = " + page.url());

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Apps")).click();
		PlaywrightAssertions.assertThat(
				page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Apps for Automation Testing")))
				.isVisible();
		System.out.println("After Click URL   = " + page.url());

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("APIs")).click();
		PlaywrightAssertions.assertThat(
				page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("REST APIs for Automation Test ")))
				.isVisible();
		System.out.println("After Click URL   = " + page.url());

		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Assertions")).click();
		PlaywrightAssertions.assertThat(page.getByRole(AriaRole.HEADING,
				new Page.GetByRoleOptions().setName("Assertions for Automation Testing"))).isVisible();
		System.out.println("After Click URL   = " + page.url());

		// when more than one matching locator or strict mode violation
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Reports")).first().click();
		// page.getByRole(AriaRole.LINK, new
		// Page.GetByRoleOptions().setName("Reports").setExact(true)).click();
		// page.locator("a[href='/#reports']").click();
		PlaywrightAssertions
				.assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Reports Examples")))
				.isVisible();
		System.out.println("After Click URL = " + page.url());

		page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Tools for QA and SDET")).click();
		PlaywrightAssertions
				.assertThat(
						page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Tools for QA and SDET")))
				.isVisible();

		page.mouse().up();
		assertThat(page.locator("#main-navbar")).containsText("Free ISTQB Mock Exams");
		assertThat(page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Search an example...")))
				.isVisible();
		page.getByPlaceholder("Search an example...").fill("LalaJI");
	}

	// @Test
	public void praticeTest() {
		page.navigate("https://practice.expandtesting.com/");
		System.out.println("Title = " + page.title());
		System.out.println("URL   = " + page.url());
		PlaywrightAssertions.assertThat(page)
				.hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");
	}
}
