package playwright5;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.AriaRole;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class PracticeAppsPage {

    private final Page page;

    // Constructor
    public PracticeAppsPage(Page page) {
        this.page = page;
    }

    // Locators
    private Locator practiceAppsLink() {
        return page.getByRole(AriaRole.LINK,
                new Page.GetByRoleOptions().setName("Practice Apps"));
    }

    private Locator webAutomationTab() {
        return page.getByRole(AriaRole.TAB,
                new Page.GetByRoleOptions().setName("Web Automation"));
    }

    private Locator startPracticingButtons() {
        return page.getByRole(AriaRole.BUTTON,
                new Page.GetByRoleOptions().setName("Start Practicing"));
    }

    private Locator nameField() {
        return page.getByRole(AriaRole.TEXTBOX,
                new Page.GetByRoleOptions().setName("Your Name*"));
    }

    private Locator emailField() {
        return page.getByRole(AriaRole.TEXTBOX,
                new Page.GetByRoleOptions().setName("Your Email*"));
    }

    private Locator verifyDialog() {
        return page.getByRole(AriaRole.DIALOG,
                new Page.GetByRoleOptions().setName("Verify Access"));
    }

    private Locator verifyAndContinueButton() {
        return page.getByRole(AriaRole.BUTTON,
                new Page.GetByRoleOptions().setName("Verify & Continue"));
    }

    // Actions
    public void openPracticeApps() {
        practiceAppsLink().click();
    }

    public void openWebAutomationTab() {
        webAutomationTab().click();
    }

    public void clickNthStartPracticing(int index) {
        startPracticingButtons().nth(index).click();
    }

    public void enterName(String name) {
        nameField().fill(name);
    }

    public void enterEmail(String email) {
        emailField().fill(email);
    }

    public void focusVerifyDialog() {
        verifyDialog().click();
    }

    public Page verifyAndContinue() {
        return page.waitForPopup(() -> {
            verifyAndContinueButton().click();
        });
    }

    // Assertions on new popup page
    public void verifyLoginPage(Page popupPage) {
        assertThat(popupPage.getByText("Username:")).isVisible();
        assertThat(popupPage.getByText("Password:")).isVisible();
        assertThat(popupPage.getByText("Admin")).isVisible();
        assertThat(popupPage.getByText("User",
                new Page.GetByTextOptions().setExact(true))).isVisible();
        assertThat(popupPage.getByRole(AriaRole.BUTTON,
                new Page.GetByRoleOptions().setName("Sign In"))).isVisible();
    }
}