package playwright5;

/**
 * to generate code
 * //mvn exec:java -e -D exec.mainClass=com.microsoft.playwright.CLI -D exec.args="codegen https://rahulshettyacademy.com/"
 * */
import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;
import static org.testng.Assert.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

import base.primaryTest;

public class Test001A extends primaryTest {
	
	@Test
	public void dashboadrHome()
	{
		launchLoginTest2();
		homepage home = new homepage(page);


		assertTrue(home.getPageTitle().contains("ProtoCommerce"), "Unexpected page title: " + home.getPageTitle());
		assertThat(home.getShopNameHeading()).isVisible();
        assertThat(home.getHomeHeading()).isVisible();
        home.ClickCheckoutBtn();
		
	}

	//@Test
	public void launchLoginTest2() {
		launchPracticeSite2();
		assertThat(page).hasTitle("LoginPage Practise | Rahul Shetty Academy");
		PageObjectTest001A pageObj = new PageObjectTest001A(page);
		
		Assertions.assertTrue(pageObj.checkLabels());
		pageObj.inputUserDetails();
		pageObj.clickonRadiobtn("User");
		pageObj.selectOption("Consultant");
		pageObj.checkTerms();
		pageObj.clickLogin();
	}
	
	//@Test
	public void launchLoginTest(){
		launchPracticeSite2();
		assertThat(page).hasTitle("LoginPage Practise | Rahul Shetty Academy");

		PageObjectTest001A pageObj = new PageObjectTest001A(page);
		assertThat(pageObj.getUserNameLabel()).isVisible();
		assertThat(pageObj.getPasswordLabel()).isVisible();
		assertThat(pageObj.getAdminRadio()).isVisible();
		assertThat(pageObj.getUserRadio()).isVisible();
		pageObj.inputUserDetails();
		pageObj.selectOption("Consultant");
		pageObj.checkTerms();
		pageObj.clickonRadiobtn("User");
	}
	
	//@Test
	public void launchTest() {
		launchPracticeSite1();
		page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Practice Apps")).click();
		assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Master QA Testing Through")))
				.isVisible();
		assertThat(page.locator("h1")).containsText("Master QA Testing Through Practice");

		page.getByRole(AriaRole.TAB, new Page.GetByRoleOptions().setName("Web Automation")).click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Start Practicing")).nth(4).click();
		page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Close")).click();
	}
}
