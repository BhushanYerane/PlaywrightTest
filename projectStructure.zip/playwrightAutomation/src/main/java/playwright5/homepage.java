package playwright5;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

public class homepage {

	private Page page;

	public homepage(Page page) {
		this.page = page;
		this.pageTitle = page.title();
		this.headingShopName = page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Shop Name"));
		this.headingHome = page.getByText("ProtoCommerce Home");
		this.checkoutBtn = page.getByText("Checkout");
	}

	private String pageTitle;
	private Locator headingShopName;
	private Locator headingHome;
	private Locator checkoutBtn;

	// Methods
	public String getPageTitle() {
		return page.title();
	}

	public Locator getShopNameHeading() {
		return headingShopName;
	}

	public Locator getHomeHeading() {
		return headingHome;
	}
	
	public void ClickCheckoutBtn()
	{
		checkoutBtn.click();
	}

}
