package playwright5;

import java.util.List;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.WaitForSelectorState;

public class PageObjectTest001A {

	private Page page;

	// Locators labels
	private Locator userNameLabel;
	private Locator passwordLabel;
	private Locator adminRadioLabel;
	private Locator userRadioLabel;

	// locator inputs
	private Locator userInput;
	private Locator passkeyInput;
	private Locator userRoledropdown;
	private Locator termCheckbox;
	private Locator signInBtn;

	private Locator username;
	private Locator password;

	// ✅ Constructor initializes locators
	public PageObjectTest001A(Page page) {
		this.page = page;
		this.userNameLabel = page.getByLabel("Username");
		this.passwordLabel = page.getByLabel("Password");
		this.adminRadioLabel = page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName("Admin"));
		this.userRadioLabel = page.getByRole(AriaRole.RADIO, new Page.GetByRoleOptions().setName("User"));

		this.userInput = page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Username"));
		this.passkeyInput = page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Password"));
		this.signInBtn = page.locator("#signInBtn");
		this.userRoledropdown = page.getByRole(AriaRole.COMBOBOX);
		this.termCheckbox = page.getByRole(AriaRole.CHECKBOX,
				new Page.GetByRoleOptions().setName("I Agree to the terms and"));

		this.username = page.getByText("rahulshettyacademy");
		this.password = page.getByText("Learning@830$3mK2");
	}
	
	public homepage clickLogin()
	{
		signInBtn.click();
		return new homepage(page);
	}
	
	public void selectOption(String str)
	{
		userRoledropdown.selectOption(str);
	}
	
	public void checkTerms()
	{
		termCheckbox.check();
	}

	public void clickonRadiobtn(String radiobtn) 
	{
		if (radiobtn.equalsIgnoreCase("User")) 
		{
			if (isAdminChecked()) 
			{
//				page.onDialog(dialog -> {
//					System.out.println("Dialog message: " + dialog.message());
//					dialog.accept();
//				});
					userRadioLabel.click();
					// alert is not working then check for pop up locator and handel it as shown.
					Locator modal = page.locator("#myModal");
					modal.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.VISIBLE));
					page.locator("#okayBtn").click();
					modal.waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.HIDDEN));				
			} else {
				System.out.println("User radio already selected");
			}

		} else if (radiobtn.equalsIgnoreCase("Admin")) {
			if (isUserChecked()) {
				adminRadioLabel.check();
			} else {
				System.out.println("Admin radio already selected");
			}
		}
	}
	public void getUserDeatils(String username2, String password2) {
		userInput.fill(username2);
		passkeyInput.fill(password2);
	}

	public void inputUserDetails() {
		getUserDeatils(username.innerText(), password.innerText());
	}

	// ✅ Expose locators (NO assertions)
	public boolean checkLabels() {
		return getUserNameLabel().isVisible() 
				&& getPasswordLabel().isVisible() 
				&& getUserRadio().isVisible()
				&& getAdminRadio().isVisible();
	}

	private boolean isUserChecked() {
		return userRadioLabel.isChecked();
	}

	private boolean isAdminChecked() {
		return adminRadioLabel.isChecked();
	}

	public Locator getUserNameLabel() {
		return userNameLabel;
	}

	public Locator getPasswordLabel() {
		return passwordLabel;
	}

	public Locator getAdminRadio() {
		return adminRadioLabel;
	}

	public Locator getUserRadio() {
		return userRadioLabel;
	}

}
// I write the method
/*** written smaple
public void clickonRadiobtn(String radiobtn)
{
	boolean isBtnCheck = false;
	if(radiobtn.equalsIgnoreCase("User"))
	{
	page.onceDialog(dialog -> {
		System.out.println("Dialog message: " + dialog.message());
		dialog.dismiss();
	});
	userRadioLabel.click();
	} else if (radiobtn.equalsIgnoreCase("Admin")){	
		isBtnCheck = adminRadioLabel.isChecked();
		if(isBtnCheck)
			System.out.println("already checked");
		// if isBtnCheck is true continue with executuin. admin radio is already check.
	} else 
	{
		adminRadioLabel.check();
	}
} */