package playwright5;

import base.primaryTest;
import org.junit.jupiter.api.Test;

import com.microsoft.playwright.Page;


public class PracticeAppsTest extends primaryTest {

    @Test
    void practiceAppsFlowTest() {

    	launchPracticeSite1();

        PracticeAppsPage practicePage = new PracticeAppsPage(page);

        practicePage.openPracticeApps();
        practicePage.openWebAutomationTab();
        practicePage.clickNthStartPracticing(4);

        practicePage.enterName("Bhushan lala");
        page.keyboard().press("Tab");
        practicePage.enterEmail("bhushanyerane@aol.com");

        practicePage.focusVerifyDialog();
        practicePage.enterName("Bhushan");

        // Handle popup
        Page popupPage = practicePage.verifyAndContinue();

        // Assertions on popup
        practicePage.verifyLoginPage(popupPage);
    }
}
