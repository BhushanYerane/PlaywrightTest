package playwright99;

import com.microsoft.playwright.*;
import org.junit.jupiter.api.extension.*;

import java.util.Objects;

/**
 * JUnit 5 Extension that handles Playwright lifecycle: - BeforeAll: launch
 * browser - BeforeEach: create context + page - AfterEach: close page + context
 * - AfterAll: close browser + playwright
 *
 * It also injects Page and BrowserContext via ParameterResolver.
 */
public class PlaywrightExtension
		implements BeforeAllCallback, BeforeEachCallback, AfterEachCallback, AfterAllCallback, ParameterResolver {

	private static class PWState {
		Playwright playwright;
		Browser browser;
		BrowserContext context;
		Page page;
	}

	// Store key to keep state per test container
	private static final String NS = "playwright2.support.PlaywrightExtension";
	private static final String KEY = "PW_STATE";

	@Override
	public void beforeAll(ExtensionContext context) {
		PWState s = new PWState();
		s.playwright = Playwright.create();
		// Use Edge channel headless=true slowMo=100 like your example
		s.browser = s.playwright.chromium()
				.launch(new BrowserType.LaunchOptions().setHeadless(true).setSlowMo(100).setChannel("msedge"));
		getStore(context).put(KEY, s);
		System.out.println("<------- # Start # --------->");
	}

	@Override
	public void beforeEach(ExtensionContext context) {
		PWState s = getState(context);
		s.context = s.browser.newContext();
		s.page = s.context.newPage();
	}

	@Override
	public void afterEach(ExtensionContext context) {
		PWState s = getState(context);
		// Close page first, then context
		if (s.page != null) {
			try {
				s.page.close();
			} catch (Exception ignored) {
			}
			s.page = null;
		}
		if (s.context != null) {
			try {
				s.context.close();
			} catch (Exception ignored) {
			}
			s.context = null;
		}
	}

	@Override
	public void afterAll(ExtensionContext context) {
		PWState s = getState(context);
		if (s.browser != null) {
			try {
				s.browser.close();
			} catch (Exception ignored) {
			}
			s.browser = null;
		}
		if (s.playwright != null) {
			try {
				s.playwright.close();
			} catch (Exception ignored) {
			}
			s.playwright = null;
		}
		System.out.println("<--------- # END # --------->");
		getStore(context).remove(KEY);
	}

	private ExtensionContext.Store getStore(ExtensionContext context) {
		return context.getRoot().getStore(ExtensionContext.Namespace.create(NS));
	}

	private PWState getState(ExtensionContext context) {
		PWState s = (PWState) getStore(context).get(KEY);
		return Objects.requireNonNull(s, "Playwright state not initialized.");
	}

	// --- Parameter Resolution (inject Page or BrowserContext into test methods)
	// ---

	@Override
	public boolean supportsParameter(ParameterContext parameterContext, ExtensionContext extensionContext)
			throws ParameterResolutionException {
		Class<?> type = parameterContext.getParameter().getType();
		return type.equals(Page.class) || type.equals(BrowserContext.class) || type.equals(Browser.class);
	}

	@Override
	public Object resolveParameter(ParameterContext parameterContext, ExtensionContext extensionContext)
			throws ParameterResolutionException {
		PWState s = getState(extensionContext);
		Class<?> type = parameterContext.getParameter().getType();
		if (type.equals(Page.class)) {
			return s.page;
		} else if (type.equals(BrowserContext.class)) {
			return s.context;
		} else if (type.equals(Browser.class)) {
			return s.browser;
		}
		throw new ParameterResolutionException("Unsupported parameter type: " + type);
	}
}
