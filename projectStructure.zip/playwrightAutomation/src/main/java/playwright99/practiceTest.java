package playwright99;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.ExtendWith;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;

@ExtendWith(PlaywrightExtension.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS) // optional, not required with extension
public class practiceTest {

    // Example test using injected Page
    @Test
    void webInputs(Page page) {
        page.navigate("https://practice.expandtesting.com/");
        System.out.println("Title = " + page.title());
        System.out.println("URL   = " + page.url());
        PlaywrightAssertions.assertThat(page)
                .hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");

        page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Web inputs")).click();
        System.out.println("New URL   = " + page.url());
    }

    //@Test
    void clickMenu(Page page) {
        page.navigate("https://practice.expandtesting.com/");
        PlaywrightAssertions.assertThat(page)
                .hasTitle("Automation Testing Practice Website for QA and Developers | UI and API");

        PlaywrightAssertions.assertThat(page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("SUT")))
                .isVisible();
        PlaywrightAssertions.assertThat(page.locator("#main-title"))
                .containsText("Automation Testing Practice WebSite for QA and Developers");

        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
        page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Examples")).click();
        PlaywrightAssertions.assertThat(
                page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Sample applications for")))
                .isVisible();

        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
        page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Apps")).click();
        PlaywrightAssertions.assertThat(
                page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Apps for Automation Testing")))
                .isVisible();

        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
        page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("APIs")).click();
        PlaywrightAssertions.assertThat(
                page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("REST APIs for Automation Test ")))
                .isVisible();

        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
        page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Assertions")).click();
        PlaywrightAssertions.assertThat(
                page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Assertions for Automation Testing")))
                .isVisible();

        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Demos")).click();
        page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Reports")).first().click();
        PlaywrightAssertions.assertThat(
                page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Reports Examples")))
                .isVisible();

        page.mouse().up();
        assertThat(page.locator("#main-navbar")).containsText("Free ISTQB Mock Exams");
        assertThat(page.getByRole(AriaRole.TEXTBOX, new Page.GetByRoleOptions().setName("Search an example...")))
                .isVisible();
        page.getByPlaceholder("Search an example...").fill("LalaJI");
    }

    //@Test
    void canSearchOnBing(Page page) {
        page.navigate("https://www.bing.com");
        page.getByLabel("Enter your search term").click();
        page.keyboard().type("Playwright Java JUnit 5");
        page.keyboard().press("Enter");

        Locator results = page.locator("#b_results");
        results.waitFor();
        Assertions.assertTrue(results.count() > 0, "Search results should be visible");
    }

    //@Test
    void opensExampleAndChecksTitle(Page page) {
        page.navigate("https://jqueryui.com/");
        String title = page.title();
        Assertions.assertTrue(title.toLowerCase().contains("example"),
                "Expected title to contain 'example' but was: " + title);
    }
}
