package org.TestDemo;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.PlaywrightException;
import com.microsoft.playwright.options.AriaRole;

public class TestExample099 {
  public static void main(String[] args) {
    System.out.println("Hello user! This is TestExample099 of Playwright with Java without JUnit.");
    System.out.println("-->---------#-Start-#---------<--");

    // Choose your email domain here:
    final String EMAIL_DOMAIN = "networks19.com"; // or "network19.co.net"

    try (Playwright pw = Playwright.create()) {
      Browser browser = pw.chromium().launch(
          new BrowserType.LaunchOptions()
              .setChannel("msedge")    // use Edge if installed; else remove channel
              .setHeadless(false)      // show the browser; set true for CI
              .setSlowMo(50)           // slow down for demo
      );

      BrowserContext context = browser.newContext();
      Page page = context.newPage();

      // --- Generate data via Faker helpers ---
      FakerDataUtil.UserData user = FakerDataUtil.generateUserData(EMAIL_DOMAIN);
      System.out.println("Full name  - " + user.fullName);
      System.out.println("Email      - " + user.email);
      System.out.println("Password   - " + user.password);

      // --- Navigate & open Signup ---
      page.navigate("https://freelance-learn-automation.vercel.app/login");

      // More robust: use accessible role-based locator for the link
      page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("New user? Signup")).click();

      // Assert submit is initially disabled
      assertThat(page.locator("button.submit-btn")).isDisabled();

      // --- Fill the form ---
      // Name
      page.locator("input[name='name']").fill(user.fullName);

      // Email
      page.locator("input[type='email']").fill(user.email);

      // Password
      page.getByPlaceholder("Password").fill(user.password);

      // Skills checkboxes — prefer label-based locators for clarity
      // If labels don't work on this page, you can fall back to the XPath you had.
      try {
        page.getByLabel("Java").check();
        page.getByLabel("Selenium").check();
        page.getByLabel("Playwright").check();

        assertThat(page.getByLabel("Java")).isChecked();
        assertThat(page.getByLabel("Selenium")).isChecked();
        assertThat(page.getByLabel("Playwright")).isChecked();
      } catch (PlaywrightException e) {
        // Fallback to original XPath pattern if labels aren’t associated correctly
        page.locator("//label[text()='Java']/preceding::input[1]").check();
        assertThat(page.locator("//label[text()='Java']/preceding::input[1]")).isChecked();

        page.locator("//label[text()='Selenium']/preceding::input[1]").check();
        assertThat(page.locator("//label[text()='Selenium']/preceding::input[1]")).isChecked();

        page.locator("//label[text()='Playwright']/preceding::input[1]").check();
        assertThat(page.locator("//label[text()='Playwright']/preceding::input[1]")).isChecked();
      }

      // Gender radio
      try {
        page.getByLabel("Female").check();
        assertThat(page.getByLabel("Female")).isChecked();
      } catch (PlaywrightException e) {
        page.locator("input[type='radio'][value='Female']").check();
        assertThat(page.locator("input[type='radio'][value='Female']")).isChecked();
      }

      // State select
      page.locator("select#state").selectOption("Maharashtra");

      // Hobbies multi-select
      page.locator("select#hobbies").selectOption(new String[]{"Reading", "Swimming"});

      // Submit enabled now
      assertThat(page.locator("button.submit-btn")).isEnabled();

      // Submit form
      page.locator("button.submit-btn").click();

      // --- Success assertion ---
      Locator successMsg = page.getByText("Signup successfully, Please login!");
      assertThat(successMsg).isVisible();
      System.out.println(successMsg.textContent());

      // Optional: wait for URL or navigate back to login if site redirects/state changes
      // page.waitForURL("**/login");

      // Cleanup (context will close when exiting try-with-resources or explicitly)
      page.close();
      context.close();
      browser.close();
    } catch (Exception ex) {
      System.err.println("Script failed: " + ex.getMessage());
      ex.printStackTrace();
      System.exit(1);
    }

    System.out.println("-->#####---END---#####<--");
  }
}
