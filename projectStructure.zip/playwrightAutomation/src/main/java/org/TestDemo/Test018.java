package org.TestDemo;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Test018 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test018 of Playwright with Java for Timeout ");
		Playwright pw18 = null;
		Browser browser18 = null;
		BrowserContext context18 = null;
		Page page18 = null;
		System.out.println("-->---------#-Start-#---------<--");
		
		pw18 = Playwright.create();
		browser18 = pw18.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(true).setSlowMo(50));
		context18 = browser18.newContext();
		page18 = context18.newPage();

		page18.navigate("https://freelance-learn-automation.vercel.app/login", new Page.NavigateOptions().setTimeout(60000));
		page18.getByText("New11").click();
		
		
		
		System.out.println("-->#####---END---#####<--");
		testUtilities.closeResources(page18, context18, browser18, pw18);
	}
}
