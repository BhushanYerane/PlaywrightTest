package org.TestDemo;

import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.*;

public class Test000 {
    public static void main(String[] args) {
        System.out.println("Hello user! This is Test000: Playwright Java Launch all sites.");
        System.out.println("-->---------#-Start-#---------<--");

        String browserName = "chromium"; // Options: "chromium", "firefox", "webkit"
        boolean headlessOption = false;  // true or false

        Playwright playwright = null;
        Browser browser = null;
        Page page = null;

        try {
            playwright = Playwright.create();

            // Launch browser based on browserName
            BrowserType.LaunchOptions options = new BrowserType.LaunchOptions().setHeadless(headlessOption);
            switch (browserName.toLowerCase()) {
                case "firefox":
                    browser = playwright.firefox().launch(options);
                    break;
                case "webkit":
                    browser = playwright.webkit().launch(options);
                    break;
                default:
                    browser = playwright.chromium().launch(options);
            }

            page = browser.newPage();

            // List of URLs
            String[] urls = {
                "https://en.wikipedia.org/wiki/Wikipedia",
                "https://gorest.co.in/",
                "https://demo.automationtesting.in/Index.html",
                "https://dotesthere.com/",
                "https://practice.expandtesting.com/"
            };

            for (String rawUrl : urls) {
                String url = rawUrl.trim();
                System.out.println("\nNavigating to: " + url);

                Response response = page.navigate(url);
                page.waitForLoadState();

                // Log HTTP status
                if (response != null) {
                    System.out.println("Status: " + response.status() + " " + response.statusText());
                }

                // Get and log title
                String title = page.title();
                System.out.println("Title: " + title);

                System.out.println("✅ Successfully loaded: " + url);
            }

            // Example action: Click Login on gorest.co.in
            System.out.println("\nPerforming extra step on gorest.co.in...");
            page.navigate("https://gorest.co.in/");
            page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Login")).click();
            page.waitForLoadState();
            System.out.println("Login page title: " + page.title());

            System.out.println("\n-->#####---END---#####<--");

        } catch (Exception e) {
            System.err.println("Error occurred: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (page != null) page.close();
            if (browser != null) browser.close();
            if (playwright != null) playwright.close();
        }
    }
}

