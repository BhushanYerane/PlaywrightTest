package org.TestDemo;

import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page.ScreenshotOptions;
import com.microsoft.playwright.Playwright;
import java.nio.file.Paths;
import com.microsoft.playwright.*;

public class Test001 {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws InterruptedException 
	{
		System.out.println("Hello user! This is Test001 of Playwright with Java for taking Screenshot.");
		System.out.println("-->---------#-Start-#---------<--");
		
		String browserName = "chromium"; // Options: "chromium", "firefox", "webkit"
		boolean headlessOption = false; // Options: "true", "false"
		String baseURL = "https://practice.expandtesting.com/";
		String customeFilePath = "C:\\Users\\byerane\\OneDrive - Capgemini\\Desktop\\screenshots\\TestDeomz";
		
		Playwright pw1 = Playwright.create();
		Browser browser = pw1.chromium().launch(new BrowserType.LaunchOptions().setHeadless(headlessOption)); //setSlowMo(50).setTimeout(90));
		Page page1 = browser.newPage();
		page1.navigate(baseURL);
		System.out.println(page1.title());
		ScreenshotOptions screenshotOptions = new ScreenshotOptions();
		screenshotOptions.setPath(Paths.get(customeFilePath + "\\Test01_HomePage.png"));
		
		
		System.out.println("-->#####---END---#####<--");
        Thread.sleep(2500);
        page1.close();
        browser.close();
        pw1.close();
		
	}
}
