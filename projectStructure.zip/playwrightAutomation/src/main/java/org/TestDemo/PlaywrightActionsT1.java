package org.TestDemo;

import com.microsoft.playwright.*;

public class PlaywrightActionsT1 implements AutoCloseable 
{
  private final Playwright playwright;
  private final Browser browser;

  public PlaywrightActionsT1()
  {
    playwright = Playwright.create();
    browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(true));
  }

  private static class ContextPage implements AutoCloseable 
  {
    final BrowserContext context;
    final Page page;
    ContextPage(Browser browser) 
    {
      context = browser.newContext();
      page = context.newPage();
    }
    @Override
    public void close() 
    {
      context.close();
    }
  }

  public void shouldClickButton() 
  {
    try (ContextPage cp = new ContextPage(browser)) 
    {
      cp.page.navigate("data:text/html,<script>var result;</script><button onclick='result=\"Clicked\"'>Go</button>");
      cp.page.locator("button").click();
      String result = cp.page.evaluate("result").toString();
      if (!"Clicked".equals(result)) {
        throw new RuntimeException("Expected 'Clicked', got: " + result);
      }
      System.out.println("[OK] shouldClickButton -> " + result);
    }
  }

  public void shouldCheckTheBox() 
  {
    try (ContextPage cp = new ContextPage(browser)) {
      cp.page.setContent("<input id='checkbox' type='checkbox'></input>");
      cp.page.locator("input#checkbox").check();
      Boolean checked = (Boolean) cp.page.evaluate("() => window['checkbox'].checked");
      if (!Boolean.TRUE.equals(checked)) {
        throw new RuntimeException("Expected checkbox to be checked, got: " + checked);
      }
      System.out.println("[OK] shouldCheckTheBox -> checked=" + checked);
    }
  }

  public void shouldSearchWiki() {
    try (ContextPage cp = new ContextPage(browser)) {
      cp.page.navigate("https://www.wikipedia.org/");
      cp.page.locator("input[name='search']").click();
      cp.page.locator("input[name='search']").fill("Playwright (software)");
      cp.page.keyboard().press("Enter");

      // Wait for navigation & confirm via heading and URL
      cp.page.waitForURL("**/Playwright_(software)");

      // Prefer unique heading id on Wikipedia
      Locator heading = cp.page.locator("#firstHeading");
      heading.waitFor();
      String headingText = heading.innerText();
      if (!"Playwright (software)".equals(headingText)) {
        throw new RuntimeException("Expected heading 'Playwright (software)', got: " + headingText);
      }

      String url = cp.page.url();
      if (!"https://en.wikipedia.org/wiki/Playwright_(software)".equals(url)) {
        throw new RuntimeException("Expected URL https://en.wikipedia.org/wiki/Playwright_(software), got: " + url);
      }
      System.out.println("[OK] shouldSearchWiki -> " + url);
    }
  }

  public void shouldReturnInnerHTML() {
    try (ContextPage cp = new ContextPage(browser)) {
      cp.page.setContent("<div>hello</div>");
      String html = cp.page.innerHTML("div");
      if (!"hello".equals(html)) {
        throw new RuntimeException("Expected 'hello', got: " + html);
      }
      System.out.println("[OK] shouldReturnInnerHTML -> " + html);
    }
  }

  public void shouldClickButtonPopup() {
    try (ContextPage cp = new ContextPage(browser)) {
      Page popup = cp.page.waitForPopup(() -> {
        cp.page.evaluate("window.open('about:blank');");
      });
      String url = popup.url();
      if (!"about:blank".equals(url)) {
        throw new RuntimeException("Expected popup URL 'about:blank', got: " + url);
      }
      System.out.println("[OK] shouldClickButtonPopup -> " + url);
    }
  }

  @Override
  public void close() {
    // Close Playwright and browser
    browser.close();
    playwright.close();
  }
}
