package org.TestDemo;

import java.util.regex.Pattern;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public class Test003 {

	public static void main(String[] args) {
		System.out.println("Hello user! This is Test003 of Playwright with Java for loacators");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw3 = null;
		Browser browser3 = null;
		BrowserContext context3 = null;
		Page page3 = null;
		try {
			pw3 = Playwright.create();
			browser3 = pw3.chromium()
					.launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false).setSlowMo(500));
//		Browser broswer3 = Playwright.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false).setSlowMo(50));
			context3 = browser3.newContext();
			page3 = context3.newPage();
			
			// page3.navigate("https://gorest.co.in/");
			// System.out.println(page3.title());

			/** from other site -- https://freelance-learn-automation.vercel.app/login */
			
			page3.navigate("https://freelance-learn-automation.vercel.app/login");
			System.out.println(page3.title());
			PlaywrightAssertions.assertThat(page3).hasTitle("Learn Automation Courses");
			//page3.locator("#email1").fill("admin@email.com");
			//page3.locator("xpath=//input[@name='email1']").fill("admin@email.com");
			//page3.locator("css=input[name='email1']").fill("admin@email.com");
			page3.getByPlaceholder("Enter Email").fill("admin@email.com");
			page3.locator("input[type='password']").fill("admin@123");
			page3.getByText("Sign in").nth(1).click();
			//page3.locator("button[class='submit-btn']").click();
			
			//PlaywrightAssertions.assertThat(page3.locator(".welcomeMessage")).containsText("Welcome");
			page3.getByAltText("menu").click();
			page3.getByText("Sign out").click();
			PlaywrightAssertions.assertThat(page3).hasURL(Pattern.compile(".*login"));
							
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			System.out.println("-->#####---END---#####<--");
			page3.close();
			browser3.close();
			pw3.close();
		}
	}
}
