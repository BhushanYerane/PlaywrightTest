package org.TestDemo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Download;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.AriaRole;

public class Test017 {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws InterruptedException, IOException {
		System.out.println("Hello user! This is Test017 of Playwright with Java for file downloading.");
		Playwright pw17 = null;
		Browser browser17 = null;
		BrowserContext context17 = null;
		final Page page17;
		System.out.println("-->---------#-Start-#---------<--");

		pw17 = Playwright.create();
		browser17 = pw17.chromium()
				.launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(true).setSlowMo(10));
		context17 = browser17.newContext();
		page17 = context17.newPage();

		page17.navigate("https://the-internet.herokuapp.com/");
		page17.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("File Download")).nth(0).click();
		
		Download download = page17.waitForDownload(() -> {
			page17.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("testfile.txt")).click();
		});
		
		String downloadedFilePath = System.getProperty("user.dir") + "\\captureSS\\filesdownloaded\\"+download.suggestedFilename();
		System.out.println("File downloaded at path: " + downloadedFilePath);
		System.out.println(download.suggestedFilename());
		System.out.println(download.url());
		System.out.println(download.path());
		
		download.saveAs(Paths.get(downloadedFilePath));
		if(downloadedFilePath.endsWith(".txt"))
		{
			System.out.println("File Extension is .txt and Verified");
		} else {
			System.out.println("File Extension is not Verified");
			browser17.close();
			return;
		}
		
		if(Files.size(Paths.get(downloadedFilePath))>0)
		{
			System.out.println("File size is greater than 0 bytes and Verified");
		} else {
			System.out.println("File size is not greater than 0 bytes and Not Verified");
			browser17.close();
			return;
		}

		String datafromfile = new String(Files.readAllBytes(Paths.get(downloadedFilePath)));
		
		
		System.out.println("-->#####---END---#####<--");
		testUtilities.closeResources(page17, context17, browser17, pw17);
	}

}
