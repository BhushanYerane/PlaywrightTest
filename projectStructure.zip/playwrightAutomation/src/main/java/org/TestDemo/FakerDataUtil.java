package org.TestDemo;

import com.github.javafaker.Faker;

import java.text.Normalizer;
import java.util.Locale;
import java.util.Random;

public final class FakerDataUtil {
	@SuppressWarnings("deprecation")
	private static final Faker faker = new Faker(new Locale("en")); // or new Locale("en-IND")
	private static final Random random = new Random();

	public static String generateFullName() {
		return faker.name().fullName(); // e.g., "BabaJI Modi"
	}

	public static String buildEmailFromName(String fullName, String domain) {
		String cleaned = removeDiacritics(fullName).trim().replaceAll("\\s+", " ");
		String[] parts = cleaned.split(" ");
		String first = sanitize(parts[0]);
		String last = (parts.length > 1) ? sanitize(parts[parts.length - 1]) : first;

		// Optional: collapse repeats like "BabaJI" -> "babji"
		first = collapseRepeats(first);
		last = collapseRepeats(last);

		int suffix = 10 + random.nextInt(90); // 10–99
		String localPart = String.format("%s_%s%d", first.toLowerCase(Locale.ROOT), last.toLowerCase(Locale.ROOT),
				suffix);
		return localPart + "@" + domain;
	}

	public static String buildPasswordLikePattern() {
		String base = sanitize(faker.hacker().noun()); // e.g., "protocol", "system", "network"
		if (base == null || base.isEmpty())
			base = "network";
		int number = 100 + random.nextInt(900); // 100–999
		char symbol = pickSymbol(); // one of ! @ # $ % & *
		return String.format("%s@%d%s", base.toLowerCase(Locale.ROOT), number, symbol);
	}

	public static UserData generateUserData(String domain) {
		String fullName = generateFullName();
		return new UserData(fullName, buildEmailFromName(fullName, domain), buildPasswordLikePattern());
	}

	// --- helpers ---
	private static String removeDiacritics(String s) {
		String nfd = Normalizer.normalize(s, Normalizer.Form.NFD);
		return nfd.replaceAll("\\p{M}", "");
	}

	private static String sanitize(String s) {
		return s == null ? "" : s.replaceAll("[^A-Za-z0-9]", "");
	}

	private static String collapseRepeats(String s) {
		return s.replaceAll("(.)\\1+", "$1");
	}

	private static char pickSymbol() {
		char[] symbols = new char[] { '!', '@', '#', '$', '%', '&', '*' };
		return symbols[random.nextInt(symbols.length)];
	}

	/** Simple DTO for user data */
	public static class UserData {
		public final String fullName;
		public final String email;
		public final String password;

		public UserData(String fullName, String email, String password) {
			this.fullName = fullName;
			this.email = email;
			this.password = password;
		}

		@Override
		public String toString() {
			return "UserData{fullName='" + fullName + "', email='" + email + "', password='" + password + "'}";
		}
	}
}
