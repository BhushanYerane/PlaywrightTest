package org.TestDemo; // handle autosuggetion or auto complete dropdowns

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Test006 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test006 of Playwright with Java");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw6 = null;
		Browser browser6 = null;
		BrowserContext context6 = null;
		Page page6 = null;
		
		pw6 = Playwright.create();
		browser6 = pw6.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false).setSlowMo(3000));
		context6 = browser6.newContext();
		page6 = context6.newPage();
		
		page6.navigate("https://www.google.com/");
		page6.locator("//textarea[@title='Search']").fill("mukesh otwani ");
		Locator locator6 = page6.locator("xpath=//ul[@role='listbox']/li");
		int count6 = locator6.count();
		System.out.println("Total Autosuggetion found: "+count6);
		for(int i=0; i<count6; i++)
		{
			// String test6 = locator6.nth(i).textContent();   // it gives all text including hidden text
			String test6 = locator6.nth(i).innerText();      // it gives only visible text
			//System.out.println("Autosuggetion "+i+" : "+test6);
			if(test6.contains("playwright"))
			{
				locator6.nth(i).click();
				break;
			}
		}
		
		page6.navigate("https://www.wikipedia.org/");
		
		
		System.out.println("-->#####---END---#####<--");
		Thread.sleep(3000);
		//page6.close();
		//browser6.close();
		//pw6.close();

	}
}
