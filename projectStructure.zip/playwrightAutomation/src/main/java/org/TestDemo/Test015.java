package org.TestDemo;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.FrameLocator;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.Tracing;

public class Test015 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test015 of Playwright with Java for handling shadow DOM");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw15 = null;
		Browser browser15 = null;
		BrowserContext context15 = null;
		final Page page15;

		pw15 = Playwright.create();
		browser15 = pw15.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false).setSlowMo(100));
		context15 = browser15.newContext();
		context15.tracing().start(new Tracing.StartOptions().setScreenshots(true).setSnapshots(true).setSources(true));
		page15 = context15.newPage();
		
		page15.navigate("https://jqueryui.com/slider/");
		FrameLocator frameloc1 = page15.frameLocator(".demo-frame");
		Locator slideloc = frameloc1.locator("//span[contains(@class,'ui-slider-handle')]");
		
		for(int i=0;i<11;i++)
		{
			slideloc.press("ArrowRight");
			Thread.sleep(200);
		}
		for(int i=0;i<6;i++)
		{
			slideloc.press("ArrowLeft");
			Thread.sleep(200);
		}
		
	    System.out.println("-->#####---END---#####<--");
		testUtilities.closeResources(page15, context15, browser15, pw15);
	}

}
