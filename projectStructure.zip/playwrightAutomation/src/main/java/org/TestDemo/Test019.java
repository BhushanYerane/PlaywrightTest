package org.TestDemo;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.Browser.NewContextOptions;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Test019 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test019 of Playwright with Java for SSL Certificate Error Handling ");
		Playwright pw19 = null;
		Browser browser19 = null;
		BrowserContext context19 = null;
		Page page19 = null;
		System.out.println("-->---------#-Start-#---------<--");
		
		NewContextOptions contextoption= new Browser.NewContextOptions();
		contextoption.setIgnoreHTTPSErrors(true);
		
		pw19 = Playwright.create();
		browser19 = pw19.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(true).setSlowMo(50));
		context19 = browser19.newContext();
		page19 = context19.newPage();

		page19.navigate("https://expired.badssl.com/", new Page.NavigateOptions().setTimeout(60000));
		
		System.out.println("-->#####---END---#####<--");
		testUtilities.closeResources(page19, context19, browser19, pw19);
	}
}
