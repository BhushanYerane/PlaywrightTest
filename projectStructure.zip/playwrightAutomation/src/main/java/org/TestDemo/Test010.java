package org.TestDemo;

import java.util.regex.Pattern;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Frame;
import com.microsoft.playwright.FrameLocator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;

public class Test010 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test010 of Playwright with Java for handling iFrames");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw10 = null;
		Browser browser10 = null;
		BrowserContext context10 = null;
		final Page page10;

		pw10 = Playwright.create();
		browser10 = pw10.chromium()
				.launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(true).setSlowMo(1000));
		context10 = browser10.newContext();
		page10 = context10.newPage();
		 
		page10.navigate("https://practice.expandtesting.com/");
		page10.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("IFrame")).click();
		PlaywrightAssertions.assertThat(page10.locator("//h1[contains(text(),'IFrame page for Automation')]")).isVisible();
		int iframecount = page10.locator("iframe").count();
		//System.out.println("Total iFrame:- "+iframecount);
		
		// 1
		Frame iframe1 = page10.frameByUrl(Pattern.compile("/iframe-email-subscribe"));
		iframe1.locator("//input[@type='email']").fill("bhushan@gmail.com");
		iframe1.locator("#btn-subscribe").click();
		//page.frameLocator("#email-subscribe").getByRole(AriaRole.BUTTON, new FrameLocator.GetByRoleOptions().setName("Subscribe")).click();
		
		//String successmsg = page10.locator("#success-message").innerText();
		//PlaywrightAssertions.assertThat(page10.locator("#success-message")).containsText(successmsg);
		//assertThat(page.frameLocator("#email-subscribe").locator("#success-message")).containsText("You are now subscribed!");
		
		// 2
		FrameLocator frame2 = page10.frameLocator("#iframe-youtube");
		frame2.getByLabel("Play", new FrameLocator.GetByLabelOptions().setExact(true)).click();
		
		// 3
		page10.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("External IFrame: TinyMCE")).click();
		PlaywrightAssertions.assertThat(page10.frameLocator("iframe[title=\"Rich Text Area\"]").locator("html")).containsText("Your content goes here.");
		PlaywrightAssertions.assertThat(page10.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("External IFrame: TinyMCE"))).isVisible();
		page10.frameLocator("iframe[title=\"Rich Text Area\"]").locator("html").click();
		page10.frameLocator("iframe[title=\"Rich Text Area\"]").locator("html").fill("Laala Ji");
		
		System.out.println("-->#####---END---#####<--");
		testUtilities.closeResources(page10, context10, browser10, pw10);
	}

}
