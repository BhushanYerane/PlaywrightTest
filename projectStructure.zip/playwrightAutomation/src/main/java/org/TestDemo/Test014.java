package org.TestDemo;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.Tracing;

public class Test014 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test014 of Playwright with Java for handling shadow DOM");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw14 = null;
		Browser browser14 = null;
		BrowserContext context14 = null;
		final Page page14;

		pw14 = Playwright.create();
		browser14 = pw14.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(true).setSlowMo(100));
		context14 = browser14.newContext();
		context14.tracing().start(new Tracing.StartOptions().setScreenshots(true).setSnapshots(true).setSources(true));
		page14 = context14.newPage();
		
		page14.navigate("https://freelance-learn-automation.vercel.app/login");
		
		assertThat(page14.locator("h1")).containsText("Learn Automation Courses");
	    assertThat(page14.locator("form")).containsText("Sign In");
	    assertThat(page14.locator("#login_container")).containsText("Connect with us");
	  
	    page14.getByPlaceholder("Enter Email").fill("admin@email.com");
	    
	    page14.getByPlaceholder("Enter Password").fill("admin@123");
	    
	    // Selecting all text using keyboard actions
	    page14.keyboard().down("Control");
	    page14.keyboard().press("a");
	    page14.keyboard().up("Control");
	    
	    // copying the selected text using keyboard actions
	    page14.keyboard().down("Control");
	    page14.keyboard().press("a");
	    page14.keyboard().up("Control");
	    
	    page14.keyboard().press("Tab");
	    
	    // pasting the copied text using keyboard actions
	    page14.keyboard().down("Control");
	    page14.keyboard().press("v");
	    page14.keyboard().up("Control");
	    
	    System.out.println("-->#####---END---#####<--");
		testUtilities.closeResources(page14, context14, browser14, pw14);
	}

}
