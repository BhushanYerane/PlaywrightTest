package org.TestDemo;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.Tracing;
import com.microsoft.playwright.options.AriaRole;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;

import java.nio.file.Paths;
import java.util.regex.Pattern;

public class Test013 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test013 of Playwright with Java for handling shadow DOM");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw13 = null;
		Browser browser13 = null;
		BrowserContext context13 = null;
		final Page page13;

		pw13 = Playwright.create();
		browser13 = pw13.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(true).setSlowMo(100));
		context13 = browser13.newContext();
		context13.tracing().start(new Tracing.StartOptions().setScreenshots(true).setSnapshots(true).setSources(true));
		page13 = context13.newPage();
		
		page13.navigate("https://freelance-learn-automation.vercel.app/login");
		
		assertThat(page13.locator("h1")).containsText("Learn Automation Courses");
	    assertThat(page13.locator("form")).containsText("Sign In");
	    assertThat(page13.locator("#login_container")).containsText("Connect with us");
	    
	    page13.getByPlaceholder("Enter Email").click();
	    page13.getByPlaceholder("Enter Email").fill("admin@email.com");
	    page13.getByPlaceholder("Enter Email").press("Tab");
	    page13.getByPlaceholder("Enter Password").fill("admin@123");
	    page13.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Sign in")).click();
	    
	    assertThat(page13.locator("h4")).containsText("Welcome Admin Manager to Learn Automation Courses");
	    
	    page13.getByRole(AriaRole.IMG, new Page.GetByRoleOptions().setName("menu")).click();
	    assertThat(page13.getByRole(AriaRole.NAVIGATION)).containsText("Sign out");
	   
	    page13.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Sign out")).click();
	    
	    assertThat(page13).hasURL(Pattern.compile(".*login"));
	    assertThat(page13.getByRole(AriaRole.IMG, new Page.GetByRoleOptions().setName("Login"))).isVisible();
		
		System.out.println("-->#####---END---#####<--");
		context13.tracing().stop(new Tracing.StopOptions().setPath(Paths.get("trace-Test013.zip")));
		testUtilities.closeResources(page13, context13, browser13, pw13);
	}
}
