package org.TestDemo;

import org.junit.jupiter.api.Assertions;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.assertions.PlaywrightAssertions;
import com.microsoft.playwright.options.AriaRole;

public class Test008 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test008 of Playwright with Java for file upload handling.");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw8 = null;
		Browser browser8 = null;
		BrowserContext context8 = null;
		Page page8 = null;

		pw8 = Playwright.create();
		browser8 = pw8.chromium()
				.launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(true).setSlowMo(1000));
		context8 = browser8.newContext();
		page8 = context8.newPage();

		page8.navigate("https://the-internet.herokuapp.com/");
		page8.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("A/B Testing")).click();
		page8.goBack();
		page8.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Add/Remove Elements")).click();
		page8.goBack();
		page8.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("JavaScript Alerts")).click();

		// Alert: accept (or dismiss) once, no global onDialog
		page8.onceDialog(dialog -> {
			System.out.println("Dialog (alert) message: " + dialog.message());
			dialog.accept(); // alerts usually accepted; dismiss also okay if you want
		});
		page8.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Click for JS Alert")).click();

		// Confirm: dismiss (or accept) once
		page8.onceDialog(dialog -> {
			System.out.println("Dialog (confirm) message: " + dialog.message());
			dialog.dismiss(); // choose dismiss to simulate "Cancel"; use accept() for "OK"
		});
		page8.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Click for JS Confirm")).click();

		// Prompt: accept with input text
		page8.onceDialog(dialog -> {
			System.out.println("Dialog (prompt) message: " + dialog.message());
			dialog.accept("Bhushan"); // IMPORTANT: provide the text here
		});
		page8.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Click for JS Prompt")).click();

		// Assertion for prompt result
		PlaywrightAssertions.assertThat(page8.locator("#result")).containsText("You entered: Bhushan");

		System.out.println("----->-----------<-----");
		page8.navigate("https://the-internet.herokuapp.com/javascript_alerts");
		
		// --- JS Alert ---
		page8.onceDialog(dialog -> {
		  String msg = dialog.message();
		  System.out.println("Alert message: " + msg);
		  Assertions.assertTrue(msg.contains("I am a JS Alert"));
		  dialog.accept(); // IMPORTANT: handle the alert
		});
		page8.locator("//button[text()='Click for JS Alert']").click();
		PlaywrightAssertions.assertThat(page8.locator("#result")).hasText("You successfully clicked an alert");
		
		// --- JS Confirm ---
		page8.onceDialog(dialog -> {
		  String msg = dialog.message();
		  System.out.println("Confirm message: " + msg);
		  Assertions.assertTrue(msg.contains("I am a JS Confirm"));
		  dialog.dismiss(); // or dialog.accept(); depends on the behavior you want
		});
		page8.locator("//button[text()='Click for JS Confirm']").click();
		PlaywrightAssertions.assertThat(page8.locator("#result")).hasText("You clicked: Cancel"); // if dismiss()
		// PlaywrightAssertions.assertThat(page8.locator("#result")).hasText("You clicked: Ok");  // If you used accept() above, assert:
		
		// --- JS Prompt ---
		page8.onceDialog(dialog -> {
		  String msg = dialog.message();
		  System.out.println("Prompt message: " + msg);
		  Assertions.assertTrue(msg.contains("I am a JS prompt"));
		  dialog.accept("Bhushan"); // Provide input text to the prompt
		});
		page8.locator("//button[text()='Click for JS Prompt']").click();
		PlaywrightAssertions.assertThat(page8.locator("#result")).hasText("You entered: Bhushan");

		
		
		System.out.println("-->#####---END---#####<--");
		Thread.sleep(1358);
		page8.close();
		browser8.close();
		pw8.close();
	}

}
