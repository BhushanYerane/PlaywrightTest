package org.TestDemo;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.LoadState;

public class Test009 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test009 of Playwright with Java for handling tabs/windows.");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw9 = null;
		Browser browser9 = null;
		BrowserContext context9 = null;
		final Page page9;

		pw9 = Playwright.create();
		browser9 = pw9.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(true).setSlowMo(1000));
		context9 = browser9.newContext();
		page9 = context9.newPage();
		 
		page9.navigate("https://practice.expandtesting.com/windows");
		Page newpage1 = context9.waitForPage(() -> 
		{
			page9.locator("//a[contains(@href,'/windows/')]").click();
		});

		newpage1.waitForLoadState(LoadState.DOMCONTENTLOADED);

		newpage1.locator("//h1[contains(text(),'window page for Automation')]").isVisible();
		page9.bringToFront();
		newpage1.bringToFront();
		
		page9.bringToFront();
		newpage1.bringToFront();
		
		newpage1.close();
		System.out.println("-->#####---END---#####<--");
		Thread.sleep(1358);
		page9.close();
		browser9.close();
		pw9.close();
	}

}
