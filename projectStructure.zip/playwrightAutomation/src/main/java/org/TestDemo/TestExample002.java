package org.TestDemo;

import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URI;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class TestExample002 {
	
	public static void main(String[] args) throws ProtocolException, InterruptedException {
		
		System.out.println("Hello user! This is TestExample002 of Playwright with Java - Form Validation and Link Checking");
		System.out.println("-->---------#-Start-#---------<--");
		
		
		Playwright playwright = Playwright.create();
		Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
		BrowserContext context = browser.newContext();
        Page page = context.newPage();
        
        page.navigate("file:///C:/Users/byerane/Downloads/Backup/Skills/PlayWright/playwrightAutomation/src/main/resources/automation_test_page.html");
        page.click("button[type='submit']");
        System.out.println("Validation message for empty fields: " + page.locator("#nameError").textContent());

        page.fill("#name", "John Doe");
        page.fill("#email", "invalid-email");
        page.click("button[type='submit']");
        System.out.println("Validation message for invalid email: " + page.locator("#emailError").textContent());
        
        page.fill("#email", "john.doe@example.com");
        page.check("#male");
        page.check("#coding");
        page.selectOption("#country", "USA");
        page.selectOption("#skills", new String[]{"Python", "Java"});
        page.click("button[type='submit']");
        Locator links = page.locator(".links a");
        int count = links.count();
        for (int i = 0; i < count; i++) 
        {
            String href = links.nth(i).getAttribute("href");
            System.out.println("Found link: " + href);
            try {
            	URI uri = URI.create(href);
                HttpURLConnection connection = (HttpURLConnection) uri.toURL().openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                int code = connection.getResponseCode();
                System.out.println("Status: " + code);
            } catch (Exception e) {
                System.out.println("Error checking link: " + href);
            }
        } 
        System.out.println("-->#####---END---#####<--");
        Thread.sleep(2500);
        browser.close();
        playwright.close();
	}
}

