package org.TestDemo;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class TestExample001 {

	static Playwright pw3;
	static Browser browser3;

	BrowserContext context3;
	Page page3;

	@BeforeAll
	static void launchBrowser() {
		System.out.println("Hello user! This is TestExample001 of Playwright with Java and JUnit5.");
		System.out.println("-->---------#-Start-#---------<--");
		
		pw3 = Playwright.create();
		browser3 = pw3.chromium().launch(new BrowserType.LaunchOptions().setSlowMo(50).setHeadless(false));
	}

	@AfterAll
	static void closeBrowser() {
		System.out.println("-->#####---END---#####<--");
		pw3.close();
	}

	@BeforeEach
	public void createContextAndPage() {
		context3 = browser3.newContext();
		page3 = context3.newPage();
	}

	@AfterEach
	public void closeContext() {
		context3.close();
	}

	@Test
	public void searchWiki()
	{
		page3.navigate("https://www.wikipedia.org/");
		page3.locator("//input[@id='searchInput']").click();
		page3.locator("//input[@id='searchInput']").fill("Playwright (software)");
		page3.locator("//input[@id='searchInput']").press("Enter");
		

		// Wait for navigation implicitly via assertions
		assertThat(page3.locator("#firstHeading")).hasText("Playwright (software)");

		// Prefer Playwright Assertions over raw JUnit where possible
		assertThat(page3).hasTitle("Playwright (software) - Wikipedia");
		assertThat(page3).hasURL("https://en.wikipedia.org/wiki/Playwright_(software)");
	}
	
	@Test
	public void checkTheBox()
	{
		page3.setContent("<input id='checkbox' type='checkbox'></input>");
		page3.locator("#checkbox").check();
		assertTrue(page3.locator("#checkbox").isChecked());
		assertTrue((Boolean) page3.evaluate("() => document.getElementById('checkbox').checked") );
		assertTrue((Boolean) page3.evaluate("() => window['checkbox'].checked"));
	}
	
	@Test
	  void shouldClickButton() {
	    page3.navigate("data:text/html,<script>var result;</script><button onclick='result=\"Clicked\"'>Go</button>");
	    page3.locator("button").click();
	    assertEquals("Clicked", page3.evaluate("result"));
	  }
}
