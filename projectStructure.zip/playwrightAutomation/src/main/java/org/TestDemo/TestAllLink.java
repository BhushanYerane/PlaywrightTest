package org.TestDemo;


import com.microsoft.playwright.*;
import com.microsoft.playwright.options.LoadState;

import java.util.List;

public class TestAllLink {
    public static void main(String[] args) {
        try (Playwright playwright = Playwright.create()) {
            Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions()
                    .setHeadless(false)); // set true for headless mode
            BrowserContext context = browser.newContext();
            Page page = context.newPage();

            // Navigate to the page
            page.navigate("https://the-internet.herokuapp.com/");

            // Get all <a> elements inside the main content
            List<ElementHandle> links = page.querySelectorAll("div#content a");

            System.out.println("Total links found: " + links.size());
            System.out.println("---- Links on the page ----");

            for (ElementHandle link : links) {
                String text = link.innerText();
                String href = link.getAttribute("href");
                System.out.println("Text: " + text + " | Href: " + href);
            }

            // OPTIONAL: Click each link, verify title, then go back
            for (ElementHandle link : links) {
                String text = link.innerText();
                String href = link.getAttribute("href");
                System.out.println("\nNavigating to: " + text + " (" + href + ")");
                link.click();
                page.waitForLoadState(LoadState.DOMCONTENTLOADED);
                System.out.println("Page title: " + page.title());
                page.goBack();
                page.waitForLoadState(LoadState.DOMCONTENTLOADED);
            }

            browser.close();
        }
    }
}
