package org.TestDemo;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.AriaRole;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;

public class CodegenT001 {

	public static void main(String[] args) {
		Browser browser = null;
		BrowserContext context = null;
		Page page = null;
		try (
				Playwright playwright = Playwright.create()) 
		{
			System.out.println("Hello user! This is CodegenT001 of Playwright with Java");
			System.out.println("-->---------#-Start-#---------<--");
			
			browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
			context = browser.newContext();
			page = context.newPage();
			page.navigate("https://freelance-learn-automation.vercel.app/login");
			page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Sign In")).click();
			
			assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Connect with us")))
					.isVisible();
			assertThat(page.locator("form")).containsText("Sign In");
			assertThat(page.locator("form")).containsText("New user? Signup");
			assertThat(page.locator("h1")).containsText("Learn Automation Courses");
			
			page.getByPlaceholder("Enter Email").click();
			page.getByPlaceholder("Enter Email").fill("admin@email.com");
			page.getByPlaceholder("Enter Email").press("Tab");
			page.getByPlaceholder("Enter Password").fill("admin@123");
			
			assertThat(page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Sign in"))).isVisible();
			page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Sign in")).click();
			
			assertThat(
					page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Welcome Admin Manager to")))
					.isVisible();
			
			page.getByRole(AriaRole.IMG, new Page.GetByRoleOptions().setName("menu")).click();
			page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Sign out")).click();
			
			assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Sign In"))).isVisible();
		}
		
		System.out.println("-->#####---END---#####<--");
		page.close();
		browser.close();
	}
}
