package org.TestDemo;

import java.nio.file.Path;
import java.nio.file.Paths; // added import

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public class Test007 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test007 of Playwright with Java for file upload");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw7 = null;
		Browser browser7 = null;
		BrowserContext context7 = null;
		Page page7 = null;
		
		pw7 = Playwright.create();
		browser7 = pw7.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false).setSlowMo(3000));
		context7 = browser7.newContext();
		page7 = context7.newPage();
		
		page7.navigate("https://the-internet.herokuapp.com/upload");
		PlaywrightAssertions.assertThat(page7.locator("h3")).hasText("File Uploader");
		page7.locator("#file-upload").setInputFiles(Paths.get(System.getProperty("user.dir")+"/src/main/resources/filesUpload/build.gradle"));

		Path []files = { Paths.get(System.getProperty("user.dir")+"/src/main/resources/filesUpload/build.gradle"),
	//					 Paths.get(System.getProperty("user.dir")+"/src/main/resources/filesUpload/secret.key"),
	//					 Paths.get(System.getProperty("user.dir")+"/src/main/resources/filesUpload/twoFile.jfif")
				};
		
		page7.locator("#file-upload").setInputFiles(files);
		
		page7.locator("#file-upload").setInputFiles(new Path[] {
				Paths.get(System.getProperty("user.dir")+"/src/main/resources/filesUpload/twoFile.jfif")
		});
		
		Thread.sleep(2000);
		page7.locator("#file-upload").setInputFiles(new Path[0]); // to clear selected files
		
		page7.reload();
		
		// add file to upload using FileChooser
		//FileChooser filechooser7 = page7.waitForFileChooser(()-> page7.locator("#drag-drop-upload").click());
		//filechooser7.setFiles(Paths.get(System.getProperty("user.dir")+"/src/main/resources/filesUpload/build.gradle"));

		System.out.println("-->#####---END---#####<--");
		Thread.sleep(1000);
		page7.close();
		browser7.close();
		pw7.close();

	}
}
