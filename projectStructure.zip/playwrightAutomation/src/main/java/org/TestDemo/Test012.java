package org.TestDemo;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class Test012 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test012 of Playwright with Java for handling shadow DOM");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw12 = null;
		Browser browser12 = null;
		BrowserContext context12 = null;
		final Page page12;

		pw12 = Playwright.create();
		browser12 = pw12.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false).setSlowMo(1200));
		context12 = browser12.newContext();
		//browser12.newContext(new Browser.NewContextOptions().setRecordVideoSize(500,500).setRecordVideoDir(Paths.get("videoz/")));
		page12 = context12.newPage();
		
		page12.navigate("https://www.msn.com/en-in/");
		//byte[] arr1 =  page12.screenshot(new Page.ScreenshotOptions().setFullPage(true).setPath(Paths.get("C:\\Users\\byerane\\OneDrive - Capgemini\\Desktop\\screenshots\\TestDeomz\\Test012-HomePage.png")));
		testUtilities.captureScreenshot(page12); // calling the static method from screenshotUtilities class
		
		System.out.println("-->#####---END---#####<--");
		testUtilities.closeResources(page12, context12, browser12, pw12); // calling the static method from screenshotUtilities class
	}
}
