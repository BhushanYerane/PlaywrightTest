package org.TestDemo;

import java.util.regex.Pattern;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;
import com.microsoft.playwright.*;
import com.microsoft.playwright.options.AriaRole;

public class Test002 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test002 of Playwright with Java for launching browser and navigating to a URL.");
		System.out.println("-->---------#-Start-#---------<--");
		
		Playwright pw2 = Playwright.create();
		Browser browser2 = pw2.chromium().launch();//new BrowserType.LaunchOptions().setHeadless(true));
		BrowserContext context2 = browser2.newContext();
		Page page2 = context2.newPage();
		
		//page2.navigate("https://deepotsav.lokmat.com/");
		page2.navigate("https://playwright.dev");
		System.out.println(page2.title());
		
		assertThat(page2).hasTitle(Pattern.compile("Playwright"));
	//	Locator getStarted = page2.locator("text=Get Started");

		Locator getStarted = page2.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Get Started"));
		assertThat(getStarted).hasAttribute("href", "/docs/intro");
		getStarted.click();
		assertThat(page2.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Installation"))).isVisible();
		
		
		System.out.println("-->#####---END---#####<--");
        Thread.sleep(2500);
        page2.close();
        browser2.close();
        pw2.close();
	}
}
