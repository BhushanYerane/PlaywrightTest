package org.TestDemo;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.FrameLocator;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.Tracing;

public class Test016 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test016 of Playwright with Java for handling shadow DOM");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw16 = null;
		Browser browser16 = null;
		BrowserContext context16 = null;
		final Page page16;

		pw16 = Playwright.create();
		browser16 = pw16.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false).setSlowMo(100));
		context16 = browser16.newContext();
		context16.tracing().start(new Tracing.StartOptions().setScreenshots(true).setSnapshots(true).setSources(true));
		page16 = context16.newPage();
		
		page16.navigate("https://jqueryui.com/droppable/");
		FrameLocator frameloc1 = page16.frameLocator(".demo-frame");
		//frameloc1.locator("#draggable").dragTo(frameloc1.locator("#droppable"));
		
		frameloc1.locator("#draggable").hover();
		page16.mouse().down();
		frameloc1.locator("#droppable").hover();
		page16.mouse().up();
		
	    System.out.println("-->#####---END---#####<--");
		testUtilities.closeResources(page16, context16, browser16, pw16);
		
		// if we are not dealing with frame then the code will be as below:
		//page16.locator("#draggable").dragTo(page16.locator("#droppable"));
	}

}
