package org.TestDemo;

import com.github.javafaker.Faker;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public class Test004 {

	public static void main(String[] args) {
		System.out.println("Hello user! This is Test004 of Playwright with Java");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw4 = null;
		Browser browser4 = null;
		BrowserContext context4 = null;
		Page page4 = null;
		

		Faker faker = new Faker();
        String name = faker.name().fullName();
        String email = faker.name().firstName().toLowerCase()+ faker.name().lastName().toLowerCase() + faker.hashCode() + "@networks19.com";
        String password = faker.internet().password(8, 11);

		pw4 = Playwright.create();
		browser4 = pw4.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false).setSlowMo(50));
		context4 = browser4.newContext();
		page4 = context4.newPage();

		page4.navigate("https://freelance-learn-automation.vercel.app/login");
		page4.getByText("New user? Signup").click();
		PlaywrightAssertions.assertThat(page4.locator("button.submit-btn")).isDisabled();
		
		page4.locator("xpath=//input[@name='name']").fill(name);
		//page4.locator("input[type='email']").fill("lalaji123@outlook.co.in");
		//page4.locator("input[type='email']").fill("lalaji123_"+System.currentTimeMillis()+"@outlook.co.in");
		page4.locator("input[type='email']").fill(email);
		page4.getByPlaceholder("Password").fill(password);
		
		page4.locator("xpath=//label[text()='Java']//preceding::input[1]").check();
		//page4.getByText("Java").click();
		PlaywrightAssertions.assertThat(page4.locator("xpath=//label[text()='Java']//preceding::input[1]")).isChecked();
		page4.locator("xpath=//label[text()='Selenium']//preceding::input[1]").check();
		PlaywrightAssertions.assertThat(page4.locator("xpath=//label[text()='Selenium']//preceding::input[1]")).isChecked();
		page4.locator("xpath=//label[text()='Playwright']//preceding::input[1]").click();
		PlaywrightAssertions.assertThat(page4.locator("xpath=//label[text()='Playwright']//preceding::input[1]")).isChecked();
		
		page4.locator("xpath=//input[@value='Female']").click();
		PlaywrightAssertions.assertThat(page4.locator("xpath=//input[@value='Female']")).isChecked();
		
		page4.locator("select#state").selectOption("Maharashtra");
		String hobbies[] = {"Reading","Swimming"};
		page4.locator("select#hobbies").selectOption(hobbies);
		
		PlaywrightAssertions.assertThat(page4.locator("button.submit-btn")).isEnabled();
		page4.locator("button.submit-btn").click();
		
		page4.getByText("Signup successfully, Please login!");
		PlaywrightAssertions.assertThat(page4.getByText("Signup successfully, Please login!")).isVisible();
		System.out.println(page4.getByText("Signup successfully, Please login!").textContent());
		
		
		System.out.println("-->#####---END---#####<--");
		page4.close();
		browser4.close();
		pw4.close();
	}
}
