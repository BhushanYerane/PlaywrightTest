package org.TestDemo;

import java.util.regex.Pattern;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public class Test005 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test005 of Playwright with Java");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw5 = null;
		Browser browser5 = null;
		BrowserContext context5 = null;
		Page page5 = null;
		
		pw5 = Playwright.create();
		browser5 = pw5.chromium().launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(true).setSlowMo(50));
		context5 = browser5.newContext();
		page5 = context5.newPage();
		
		page5.navigate("https://freelance-learn-automation.vercel.app/login");
		page5.locator("button.submit-btn").click();
		
		String ExpectedMSG = "Email and Password is required";
		String loginMSG1 = page5.locator("h2.errorMessage").textContent();
		PlaywrightAssertions.assertThat(page5.locator("h2.errorMessage")).hasText(ExpectedMSG);
		PlaywrightAssertions.assertThat(page5.locator("h2.errorMessage")).containsText("and Password is");
		PlaywrightAssertions.assertThat(page5.locator("h2.errorMessage")).containsText(Pattern.compile("required"));
		
		System.out.println("Login Error Message: "+loginMSG1);
		
		//String loginMSG2 = page5.locator("h2.errorMessage").innerText();
		//System.out.println("Login Error Message: "+loginMSG2);
		
		System.out.println("-->#####---END---#####<--");
		Thread.sleep(3000);
		page5.close();
		browser5.close();
		pw5.close();

	}
}
