package org.TestDemo.parallelTest;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import com.microsoft.playwright.*;

public class threadLocalDemoTest {

	private static ThreadLocal<Playwright> tlPlaywright = new ThreadLocal<>();
	private static ThreadLocal<Browser> tlBrowser = new ThreadLocal<>();
	private static ThreadLocal<BrowserContext> tlBrowserContext = new ThreadLocal<>();
	private static ThreadLocal<Page> tlPage = new ThreadLocal<>();

	// ---------- GETTERS ----------
	protected Playwright getPlaywright() {
		return tlPlaywright.get();
	}

	protected Browser getBrowser() {
		return tlBrowser.get();
	}

	protected BrowserContext getBrowserContext() {
		return tlBrowserContext.get();
	}

	protected Page getPage() {
		return tlPage.get();
	}

	// ---------- SETUP ----------
	@BeforeEach
	public void setUp() {
		Playwright playwright = Playwright.create();
		tlPlaywright.set(playwright);

		Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions()
							.setHeadless(true).setChannel("msedge").setSlowMo(750));
		tlBrowser.set(browser);

		BrowserContext context = browser.newContext();
		tlBrowserContext.set(context);

		Page page = context.newPage();
		tlPage.set(page);
	}

	// ---------- TEARDOWN ----------
	@AfterEach
	public void tearDown() {
		tlPage.get().close();
		tlBrowserContext.get().close();
		tlBrowser.get().close();
		tlPlaywright.get().close();

		tlPage.remove();
		tlBrowserContext.remove();
		tlBrowser.remove();
		tlPlaywright.remove();
	}
}