package org.TestDemo.parallelTest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

//@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class ParallelUrlTest extends threadLocalDemoTest {

    @Test
    void launchDotesthere() {
        getPage().navigate("https://dotesthere.com/");
        System.out.println("Launched dotesthere - " + Thread.currentThread().getName());
    }

    @Test
    void launchDemoQA() {
        getPage().navigate("https://demoqa.com/");
        System.out.println("Launched demoqa - " + Thread.currentThread().getName());
    }

    @Test
    void launchExpandTesting() {
        getPage().navigate("https://practice.expandtesting.com/");
        System.out.println("Launched expandtesting - " + Thread.currentThread().getName());
    }

    @Test
    void launchUiPathSwagger() {
        getPage().navigate("https://uibank-api.uipath.com/explorer/swagger.json");
        System.out.println("Launched uipath swagger - " + Thread.currentThread().getName());
    }
}