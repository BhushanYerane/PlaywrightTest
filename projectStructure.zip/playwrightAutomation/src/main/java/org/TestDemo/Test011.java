package org.TestDemo;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.assertions.PlaywrightAssertions;

public class Test011 {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Hello user! This is Test011 of Playwright with Java for handling shadow DOM");
		System.out.println("-->---------#-Start-#---------<--");
		Playwright pw11 = null;
		Browser browser11 = null;
		BrowserContext context11 = null;
		final Page page11;

		pw11 = Playwright.create();
		browser11 = pw11.chromium()
				.launch(new BrowserType.LaunchOptions().setChannel("msedge").setHeadless(false).setSlowMo(1100));
		context11 = browser11.newContext();
		page11 = context11.newPage();

		page11.navigate("https://selectorshub.com/xpath-practice-page/");
		page11.evaluate("document.querySelector('input[title=\"Email\"]').removeAttribute('readonly')");
		page11.locator("input[title='Email']").fill("bhushan19@network.in");
		PlaywrightAssertions.assertThat(page11.getByPlaceholder("Enter Email")).isVisible();

		Locator shadowRoot = page11.locator("div#userName");
		shadowRoot.locator("input#kils").fill("Bhushan19");
		
		
		System.out.println("-->#####---END---#####<--");
		testUtilities.closeResources(page11, context11, browser11, pw11);
	}
}
