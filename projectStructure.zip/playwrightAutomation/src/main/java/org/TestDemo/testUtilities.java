package org.TestDemo;

import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class testUtilities {
	
	public static byte[] captureScreenshot(Page page) 
	{
		SimpleDateFormat customDate = new SimpleDateFormat("ddMMyyyy_HHmmss");
		Date date1 = new Date();
		String newdate = customDate.format(date1);
		byte[] arr1 = page.screenshot(new Page.ScreenshotOptions().setFullPage(true).setPath(Paths.get("captureSS/"+"Screenshot_"+newdate+".png")));
		return arr1;
	}
	
	public static void closeResources(Page page, BrowserContext context, Browser browser, Playwright pw) throws InterruptedException 
	{
		Thread.sleep(1358);
		page.close();
		context.close();
		browser.close();
		pw.close();	
	}
}
