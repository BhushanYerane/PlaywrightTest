package org.TestDemo;

public class ActionsRunnerT1 
{
	public static void main(String[] args) 
	{
		PlaywrightActionsT1 actions = new PlaywrightActionsT1();
		System.out.println("Reference of PlaywrightActionsT1 class created successfully.");
		actions.shouldClickButton();
		actions.shouldCheckTheBox();
		actions.shouldSearchWiki();
		actions.shouldReturnInnerHTML();
		actions.shouldClickButtonPopup();
		System.out.println("All actions completed successfully.");
		
		actions.close();
	}
}
