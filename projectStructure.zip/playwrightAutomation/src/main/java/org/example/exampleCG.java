package org.example;
import java.util.regex.Pattern;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;
import com.microsoft.playwright.options.AriaRole;
import com.microsoft.playwright.options.MouseButton;

public class exampleCG {
    public static void main(String[] args) {
        try (Playwright playwright1 = Playwright.create()) {
            Browser browser1 = playwright1.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
            BrowserContext context1 = browser1.newContext();
            Page page1 = context1.newPage();
            page1.navigate("https://demo.playwright.dev/todomvc/");
            page1.locator("html").click();
            page1.navigate("https://www.google.com/search?q=capgemini&oq=capgemini&gs_lcrp=EgZjaHJvbWUyBggAEEUYOdIBCDQzMTRqMGo0qAIAsAIA&sourceid=chrome&ie=UTF-8");
            page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Capgemini - Get The Future")).click();
            page1.getByLabel("Insights menu").click();
            page1.getByLabel("Expert perspectives menu").click();
            page1.getByLabel("Services menu").click();
            page1.getByLabel("Cybersecurity menu").click();
            page1.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Cybersecurity").setExact(true)).click();
            page1.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Cybersecurity").setExact(true)).click(new Locator.ClickOptions().setButton(MouseButton.RIGHT));
            page1.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Cybersecurity").setExact(true)).click();
            page1.locator("a").filter(new Locator.FilterOptions().setHasText("Get in touch")).click();
            page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("close").setExact(true)).click();
            page1.getByLabel("Careers menu").click();
            page1.getByPlaceholder("Search for your future role...").click();
            page1.getByPlaceholder("Search for your future role...").fill("QA");
            page1.getByRole(AriaRole.FORM, new Page.GetByRoleOptions().setName("opens in a new window")).getByRole(AriaRole.BUTTON).click();
            page1.locator("#job_search_list div").filter(new Locator.FilterOptions().setHasText(Pattern.compile("^Country$"))).nth(1).click();
            page1.locator("#react-select-2-option-14").click();
            page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Performance Architect | 6 to")).click();
            page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Apply now")).nth(1).click();
            page1.navigate("https://career5.successfactors.eu/careers?company=C0001123183P");
            page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Show")).click();
            page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Hide")).click();
            page1.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Sign In")).click();
            page1.getByText("An email address is required.").click();
            page1.getByText("A password is required.").dblclick();
        }
    }
}