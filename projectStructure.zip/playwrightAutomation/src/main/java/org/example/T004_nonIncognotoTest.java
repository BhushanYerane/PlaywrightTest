package org.example;

import com.microsoft.playwright.*;

import java.nio.file.Paths;

public class T004_nonIncognotoTest {
    public static void main(String[] args) {
        Playwright playwright = Playwright.create();

        //Browser browser1 = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false).setChannel("chrome"));
        //BrowserContext browserContext1 = playwright.chromium().launchPersistentContext(Paths.get(""),new BrowserType.LaunchPersistentContextOptions().setHeadless(false));
        //BrowserContext browserContext1 = playwright.chromium().launchPersistentContext(Paths.get(""),new BrowserType.LaunchPersistentContextOptions().setHeadless(false).setExecutablePath(Paths.get("C:\\\\Program Files (x86)\\\\Microsoft\\\\Edge\\\\Application\\\\msedge.exe")));
        BrowserContext browserContext1 = playwright.chromium().launchPersistentContext(Paths.get(""),new BrowserType.LaunchPersistentContextOptions().setHeadless(false).setChannel("msedge"));

        //Page page1 = browser1.newPage();
        Page page1 = browserContext1.newPage();
        page1.navigate("http://www.outlooktraveller.com/");

        page1.close();
        playwright.close();
    }
}
