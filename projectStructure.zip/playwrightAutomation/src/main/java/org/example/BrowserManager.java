package org.example;

import com.microsoft.playwright.*;

public class BrowserManager {
    private static Playwright playwright;
    private static Browser browser;
    private static BrowserContext context;
    private static Page page;

    /** it is sample base method to launch browser
     * and use in DemoTest00***.java classes for tests
     * @return void
     * @author Bhushan
     * @date 2025-11-29
     *  */
    
    public static void launchBrowser() {
        playwright = Playwright.create();
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setSlowMo(1000).setHeadless(true));
        context = browser.newContext();
        page = context.newPage();
        System.out.println("-->---------#-Start-#---------<--");
    }

    public static Page getPage() {
        return page;
    }

    public static void closeBrowser() {
    	System.out.println("-->#####---END---#####<--");
    	context.close();
        browser.close();
        playwright.close();
    }
}
