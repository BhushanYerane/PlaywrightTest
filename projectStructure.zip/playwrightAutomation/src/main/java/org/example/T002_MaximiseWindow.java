package org.example;

import com.microsoft.playwright.*;

import java.util.ArrayList;

public class T002_MaximiseWindow {
     public static void main(String [] args) throws InterruptedException {

         Playwright playwright1 = Playwright.create();
         ArrayList<String> arguments = new ArrayList<String>();
         arguments.add("---start-maximised--");
         BrowserType chromium = playwright1.chromium();
         Browser browser1 = chromium.launch(new BrowserType.LaunchOptions().setChannel("chrome").setHeadless(false).setArgs(arguments));
         BrowserContext bowsercontext1 = browser1.newContext(new Browser.NewContextOptions().setViewportSize(null));
         Page page = bowsercontext1.newPage();

         page.navigate("http://www.outlookmoney.com");
         page.title();
         System.out.println(page.title());
         Thread.sleep(3000);
         page.close();
         playwright1.close();

     }
}
