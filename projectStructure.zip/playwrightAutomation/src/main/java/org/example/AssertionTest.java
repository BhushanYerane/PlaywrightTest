package org.example;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.AriaRole;

import java.util.regex.Pattern;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class AssertionTest {

    public static void main(String [] args) throws InterruptedException {

        Playwright playwright1 = Playwright.create();
        //Browser browser1 = playwright1.chromium().launch(new BrowserType.LaunchOptions().setChannel("chrome").setHeadless(false));
        //Page page1 = browser1.newPage();

        Browser browser1 = playwright1.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
        BrowserContext context1 = browser1.newContext();
        Page page1 = context1.newPage();

        page1.navigate("https://playwright.dev/java/");
        page1.title();
        //page1.getByAltText(assertThat(page1.getByLabel()));

        assertThat(page1).hasTitle(Pattern.compile("Playwright Java"));
        Locator getStarted = page1.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Get Started"));
        assertThat(getStarted).hasAttribute("href", "/java/docs/intro");

        getStarted.click();
        assertThat(page1.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Installation"))).isVisible();

        Thread.sleep(10505);
        page1.close();
        playwright1.close();

    }
}
