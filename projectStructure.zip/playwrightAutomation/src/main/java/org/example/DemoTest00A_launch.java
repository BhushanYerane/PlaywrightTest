package org.example;

import org.junit.jupiter.api.*;
import com.microsoft.playwright.Page;
//import org.example.BrowserManager; (if in other package)

public class DemoTest00A_launch {

	@BeforeAll
	public static void setUp() {
		BrowserManager.launchBrowser();
	}

	@Test
	public void testLaunchSite() {
		Page page = BrowserManager.getPage();
		page.navigate("https://dotesthere.com/");
		//Assertions.assertTrue(page.title().contains("Do Test Here"), "Free Automation Testing Practice");
		System.out.println("Page Title: " + page.title());
	}
	
	

	@AfterAll
	public static void tearDown() {
		BrowserManager.closeBrowser();
	}
}
