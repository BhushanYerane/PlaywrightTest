package org.example;

import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

import java.nio.file.Paths;

public class nevigationTest {
    public static void main(String[] args) throws InterruptedException {
        Playwright playwright = Playwright.create();

        BrowserContext browserContext1 = playwright.chromium().launchPersistentContext(Paths.get(""),new BrowserType.LaunchPersistentContextOptions().setHeadless(false).setChannel("chrome"));
        Page page1 = browserContext1.newPage();
        page1.navigate("http://www.outlooktraveller.com/");
        System.out.println(page1.title());
        page1.reload();
        Thread.sleep(1500);

        page1.navigate("http://www.outlookmoney.com/");
        System.out.println(page1.title());

        //page1.goBack();
        page1.goBack(new Page.GoBackOptions().setTimeout(500));
        Thread.sleep(1500);

        page1.goForward(new Page.GoForwardOptions().setTimeout(500));

        //page1.goForward();
        //page1.goForward(new Page.GoForwardOptions().setWaitUntil(2000));
        //page1.goBack(new Page.GoBackOptions().setWaitUntil(500));
        page1.close();
        playwright.close();
    }
}
