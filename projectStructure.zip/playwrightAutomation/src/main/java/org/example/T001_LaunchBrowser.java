package org.example;

import com.microsoft.playwright.*;
import java.awt.*;

public class T001_LaunchBrowser {

// Lunch Browser
    /*public static void main(String[] args) {
        Playwright playwright = Playwright.create();
//        Browser browser = playwright.chromium().launch();
        Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));

        Page page = browser.newPage();
        page.navigate("http://playwright.dev");
        System.out.println(page.title());
        page.close();
        playwright.close();
    }*/

    // Maximise Windows
    public static void main(String[] args) throws InterruptedException {

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        double width = screenSize.getWidth();
        double height = screenSize.getHeight();
        System.out.println(width + "---" + height);

        Playwright playwright = Playwright.create();
        BrowserType chromium = playwright.chromium();
        Browser browser = chromium.launch(new BrowserType.LaunchOptions().setHeadless(false));
//        Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
        BrowserContext browserContext = browser.newContext(new Browser.NewContextOptions().setViewportSize((int) width, (int) height));
        Page page = browserContext.newPage();
        page.navigate("https://practice.expandtesting.com/inputs");
        System.out.println(page.title());
        Thread.sleep(2500);
        page.close();
        playwright.close();
    }
}
