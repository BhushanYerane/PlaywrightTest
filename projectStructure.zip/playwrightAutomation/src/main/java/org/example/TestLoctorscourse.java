package org.example;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class TestLoctorscourse{
    @SuppressWarnings("deprecation")
	public static void main(String [] args){
        Playwright playwright = Playwright.create();
        Browser browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false).setChannel("chrome"));
        Page page = browser.newPage();
        page.navigate("http://www.gmail.com");

        //page.locator("#identifierId").type("trainer@way2automation.com");
        //page.locator("[id='identifierId']").type("trainer@way2automation.com");
        page.fill("id=identifierId", "trainer@way2automation.com");
        //page.locator().pressSequentially();
        //page.locator().pressSequentially(new );
        //page.locator().press();
        page.locator("[type=email]").type("trainer@way2automation.com");
        //page.click("text=Next");
        page.click("button:has-text('Next')");
        page.locator("[type=password]").fill("sdfsdfdsf");
        page.click("button:has-text('Next')");

        System.out.println(page.locator("//*[@id=\"view_container\"]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[1]/div[2]/div[2]/span").innerText());

        page.close();
        playwright.close();

    }
}
