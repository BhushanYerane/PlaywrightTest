package org.example;

import java.awt.Dimension;
import java.awt.Toolkit;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class T003_LaunchBrowser {
    public static void main(String[] args){

        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        double width = screenSize.getWidth();
        double height = screenSize.getHeight();
        System.out.println(width + "---" + height);

        Playwright playwright1 = Playwright.create();
        Browser browser1 = playwright1.chromium().launch(new BrowserType.LaunchOptions().setChannel("chrome").setHeadless(false));
     //   Browser browser1 = playwright1.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false).setExecutablePath(Paths.get("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe")));
     //   browser1 = playwright1.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false).setExecutablePath(Paths.get("C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe")));
        BrowserContext browserContext1 = browser1.newContext(new Browser.NewContextOptions().setViewportSize((int)width,(int)height));

        Page page1 = browserContext1.newPage();
        page1.navigate("https://www.outlookindia.com");
        System.out.println(page1.title());

        page1.close();
        playwright1.close();
    }
}
