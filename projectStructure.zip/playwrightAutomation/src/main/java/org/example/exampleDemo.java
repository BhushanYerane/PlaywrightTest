package org.example;
import com.microsoft.playwright.*;
import com.microsoft.playwright.options.*;
import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

@SuppressWarnings("unused")
public class exampleDemo {
    public static void main(String[] args) {
        try (Playwright playwright1 = Playwright.create()) {
            Browser browser1 = playwright1.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
            BrowserContext context1 = browser1.newContext();
            Page page = context1.newPage();
            page.navigate("https://demo.automationtesting.in/Index.html");
            page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("logo")).click();
            page.getByPlaceholder("First Name").click();
            page.getByPlaceholder("First Name").fill("Bhushan");
            page.getByPlaceholder("First Name").press("Tab");
            page.getByPlaceholder("Last Name").click();
            page.getByPlaceholder("Last Name").fill("yerane");
            page.locator("textarea").click();
            page.locator("textarea").fill("Pune Wadgaon");
            page.locator("input[type=\"email\"]").click();
            page.locator("input[type=\"email\"]").fill("11111@outlook.com");
            page.locator("input[type=\"tel\"]").click();
            page.locator("input[type=\"tel\"]").fill("1234561234");
            page.getByLabel("Male", new Page.GetByLabelOptions().setExact(true)).check();
            page.locator("#checkbox2").check();
            page.locator("#msdd").click();
            page.getByText("Arabic").click();
            page.locator("#msdd").click();
            page.locator("#msdd").click();
            page.getByText("French").click();
            page.getByText("Japanese").click();
            page.getByText("Urdu").click();
            page.getByText("Skills Select Skills Adobe").click();
            page.locator("#Skills").selectOption("Java");
            page.getByLabel("", new Page.GetByLabelOptions().setExact(true)).click();
            page.getByRole(AriaRole.TREEITEM, new Page.GetByRoleOptions().setName("India")).click();
            page.locator("#yearbox").selectOption("1934");
            page.locator("#basicBootstrapForm div").filter(new Locator.FilterOptions().setHasText("Date Of Birth year")).getByRole(AriaRole.COMBOBOX).nth(1).selectOption("December");
            page.locator("#daybox").selectOption("31");
            page.locator("#firstpassword").click();
            page.locator("#firstpassword").fill("QAQA123$");
            page.locator("#secondpassword").click();
            page.locator("#secondpassword").fill("QAQA123$");
            page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Submit")).click();
            page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Submit")).click();
            page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("WebTable")).click();
            page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("First Name")).click();
            page.getByLabel("Email").getByLabel("Column Menu").click();

            page.close();
            playwright1.close();
        }
    }
}