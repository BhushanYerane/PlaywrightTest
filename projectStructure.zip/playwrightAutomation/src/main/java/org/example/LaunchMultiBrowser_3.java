package org.example;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.Playwright;

public class LaunchMultiBrowser_3 {
    public static void main(String[] args) {
        try (Playwright playwright = Playwright.create())
        {
            Browser browser = null;
            String browserName = System.getenv("BROWSER");
            switch (browserName) {
                case "chromium":
                    browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false).setSlowMo(50));
                    break;
                case "firefox":
                    browser = playwright.firefox().launch(new BrowserType.LaunchOptions().setHeadless(false).setSlowMo(50));
                    break;
                case "webkit":
                    browser = playwright.webkit().launch(new BrowserType.LaunchOptions().setHeadless(false).setSlowMo(50));
                    break;
            }
            assert browser != null;
            Page page = browser.newPage();
            page.navigate("https://www.playwright.dev/java/docs/browsers#install-browsers");
            page.navigate("www.google.com");
            page.goBack(new Page.GoBackOptions().setTimeout(250));
            page.goForward(new Page.GoForwardOptions().setTimeout(300));

            page.close();
            playwright.close();
        }
    }
}
