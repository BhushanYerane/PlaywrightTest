package pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.AriaRole;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.*;

public class PracticeHubPage {

  private final Page page;

  // ===========================
  // Common
  // ===========================
  public final Locator headingAutomationTestingPractice;
  public final Locator linkABTesting;
  public final Locator linkAddRemoveElements;

  // ===========================
  // A/B Testing
  // ===========================
  public final Locator abHeading;
  public final Locator versionAHeading;
  public final Locator versionBHeading;
  public final Locator btnSwitchVersion;
  public final Locator btnShowCodeExample;
  public final Locator toastSwitchedToA;
  public final Locator toastSwitchedToB;
  public final Locator toastCodeExampleShown;

  // ===========================
  // Add/Remove Elements
  // ===========================
  public final Locator addRemoveHeading;
  public final Locator btnAddElement;
  public final Locator btnDelete;
  public final Locator toastElementAdded;
  public final Locator toastElementRemoved;

  public PracticeHubPage(Page page) {
    this.page = page;

    // -------- Common --------
    headingAutomationTestingPractice =
        page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Automation Testing Practice"));
    linkABTesting =
        page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("A/B Testing"));
    linkAddRemoveElements =
        page.getByRole(AriaRole.LINK, new Page.GetByRoleOptions().setName("Add/Remove Elements"));

    // -------- A/B Testing --------
    abHeading =
        page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("A/B Testing"));
    versionAHeading =
        page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Version A: Original Content"));
    versionBHeading =
        page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Version B: Alternative Content"));
    btnSwitchVersion =
        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Switch Version"));
    // Keep your current XPath for the code example button (but consider replacing with a better selector if available)
    btnShowCodeExample =
        page.locator("//*[@id='playground']/div[2]/div[1]/div[1]/button");
    toastSwitchedToA = page.getByText("Switched to Version A");
    toastSwitchedToB = page.getByText("Switched to Version B");
    toastCodeExampleShown = page.getByText("Code example shown!");

    // -------- Add/Remove Elements --------
    addRemoveHeading =
        page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Add/Remove Elements"));
    btnAddElement =
        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Add Element"));
    btnDelete =
        page.getByRole(AriaRole.BUTTON, new Page.GetByRoleOptions().setName("Delete"));
    toastElementAdded = page.getByText("Element added! ➕");
    toastElementRemoved = page.getByText("Element removed!");
  }

  // ===========================
  // Common Actions
  // ===========================
  public void assertHomeLoaded() {
    assertThat(page).hasTitle("DoTestHere.com - Free Automation Testing Practice Hub | Selenium, Playwright, API Testing");
    assertThat(headingAutomationTestingPractice).isVisible();
  }

  // ===========================
  // A/B Testing Actions
  // ===========================
  public void openABTesting() {
    linkABTesting.click();
    assertThat(abHeading).isVisible();
  }

  public void showCodeExample() {
    btnShowCodeExample.click();
    assertThat(toastCodeExampleShown).isVisible();
    // optional: verify section headings
    assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Selenium Java"))).isVisible();
    assertThat(page.getByRole(AriaRole.HEADING, new Page.GetByRoleOptions().setName("Playwright Python"))).isVisible();
  }

  public void switchVersionToB() {
    btnSwitchVersion.click();
    assertThat(toastSwitchedToB).isVisible();
    assertThat(versionBHeading).isVisible();
  }

  public void switchVersionToA() {
    btnSwitchVersion.click();
    assertThat(toastSwitchedToA).isVisible();
    assertThat(versionAHeading).isVisible();
  }

  // ===========================
  // Add/Remove Elements Actions
  // ===========================
  public void openAddRemoveElements() {
    linkAddRemoveElements.click();
    assertThat(addRemoveHeading).isVisible();
  }

  public void addElement() {
    btnAddElement.click();
    assertThat(toastElementAdded).isVisible();
    assertThat(btnDelete).isVisible();
  }

  public void deleteElement() {
    btnDelete.click();
    assertThat(toastElementRemoved).isVisible();
  }
}
