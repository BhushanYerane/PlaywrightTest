package utils;

import com.github.javafaker.Faker;

import java.text.Normalizer;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Utility for generating person test data with Java Faker and composing
 * derived fields according to your custom rules.
 *
 * Rules implemented:
 * - firstName: from Faker
 * - surname (lastName): from Faker
 * - username: firstName + firstLetter(surname) + "#!"
 * - email: username + "test@" + {network19.com | abc.xyz}
 * - password: "#" + surname + "AZ" + "19" + "!"
 * - confirmPassword: equals password
 *
 * All outputs are sanitized to be URL/email friendly (lowercase where appropriate).
 */
public final class FakerData {

  private FakerData() {}

  // Thread-safe faker instance per thread
  private static final ThreadLocal<Faker> TL_FAKER = ThreadLocal.withInitial(() -> new Faker(Locale.ENGLISH));
  private static Faker faker() { return TL_FAKER.get(); }

  private static final List<String> EMAIL_DOMAINS = Arrays.asList("network19.com", "abc.xyz");

  /** Container for a fully-generated person record */
  public static final class PersonData {
    public final String firstName;
    public final String surname;
    public final String username;
    public final String email;
    public final String password;
    public final String confirmPassword;

    private PersonData(String firstName, String surname, String username, String email,
                       String password, String confirmPassword) {
      this.firstName = firstName;
      this.surname = surname;
      this.username = username;
      this.email = email;
      this.password = password;
      this.confirmPassword = confirmPassword;
    }

    @Override
    public String toString() {
      return "PersonData{" +
          "firstName='" + firstName + '\'' +
          ", surname='" + surname + '\'' +
          ", username='" + username + '\'' +
          ", email='" + email + '\'' +
          ", password='" + password + '\'' +
          ", confirmPassword='" + confirmPassword + '\'' +
          '}';
    }
  }

  // ---------------------------------------------------------------------
  // Required methods (implemented)
  // ---------------------------------------------------------------------

  public static int randomTwoDigitInt() {
    return faker().number().numberBetween(10, 100); // upper bound is exclusive
  }

  /** Random given name via Faker (sanitized). */
  public static String firstName() {
    String raw = faker().name().firstName();
    return capFirst(stripNonAsciiLetters(raw));
  }

  /** Random surname/last name via Faker (sanitized). */
  public static String surname() {
    String raw = faker().name().lastName();
    return capFirst(stripNonAsciiLetters(raw));
  }

  /**
   * Username = firstName + firstLetterOfSurname + "01"
   * Example: "mukesh" + "o" + "" => "mukesho01"
   * Returns lowercase, ASCII-safe.
   */
  public static String username(String firstName, String surname) {
    String fn = stripNonAlnum(firstName).toLowerCase(Locale.ROOT);
    String sn = stripNonAlnum(surname).toLowerCase(Locale.ROOT);
    int num = randomTwoDigitInt();
    String initial = sn.isEmpty() ? "01" : sn.substring(0, 1);
    return fn + initial + num;
  }

  /**
   * Email = username + "test@" + oneOf(network19.com, abc.xyz)
   * Example: "mukesho#!" -> "mukesho#!test@network19.com"
   * Note: removes illegal email chars from username part before composing.
   */
  public static String email(String username) {
    String domain = EMAIL_DOMAINS.get(ThreadLocalRandom.current().nextInt(EMAIL_DOMAINS.size()));
    String localPart = sanitizeEmailLocal(username + ".test"); // strict local-part
    return localPart + "@" + domain;
  }

  /**
   * Password = "#" + surname + "AZ" + "19" + "!"
   * Example: surname="Otwni" => "#OtwniAZ19!"
   * Keeps original surname case for readability; you can force to lower if needed.
   */
  public static String password(String surname) {
    String sn = stripSpaces(surname); // keep letters as-is
    return "#" + sn + "AZ" + "19" + "!";
  }

  /** Confirm password equals password. */
  public static String confirmPassword(String password) {
    return password;
  }

  /**
   * Build a complete person using the defined rules.
   * Returns a PersonData DTO with all fields.
   */
  public static PersonData buildPerson() {
    String fn = firstName();
    String sn = surname();
    String user = username(fn, sn);
    String mail = email(user);
    String pass = password(sn);
    String confirm = confirmPassword(pass);
    return new PersonData(fn, sn, user, mail, pass, confirm);
  }

  // ---------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------

  /** Remove accents, keep only letters (A-Z, a-z). */
  private static String stripNonAsciiLetters(String input) {
    if (input == null) return "";
    String n = Normalizer.normalize(input, Normalizer.Form.NFD)
        .replaceAll("\\p{M}", ""); // strip diacritics
    return n.replaceAll("[^A-Za-z]", "");
  }

  /** Keep only letters and digits; drop everything else. */
  private static String stripNonAlnum(String input) {
    if (input == null) return "";
    String n = Normalizer.normalize(input, Normalizer.Form.NFD)
        .replaceAll("\\p{M}", "");
    return n.replaceAll("[^A-Za-z0-9]", "");
  }

  /** Remove spaces only (useful for passwords per rule). */
  private static String stripSpaces(String s) {
    return s == null ? "" : s.replace(" ", "");
  }

  /** Capitalize first letter, lowercase the rest. */
  private static String capFirst(String s) {
    if (s == null || s.isEmpty()) return "";
    if (s.length() == 1) return s.substring(0, 1).toUpperCase(Locale.ROOT);
    return s.substring(0, 1).toUpperCase(Locale.ROOT) + s.substring(1).toLowerCase(Locale.ROOT);
  }

  /** Sanitize email local-part (RFC-ish light): letters, digits, and . _ + - only. */
  private static String sanitizeEmailLocal(String s) {
    if (s == null) return "";
    String n = stripNonAlnum(s); // start strict, then allow a few symbols
    // Rebuild allowing ".", "_", "+", "-"
    // Since we stripped all non-alnum above, add nothing else for now (keeps it safe).
    return n.toLowerCase(Locale.ROOT);
  }

  // ---------------------------------------------------------------------
  // Future additions (method name only + TODO)
  // Throwing UnsupportedOperationException to keep compilation safe.
  // ---------------------------------------------------------------------

  /** TODO: middle name if needed later. */
  public static String middleName() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: title (Mr/Ms/Dr). */
  public static String title() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: phone number (mobile). */
  public static String phone() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: address line 1. */
  public static String addressLine1() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: address line 2. */
  public static String addressLine2() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: city. */
  public static String city() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: state/province. */
  public static String state() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: postal/zip code. */
  public static String postalCode() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: country. */
  public static String country() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: date of birth (ISO-8601). */
  public static String dateOfBirth() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: gender (M/F/Other). */
  public static String gender() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: company. */
  public static String company() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: job title. */
  public static String jobTitle() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: national id (e.g., PAN/Aadhaar masking rules). */
  public static String nationalId() {
    throw new UnsupportedOperationException("Not implemented yet");
  }

  /** TODO: optional random domain selector if you want wider pool later. */
  public static String randomEmailDomain() {
    throw new UnsupportedOperationException("Not implemented yet");
  }
  
  // random 3-digit, random PIN, random age
}
