package utils;

import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public final class RunCSVLogger {
  private static final Object LOCK = new Object();
  private static volatile boolean headerWritten = false;
  private static Path csvPath;
  private static String runTimestamp;

  private RunCSVLogger() {}

  public static void init(Path reportDir, String filenamePrefix) {
    synchronized (LOCK) {
      try {
        Files.createDirectories(reportDir);
        runTimestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        csvPath = reportDir.resolve(filenamePrefix + "_" + runTimestamp + ".csv");
        if (!headerWritten) {
          Files.writeString(csvPath, "timestamp,url,title,status,notes\n",
              StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
          headerWritten = true;
        }
      } catch (Exception e) {
        System.err.println("CSV init error: " + e.getMessage());
      }
    }
  }

  public static void append(String url, String title, String status, String notes) {
    synchronized (LOCK) {
      if (csvPath == null) return;
      try {
        String ts = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        String safeTitle = safe(title);
        String safeNotes = safe(notes);
        String row = String.format("%s,%s,\"%s\",\"%s\",\"%s\"%n", ts, url, safeTitle, status, safeNotes);
        Files.writeString(csvPath, row, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
      } catch (Exception e) {
        System.err.println("CSV append error: " + e.getMessage());
      }
    }
  }

  public static String getRunTimestamp() { return runTimestamp; }

  private static String safe(String s) {
    if (s == null) return "";
    return s.replaceAll("[\\r\\n]+", " ").replace("\"", "'");
  }
}
