package utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

public final class ConfigLoader {
  private static final String CONFIG_FILE = "/config.properties";

  public static class Config {
    public final String browser;
    public final String channel;
    public final boolean headless;
    public final int slowMo;
    public final String baseURL;
    public final String appURL;
    public final Map<String, String> urls; // e.g., urls.app1, urls.app2...

    public Config(String browser,
                  String channel,
                  boolean headless,
                  int slowMo,
                  String baseURL,
                  String appURL,
                  Map<String, String> urls) {
      this.browser = browser;
      this.channel = channel;
      this.headless = headless;
      this.slowMo = slowMo;
      this.baseURL = baseURL;
      this.appURL = appURL;
      this.urls = urls;
    }
  }

  private ConfigLoader() {}

  public static Config load() {
    Properties props = new Properties();
    try (InputStream is = ConfigLoader.class.getResourceAsStream(CONFIG_FILE)) {
      if (is == null) {
        throw new IllegalStateException("config.properties not found on classpath: " + CONFIG_FILE);
      }
      props.load(is);
    } catch (IOException e) {
      throw new RuntimeException("Failed to load config.properties", e);
    }

    String browser  = props.getProperty("browser", "chromium").trim().toLowerCase();
    String channel  = props.getProperty("channel", "").trim();
    boolean headless = Boolean.parseBoolean(props.getProperty("headless", "true"));
    int slowMo     = Integer.parseInt(props.getProperty("slowMo", "1000").trim());
    String baseURL = props.getProperty("baseURL", "").trim();
    String appURL  = props.getProperty("appURL", "").trim();

    Map<String, String> urls = new TreeMap<>();
    for (String name : props.stringPropertyNames()) {
      if (name.startsWith("urls.")) {
        String key = name.substring("urls.".length()).trim();
        String val = props.getProperty(name, "").trim();
        if (!key.isEmpty() && !val.isEmpty()) {
          urls.put(key, val);
        }
      }
    }

    return new Config(browser, channel, headless, slowMo, baseURL, appURL, urls);
  }
}
