Feature: Launch practice application

Scenario: Open the site and verify title
  Given I open the practice application
  Then the home page title should contain "practice"