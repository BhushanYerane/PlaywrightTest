package playwright3.StepDefinition;

import playwright3.base.*;
import playwright3.pages.HomePage;
import com.microsoft.playwright.Page;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class RegisterSteps {
  @Given("I open the practice application")
  public void i_open_the_practice_application() {
    Page page = BaseTest.getPage();
    HomePage home = new HomePage(page);
    home.open();
  }

  @Then("the home page title should contain {string}")
  public void the_home_page_title_should_contain(String expected) {
    Page page = BaseTest.getPage();
    String title = page.title();
    System.out.println("Page Title: " + title);
    assertTrue(title.toLowerCase().contains(expected.toLowerCase()));
  }
}