package playwright4.base;

import java.io.FileInputStream;
import java.util.Properties;

import com.microsoft.playwright.APIRequest;
import com.microsoft.playwright.APIRequestContext;
import com.microsoft.playwright.Playwright;

public class PlaywrightFactory {

    private Playwright playwright;
    private APIRequestContext request;
    private Properties prop;

    // Load config
    public String initConfig() {
        prop = new Properties();
        try {
            FileInputStream fis = new FileInputStream("./src/test/resources/config.properties");
            prop.load(fis);
        } catch (Exception e) {
            System.out.println("❌ Config file not found at ./src/test/resources/config.properties");
            e.printStackTrace();
        }

        String url = prop.getProperty("appURL");

        if (url == null || url.isEmpty()) {
            throw new RuntimeException("❌ Missing 'appURL' property in config.properties");
        }

        return url.trim();
    }

    // 🔥 NEW METHOD #1 → Read API URI
    public String getAPIURI() {
        if (prop == null) {
            initConfig(); // ensure config is loaded
        }

        String apiURL = prop.getProperty("apiURI");

        if (apiURL == null || apiURL.isEmpty()) {
            throw new RuntimeException("❌ Missing 'apiURI' property in config.properties");
        }

        return apiURL.trim();
    }

    // 🔥 NEW METHOD #2 → Read API Token
    public String getToken() {
        if (prop == null) {
            initConfig();
        }

        String token = prop.getProperty("Primary_Token");

        if (token == null || token.isEmpty()) {
            throw new RuntimeException("❌ Missing 'Primary_Token' in config.properties");
        }

        return token.trim();
    }

    // Initialize Playwright
    public void init() {
        String appURL = initConfig();  // read base URL from config file

        playwright = Playwright.create();

        request = playwright.request().newContext(
                new APIRequest.NewContextOptions()
                        .setBaseURL(appURL)
                        .setIgnoreHTTPSErrors(true)
        );
    }

    public APIRequestContext getRequest() {
        return request;
    }

    public void close() {
        if (playwright != null) {
            playwright.close();
        }
    }
}