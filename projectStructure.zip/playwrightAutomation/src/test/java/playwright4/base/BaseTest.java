package playwright4.base;

import org.testng.annotations.*;
import com.microsoft.playwright.*;

public class BaseTest {

    protected PlaywrightFactory pwf;
    protected APIRequestContext request;

    @BeforeClass
    public void setUp() {
        pwf = new PlaywrightFactory();
        System.out.println("API Test Started --->");
        pwf.init();
        request = pwf.getRequest();
    }

    @AfterClass
    public void tearDown() {
        pwf.close();
        System.out.println("<------ Test Ended -");
    }
}