package playwright4.tests;

import playwright4.base.BaseTest;
import playwright4.pages.UsersAPIPage;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.microsoft.playwright.*;

public class UsersAPITest extends BaseTest {

    @Test
    // dotesthere API
    public void validateGetDotesthereUsersAPI() {
        UsersAPIPage usersAPI = new UsersAPIPage(request);

        APIResponse response = usersAPI.getDotesthereUsers();
        Assert.assertEquals(response.status(), 200, "Status code mismatch!");

        String responseBody = response.text();
        System.out.println("Dotesthere API Response: " + responseBody);

        Assert.assertTrue(responseBody.contains("users") || responseBody.contains("data"),
                "Expected fields not found in response!");
    }   
}