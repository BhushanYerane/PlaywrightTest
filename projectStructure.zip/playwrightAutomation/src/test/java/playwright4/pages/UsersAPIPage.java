package playwright4.pages;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.RequestOptions;

public class UsersAPIPage {

	private APIRequestContext request;

	public UsersAPIPage(APIRequestContext request) {
		this.request = request;
	}

	public APIResponse getDotesthereUsers() {
		return request.get("/api/users");
	}

}