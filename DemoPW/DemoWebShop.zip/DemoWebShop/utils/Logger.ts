export function log(message: string) {
  console.log(`[DemoWebShop] ${message}`);
}
