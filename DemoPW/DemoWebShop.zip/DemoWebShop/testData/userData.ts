export const users = {
  validUser: {
    email: 'test@example.com',
    password: 'Password123!'
  }
};
