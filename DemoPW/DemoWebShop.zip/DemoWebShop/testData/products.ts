export const sampleProducts = [
  { id: 1, name: 'Build your own computer' },
  { id: 2, name: 'Lenovo IdeaCentre' }
];
