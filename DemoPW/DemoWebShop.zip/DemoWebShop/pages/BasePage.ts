import { Page } from '@playwright/test';

export default class BasePage {
  readonly page: Page;
  readonly baseURL: string;

  constructor(page: Page, baseURL: string) {
    this.page = page;
    this.baseURL = baseURL;
  }

  async goto(path = '/') {
    await this.page.goto(`${this.baseURL}${path}`);
  }
}
