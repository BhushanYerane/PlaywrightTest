import BasePage from './BasePage';
export default class ProductPage extends BasePage {}
