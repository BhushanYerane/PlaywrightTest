import BasePage from './BasePage';

export default class HomePage extends BasePage {
  constructor(page: any, baseURL: string) {
    super(page, baseURL);
  }
}
