import BasePage from './BasePage';
export default class SearchPage extends BasePage {}
