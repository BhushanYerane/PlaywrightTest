import { test } from '@playwright/test';
test('register skeleton', async ({ page }) => {
  await page.goto('/register');
});
