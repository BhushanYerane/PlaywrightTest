import { test, expect } from '@playwright/test';
import LoginPage from '../pages/LoginPage';
import { users } from '../testData/userData';

test('user can login with valid credentials', async ({ page, baseURL }) => {
  const login = new LoginPage(page, baseURL! as string);
  await login.goto();
  await login.login(users.validUser.email, users.validUser.password);
  await expect(page.locator('a.account')).toBeVisible();
});
