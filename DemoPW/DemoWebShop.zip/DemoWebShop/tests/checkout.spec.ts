import { test } from '@playwright/test';
test('checkout skeleton', async ({ page }) => {
  await page.goto('/');
});
