import { test } from '@playwright/test';
test('cart skeleton', async ({ page }) => {
  await page.goto('/');
});
