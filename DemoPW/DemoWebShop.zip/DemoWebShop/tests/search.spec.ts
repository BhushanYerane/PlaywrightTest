import { test } from '@playwright/test';
test('search skeleton', async ({ page }) => {
  await page.goto('/');
});
